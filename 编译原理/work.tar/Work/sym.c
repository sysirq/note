#include "sym.h"

arr_elem *create_arr_elem()
{
	arr_elem *p = malloc(sizeof(arr_elem));
	if(!p) return NULL;
	memset(p,0,sizeof(arr_elem));
	return p;
}

symbol *create_func_sym(char *name,uint32_t type,symbol *param_sym)
{
	symbol *sym = create_sym(name,type);
	if(!sym) return NULL;
	sym->param_sym = param_sym;
	sym->class = FUNC;
	return sym;
}

symbol *create_var_sym(char *name,uint32_t type)
{
	symbol *sym = create_sym(name,type);
	if(!sym) return NULL;
	sym->class = VAR;
	return sym;
}

symbol *create_var_ptr_sym(char *name,uint32_t type)
{
	symbol *sym = create_sym(name,type);
	if(!sym) return NULL;
	sym->class = VAR_PTR;
	return sym;
}

symbol *create_arr_sym(char *name,uint32_t type,int len)
{
	symbol *sym = create_sym(name,type);
	if(!sym) return NULL;
	sym->class = ARRAY;
	sym->arr_len = len;
	return sym;
}

symbol *create_arr_init_sym(char *name,uint32_t type,int len,struct arr_elem *arr_elems)
{
	symbol *sym = create_sym(name,type);
	if(!sym) return NULL;
	sym->class = ARRAY_INIT;
	sym->arr_len = len;
	sym->arr_elem = arr_elems;
	return sym;
}

symbol *create_sym(char *name,uint32_t type)
{
	if(!name)return NULL;

	symbol *sym = (symbol*)malloc(sizeof(symbol));
	if(!sym) return NULL;
	
	memset(sym,0,sizeof(symbol));
	
	sym->type = type;
	sym->addr = 0;
	sym->name = (char*)malloc(strlen(name)+1);
	
	if(!name){
		free(sym);
		return NULL;
	}
	strcpy(sym->name,name);
	return sym;
}

void free_sym(symbol *sym)
{
	if(!sym) return;
	if(sym->name)	free(sym->name);
	
	if(sym->class == ARRAY_INIT){
		struct arr_elem *elem = sym->arr_elem;
		struct arr_elem *n;

		while(elem){
			n = elem->next;
			free(elem);
			elem = n;
		}
	}
	free(sym);
}	

void free_symbols(symbol **symbols)
{
	if(!*symbols) return;
	
	symbol *p,*n;

	p = n = *symbols;

	while(p){
		n = p->next;
		free_sym(p);
		p = n;
	}

	*symbols = NULL;
}


symbol *find_symbol(symbol *symbols,char *name)
{
	if(!symbols || !name) return NULL;
	
	symbol *p,*n;
	p = n = symbols;

	while(p){
		n = p->next;
		if(!strcmp(p->name,name)) return p;
		p = n;
	}

	return NULL;
}

symbol *check_sym_dup(symbol *symbols)
{
	symbol *p,*n;
	p = symbols;
	
	while(p){
		n = p->next;

		while(n){
			if(strcmp(n->name,p->name)==0) return p;
			n = n->next;
		}

		p = p->next;
	}

	return 0;
}

void gen_symbols_addr(symbol *sym)
{
	symbol *p,*n;
	int step_size = 0;
	int addr = 0;
	p = sym;

	while(p){
		n = p->next;
		switch(p->class){
		case VAR:
			switch(p->type){
			case UINT8: p->addr = addr;addr+=1;p->end_addr = addr;break;
			case UINT16: p->addr = addr;addr+=2;p->end_addr = addr;break;
			case UINT32:
			case VOID:
			case VOID_PTR:
			case UINT8_PTR:
			case UINT16_PTR:
			case UINT32_PTR:
				p->addr = addr;addr+=4;p->end_addr = addr;
				break;
			}
			break;
		case ARRAY:
		case ARRAY_INIT:
			switch(p->type){
			case UINT8: step_size = 1;break;
			case UINT16: step_size = 2;break;
			case UINT32:
			case VOID:
			case VOID_PTR:
			case UINT8_PTR:
			case UINT16_PTR:
			case UINT32_PTR:
				step_size = 4;
				break;
			}
			p->addr = addr;
			addr += (step_size * p->arr_len);
			p->end_addr = addr;
			break;
		}

		p = n;
	}
}

int get_symbols_max_end_addr(symbol *sym)
{
	int ret = 0;

	while(sym){
		if(sym->end_addr > ret)
			ret = sym->end_addr;
		sym = sym->next;
	}
	return ret;
}
