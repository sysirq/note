#ifndef _NODE_H_
#define _NODE_H_
#include "sym.h"
#include <stdarg.h>
typedef enum {typeCon,typeId,typeOpr,typeParam,typeFunc} nodeEnum;
typedef enum {paramCon,paramId} paramEnum;

/*constants*/
typedef struct{
	int value;
}conNodeType;

/*identifiers*/
typedef struct{
	char name[SYM_STR_MAX_LEN + 1];
}idNodeType;

/*function parameter*/
typedef struct funcParam{
	paramEnum type;
	union{
		char name[SYM_STR_MAX_LEN + 1];
		int value;
	};
	struct nodeTypeTag *next;
}funcParam;

/*operators*/
typedef struct{
	int oper;//operator
	int nops;//number of operands
	struct nodeTypeTag **op;//operands
}oprNodeType;

/*func*/
typedef struct{
	symbol *local_sym;
	symbol *param_sym;
	char name[SYM_STR_MAX_LEN + 1];
	struct nodeTypeTag *func_body;
	struct nodeTypeTag *next;
}funcNodeType;

typedef struct nodeTypeTag{
	nodeEnum type;	//type of node
	int      len;	//decide instruction size
	int 	 left_value; // is left value?
	union{
		conNodeType con;
		idNodeType id;
		oprNodeType opr;
		funcParam param;
		funcNodeType func;
	};
}nodeType;

nodeType *id(char *name);
nodeType *con(int value);
nodeType *func_node(nodeType *func_body,symbol *lsym,symbol *psym,char *name);
nodeType *id_param(char *name);
nodeType *con_param(int value);
nodeType *opr(int oper,int nops,...);
void free_nodes(nodeType *p);
#endif
