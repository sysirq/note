#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "node.h"
#include "y.tab.h"

#define MAX_MEM_SIZE 0x300000

enum OPCODES
{
	MOV = 0xb0,
	SUB = 0xb1,
	ADD = 0xb2,
	PUSH = 0xb3,
	POP = 0xb4,
	_XOR = 0xb5,
	MUL = 0xb6,
	DIV = 0xb7,
	MOD = 0xb8,
	STACK_ADD = 0xb9,
	STACK_SUB = 0xba,
	STACK_MUL = 0xbb,
	STACK_DIV = 0xbc,
	STACK_MOD = 0xbd,

	STACK_LT = 0xbe,
	STACK_GT = 0xbf,
	
	STACK_AND = 0xc0,
	STACK_OR = 0xc1,
	
	STACK_GE = 0xc2,
	STACK_LE = 0xc3,
	
	STACK_NE = 0xc4,
	STACK_EQ = 0xc5,
	
	STACK_LSHIFT = 0xc6,
	STACK_RSHIFT = 0xc7,
	
	CMP = 0xc8,
	JZ = 0xc9,
	JNZ = 0xca,
	JMP = 0xcb,
	_GETCH = 0xcc,
	_PUTCH = 0xcd,
	
	CALL = 0xce,
	RET = 0xcf,
	
	STACK_XOR = 0xd0,
	
	EXIT = 0x00,
};

enum REGISTERS
{
	EAX = 0x10,
	EBX = 0x11,
	ECX = 0x12,
	EDX = 0x13,
	ESI = 0x14,
	EDI = 0x15,
	EBP = 0x16,
	ESP = 0x17,
	EIP = 0x18,
	NONE = 0x19,
};

enum OP_SIZE {
	BYTE = 0x21,
	WORD = 0x22,
	DWORD = 0x24
};

enum TYPE {
	REG_REG = 0x11,
	REG_ADR = 0x12,
	REG_INT = 0x13,
	ADR_REG = 0x14,
	REGADR_REG = 0x15,
	REG_REGADR = 0x16
};
unsigned char mem[MAX_MEM_SIZE];

static int push_param(nodeType *params,symbol *param_sym);

static int determine_op_size(symbol *sym);
static void init_global_data_mem();
static symbol *find_symbol_in_all(char *name);
static unsigned long code_start_addr;
static unsigned long curr_code_addr;
static unsigned long lbl = 0;

static nodeType *curr_func;

#define PER_FOR_MAX_BREAK 1000
#define MAX_NEST_FOR 1000
static unsigned long curr_break_addr = 0;
static uint32_t *break_addr[PER_FOR_MAX_BREAK];
static unsigned long nest_for_end[MAX_NEST_FOR];
static unsigned long curr_nest_for = 0;

int ex(nodeType *p)
{
	int i = 0;
	int ret = 0;
	symbol *sym;
	init_global_data_mem();
	ret = _ex(p);
	
	sym = find_symbol_in_all("check");
	assert(sym && sym->class == FUNC);

	printf("eip:0x%X\n",sym->addr);
	printf("code start addr:%d\n",code_start_addr);
	printf("code end   addr:%d\n",curr_code_addr);
	
	for(i = 0;i<curr_code_addr;i++){
		if(i == 0){
			printf("{0x%X,",mem[i]);
		}else if(i + 1 != curr_code_addr){
			printf("0x%X,",mem[i]);
		}else{
			printf("0x%X}\n",mem[i]);
		}
	}

	return ret;
}

int _ex(nodeType *p)
{
	unsigned long lbl1,lbl2;
	uint32_t *code_pos1,*code_pos2;
	struct symbol *sym;

	if(!p) return 0;

	switch (p -> type){
	case typeFunc:
		code_start_addr = curr_code_addr = get_symbols_max_end_addr(global_symbols);//set code addr
		while(p){
			//save space for local var
			curr_func = p;
			int local_var_end = get_symbols_max_end_addr(p->func.local_sym);
			
			sym = find_symbol_in_all(p->func.name);
			assert(sym->class == FUNC);
			sym->addr = curr_code_addr;
			printf("func:%s addr:0x%0X\n",sym->name,sym->addr);
			
			printf("\tpush\tebp\n");
			mem[curr_code_addr++]=PUSH;
			mem[curr_code_addr++]=DWORD;
			mem[curr_code_addr++]=EBP;
			
			printf("\tmov\tebp,esp\n");
			mem[curr_code_addr++]=MOV;
			mem[curr_code_addr++]=REG_REG;
			mem[curr_code_addr++]=DWORD;
			mem[curr_code_addr++]=EBP;
			mem[curr_code_addr++]=ESP;
			
			printf("\tsub\tesp,%d\n",local_var_end);
			mem[curr_code_addr++]=SUB;
			mem[curr_code_addr++]=REG_INT;
			mem[curr_code_addr++]=DWORD;
			mem[curr_code_addr++]=ESP;
			*(int*)&mem[curr_code_addr]=local_var_end;
			curr_code_addr+=4;
			
			_ex(p->func.func_body);
			
			printf("\tadd\tesp,%d\n",local_var_end);
			mem[curr_code_addr++]=ADD;
			mem[curr_code_addr++]=REG_INT;
			mem[curr_code_addr++]=DWORD;
			mem[curr_code_addr++]=ESP;
			*(int*)&mem[curr_code_addr]=local_var_end;
			curr_code_addr+=4;
			
			printf("\tpop\tebp\n");
			mem[curr_code_addr++]=POP;
			mem[curr_code_addr++]=DWORD;
			mem[curr_code_addr++]=EBP;
			
			printf("\tret\n");
			mem[curr_code_addr++]=RET;

			p = p->func.next;
		}
		break;
	case typeCon:
		printf("\tmov\teax,%d\n",p->con.value);
		mem[curr_code_addr++]=MOV;
		mem[curr_code_addr++]=REG_INT;
		mem[curr_code_addr++]=DWORD;
		mem[curr_code_addr++]=EAX;
		*(int*)&mem[curr_code_addr]=p->con.value;
		curr_code_addr+=4;
		
		p->left_value = 0;

		p->len = 4;
		break;
	case typeId://get addr to eax
		sym = find_symbol_in_all(p->id.name);
		p->len = determine_op_size(sym);
		
		p->left_value = 1;
		
		if(sym->is_global){//global var
			printf("\tmov\teax,%d\n",sym->addr);
			mem[curr_code_addr++]=MOV;
			mem[curr_code_addr++]=REG_INT;
			mem[curr_code_addr++]=DWORD;
			mem[curr_code_addr++]=EAX;
			*(int*)&mem[curr_code_addr]=sym->addr;
			curr_code_addr+=4;
		}else{
			printf("\tmov\teax,ebp\n");
			mem[curr_code_addr++]=MOV;
			mem[curr_code_addr++]=REG_REG;
			mem[curr_code_addr++]=DWORD;
			mem[curr_code_addr++]=EAX;
			mem[curr_code_addr++]=EBP;
			if(sym->is_param){//func param
				printf("\tadd\teax,%d\n",sym->addr+4 + 4);//skip ebp and ret addr
				mem[curr_code_addr++]=ADD;
				mem[curr_code_addr++]=REG_INT;
				mem[curr_code_addr++]=DWORD;
				mem[curr_code_addr++]=EAX;
				*(int*)&mem[curr_code_addr]=sym->addr+4+4;
				curr_code_addr+=4;
			}else{//local var
				printf("\tsub\teax,%d\n",sym->end_addr);
				mem[curr_code_addr++]=SUB;
				mem[curr_code_addr++]=REG_INT;
				mem[curr_code_addr++]=DWORD;
				mem[curr_code_addr++]=EAX;
				*(int*)&mem[curr_code_addr]=sym->end_addr;
				curr_code_addr+=4;
			}
		}
		break;
	case typeOpr:
		switch(p->opr.oper){
		case BREAK:
			assert(curr_nest_for!=0);
			printf("\tjmp\tL%03d\n",nest_for_end[curr_nest_for-1]);
			mem[curr_code_addr++] = JMP;
			*(uint32_t*)(mem+curr_code_addr) = 0;
			assert(curr_break_addr < PER_FOR_MAX_BREAK);
			break_addr[curr_break_addr++] = (uint32_t*)(mem+curr_code_addr);
			curr_code_addr+=4;
			
			
			break;
		case GETCH:
			printf("\tgetch\n");
			mem[curr_code_addr++]=_GETCH;
			p->len = 1;
			p->left_value = 0;
			break;
		case PUTCH:
			assert(p->opr.op[0]->type == typeId || p->opr.op[0]->type == typeCon);
			_ex(p->opr.op[0]);
			if(p->opr.op[0]->left_value){
				printf("\tmov\tal,[eax]\n");
				mem[curr_code_addr++]=MOV;
				mem[curr_code_addr++]=REG_REGADR;
				mem[curr_code_addr++]=BYTE;
				mem[curr_code_addr++]=EAX;
				mem[curr_code_addr++]=EAX;
			}
			printf("\tputch\tal\n");
			mem[curr_code_addr++]=_PUTCH;
			p->len = 1;
			p->left_value = 0;
			break;
		case FOR:
			lbl1 = lbl++;
			lbl2 = lbl++;
			nest_for_end[curr_nest_for++] = lbl2;

			unsigned long break_start_addr = curr_break_addr;
			_ex(p->opr.op[0]);
			
			printf("L%03d:\n",lbl1);
			unsigned long jmp_addr = curr_code_addr;

			_ex(p->opr.op[1]);
			if(p->opr.op[1]->left_value){
				printf("\tmov\teax,[eax]\n");
				mem[curr_code_addr++]=MOV;
				mem[curr_code_addr++]=REG_REGADR;
				mem[curr_code_addr++]=DWORD;
				mem[curr_code_addr++]=EAX;
				mem[curr_code_addr++]=EAX;
			}
			
			
			printf("\tcmp\teax,0\n");
			mem[curr_code_addr++] = CMP;
			mem[curr_code_addr++] = EAX;
			*(uint32_t*)(mem + curr_code_addr) = 0;
			curr_code_addr += 4;
			
			printf("\tjz\tL%03d\n",lbl2);
			mem[curr_code_addr++] = JZ;
			code_pos1 = (uint32_t*)(mem+curr_code_addr);
			*(uint32_t*)(mem+curr_code_addr) = 0;
			curr_code_addr+=4;
			
			_ex(p->opr.op[3]);

			_ex(p->opr.op[2]);

			printf("\tjmp\tL%03d\n",lbl1);
			mem[curr_code_addr++] = JMP;
			code_pos2 = (uint32_t*)(mem+curr_code_addr);
			*(uint32_t*)(mem+curr_code_addr) = jmp_addr;
			curr_code_addr+=4;
			
			printf("L%03d:\n",lbl2);
			*code_pos1 = curr_code_addr;
			
			int i;
			for(i = break_start_addr;i<curr_break_addr;i++){
				*break_addr[i] = curr_code_addr;
			}
			
			curr_break_addr = break_start_addr;
			curr_nest_for--;
			break;
		case IF:
			lbl1 = lbl++;
			_ex(p->opr.op[0]);
			if(p->opr.op[0]->left_value){
				printf("\tmov\teax,[eax]\n");
				mem[curr_code_addr++]=MOV;
				mem[curr_code_addr++]=REG_REGADR;
				mem[curr_code_addr++]=DWORD;
				mem[curr_code_addr++]=EAX;
				mem[curr_code_addr++]=EAX;
			}
			
			printf("\tcmp\teax,0\n");
			mem[curr_code_addr++] = CMP;
			mem[curr_code_addr++] = EAX;
			*(uint32_t*)(mem + curr_code_addr) = 0;
			curr_code_addr += 4;

			printf("\tjz\tL%03d\n",lbl1);
			mem[curr_code_addr++] = JZ;
			code_pos1 = (uint32_t*)(mem+curr_code_addr);
			*(uint32_t*)(mem+curr_code_addr) = 0;
			curr_code_addr+=4;
			
			_ex(p->opr.op[1]);
			printf("L%03d:\n",lbl1);
			*code_pos1 = curr_code_addr;
			p->left_value = 0;
			break;
		case ELSE:
			lbl1 = lbl++;
			lbl2 = lbl++;
			_ex(p->opr.op[0]);
			if(p->opr.op[0]->left_value){
				printf("\tmov\teax,[eax]\n");
				mem[curr_code_addr++]=MOV;
				mem[curr_code_addr++]=REG_REGADR;
				mem[curr_code_addr++]=DWORD;
				mem[curr_code_addr++]=EAX;
				mem[curr_code_addr++]=EAX;
			}
			
			printf("\tcmp\teax,0\n");
			mem[curr_code_addr++] = CMP;
			mem[curr_code_addr++] = EAX;
			*(uint32_t*)(mem + curr_code_addr) = 0;
			curr_code_addr += 4;
			
			printf("\tjz\tL%03d\n",lbl1);
			mem[curr_code_addr++] = JZ;
			code_pos1 = (uint32_t*)(mem+curr_code_addr);
			*(uint32_t*)(mem+curr_code_addr) = 0;
			curr_code_addr+=4;
			
			_ex(p->opr.op[1]);
			printf("\tjmp\tL%03d\n",lbl2);
			mem[curr_code_addr++] = JMP;
			code_pos2 = (uint32_t*)(mem+curr_code_addr);
			*(uint32_t*)(mem+curr_code_addr) = 0;
			curr_code_addr+=4;

			printf("L%03d:\n",lbl1);
			*code_pos1 = curr_code_addr;
			_ex(p->opr.op[2]);
			
			printf("L%03d:\n",lbl2);
			*code_pos2 = curr_code_addr;
			break;
		case FUNC_NO_PAR:
			sym = find_symbol_in_all(p->opr.op[0]->id.name);
			assert(sym && sym->class ==FUNC);

			printf("\tcall\t%s(0x%X)\n",p->opr.op[0]->id.name,sym->addr);
			mem[curr_code_addr++]=CALL;
			*(uint32_t*)(mem+curr_code_addr)=sym->addr;
			curr_code_addr+=4;
			
			break;
		case FUNC_PAR:
			sym = find_symbol_in_all(p->opr.op[0]->id.name);
			assert(sym && sym->class ==FUNC);
			
			int len = push_param(p->opr.op[1],sym->param_sym);
			
			printf("\tcall\t%s(0x%X)\n",p->opr.op[0]->id.name,sym->addr);
			mem[curr_code_addr++]=CALL;
			*(uint32_t*)(mem+curr_code_addr)=sym->addr;
			curr_code_addr+=4;
			
			printf("\tadd\tesp,%d\n",len);
			mem[curr_code_addr++]=ADD;
			mem[curr_code_addr++]=REG_INT;
			mem[curr_code_addr++]=DWORD;
			mem[curr_code_addr++]=ESP;
			*(uint32_t*)(mem+curr_code_addr)=len;
			curr_code_addr+=4;
			break;
		case '=':
			_ex(p->opr.op[1]);
			printf("\txor\tebx,ebx\n");
			mem[curr_code_addr++]=_XOR;
			mem[curr_code_addr++]=REG_REG;
			mem[curr_code_addr++]=DWORD;
			mem[curr_code_addr++]=EBX;
			mem[curr_code_addr++]=EBX;
			if(p->opr.op[1]->left_value){//left value
				switch(p->opr.op[1]->len){
				case 1:
					printf("\tmov\tbl,[eax]\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_REGADR;
					mem[curr_code_addr++]=BYTE;
					mem[curr_code_addr++]=EBX;
					mem[curr_code_addr++]=EAX;
					break;
				case 2:
					printf("\tmov\tbx,[eax]\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_REGADR;
					mem[curr_code_addr++]=WORD;
					mem[curr_code_addr++]=EBX;
					mem[curr_code_addr++]=EAX;
					break;
				case 4:
					printf("\tmov\tebx,[eax]\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_REGADR;
					mem[curr_code_addr++]=DWORD;
					mem[curr_code_addr++]=EBX;
					mem[curr_code_addr++]=EAX;
					break;
				}
			}else{//right
				switch(p->opr.op[1]->len){
				case 1:
					printf("\tmov\tbl,al\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_REG;
					mem[curr_code_addr++]=BYTE;
					mem[curr_code_addr++]=EBX;
					mem[curr_code_addr++]=EAX;
					break;
				case 2:
					printf("\tmov\tbx,ax\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_REG;
					mem[curr_code_addr++]=WORD;
					mem[curr_code_addr++]=EBX;
					mem[curr_code_addr++]=EAX;
					break;
				case 4:
					printf("\tmov\tebx,eax\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_REG;
					mem[curr_code_addr++]=DWORD;
					mem[curr_code_addr++]=EBX;
					mem[curr_code_addr++]=EAX;
					break;
				}
			}
			printf("\tpush\tebx\n");
			mem[curr_code_addr++]=PUSH;
			mem[curr_code_addr++]=DWORD;
			mem[curr_code_addr++]=EBX;
			_ex(p->opr.op[0]);
			printf("\tpop\tebx\n");
			mem[curr_code_addr++]=POP;
			mem[curr_code_addr++]=DWORD;
			mem[curr_code_addr++]=EBX;
			//must left value
			if(!p->opr.op[0]->left_value){
				printf("= need left value\n");
				exit(-1);
			}
			switch(p->opr.op[0]->len){
			case 1:
				printf("\tmov\t[eax],bl\n");
				mem[curr_code_addr++]=MOV;
				mem[curr_code_addr++]=REGADR_REG;
				mem[curr_code_addr++]=BYTE;
				mem[curr_code_addr++]=EAX;
				mem[curr_code_addr++]=EBX;
				break;
			case 2:
				printf("\tmov\t[eax],bx\n");
				mem[curr_code_addr++]=MOV;
				mem[curr_code_addr++]=REGADR_REG;
				mem[curr_code_addr++]=WORD;
				mem[curr_code_addr++]=EAX;
				mem[curr_code_addr++]=EBX;
				break;
			case 4:
				printf("\tmov\t[eax],ebx\n");
				mem[curr_code_addr++]=MOV;
				mem[curr_code_addr++]=REGADR_REG;
				mem[curr_code_addr++]=DWORD;
				mem[curr_code_addr++]=EAX;
				mem[curr_code_addr++]=EBX;
				break;
			}
			break;
		case ARRAY_INDEX://arr[index]
			_ex(p->opr.op[1]);//index
			printf("\txor\tebx,ebx\n");
			mem[curr_code_addr++]=_XOR;
			mem[curr_code_addr++]=REG_REG;
			mem[curr_code_addr++]=DWORD;
			mem[curr_code_addr++]=EBX;
			mem[curr_code_addr++]=EBX;
			if(p->opr.op[1]->left_value){//left value
				switch(p->opr.op[1]->len){
				case 1:
					printf("\tmov\tbl,[eax]\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_REGADR;
					mem[curr_code_addr++]=BYTE;
					mem[curr_code_addr++]=EBX;
					mem[curr_code_addr++]=EAX;
					break;
				case 2:
					printf("\tmov\tbx,[eax]\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_REGADR;
					mem[curr_code_addr++]=WORD;
					mem[curr_code_addr++]=EBX;
					mem[curr_code_addr++]=EAX;
					break;
				case 4:
					printf("\tmov\tebx,[eax]\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_REGADR;
					mem[curr_code_addr++]=DWORD;
					mem[curr_code_addr++]=EBX;
					mem[curr_code_addr++]=EAX;
					break;
				}
			}else{//right
				switch(p->opr.op[1]->len){
				case 1:
					printf("\tmov\tbl,al\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_REG;
					mem[curr_code_addr++]=BYTE;
					mem[curr_code_addr++]=EBX;
					mem[curr_code_addr++]=EAX;
					break;
				case 2:
					printf("\tmov\tbx,ax\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_REG;
					mem[curr_code_addr++]=WORD;
					mem[curr_code_addr++]=EBX;
					mem[curr_code_addr++]=EAX;
					break;
				case 4:
					printf("\tmov\tebx,eax\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_REG;
					mem[curr_code_addr++]=DWORD;
					mem[curr_code_addr++]=EBX;
					mem[curr_code_addr++]=EAX;
					break;
				}
			}
			printf("\tpush\tebx\n");
			mem[curr_code_addr++]=PUSH;
			mem[curr_code_addr++]=DWORD;
			mem[curr_code_addr++]=EBX;

			
			_ex(p->opr.op[0]);//array
			assert(p->opr.op[0]->type == typeId);
			sym = find_symbol_in_all(p->opr.op[0]->id.name);
			
			printf("\tpop\tebx\n");
			mem[curr_code_addr++]=POP;
			mem[curr_code_addr++]=DWORD;
			mem[curr_code_addr++]=EBX;

			assert(p->opr.op[0]->left_value == 1);
			printf("\txor\tedx,edx\n");
			mem[curr_code_addr++]=_XOR;
			mem[curr_code_addr++]=REG_REG;
			mem[curr_code_addr++]=DWORD;
			mem[curr_code_addr++]=EDX;
			mem[curr_code_addr++]=EDX;
			
			//id is pointer
			switch(sym->type){
			case UINT8_PTR:
			case UINT16_PTR:
			case UINT32_PTR:
				printf("\tmov\teax,[eax]\n");
				mem[curr_code_addr++]=MOV;
				mem[curr_code_addr++]=REG_REGADR;
				mem[curr_code_addr++]=DWORD;
				mem[curr_code_addr++]=EAX;
				mem[curr_code_addr++]=EAX;
				break;
			}

			printf("\tmov\tedx,eax\n");
			mem[curr_code_addr++]=MOV;
			mem[curr_code_addr++]=REG_REG;
			mem[curr_code_addr++]=DWORD;
			mem[curr_code_addr++]=EDX;
			mem[curr_code_addr++]=EAX;
			//now edx = ID , ebx = index
			
			//calculate elem addr
			switch(p->opr.op[0]->len){
			case 1:
				printf("\tmov\teax,1\n");
				mem[curr_code_addr++]=MOV;
				mem[curr_code_addr++]=REG_INT;
				mem[curr_code_addr++]=DWORD;
				mem[curr_code_addr++]=EAX;
				*(uint32_t*)(mem+curr_code_addr)=1;
				curr_code_addr+=4;
				p->len = 1;
				break;
			case 2:
				printf("\tmov\teax,2\n");
				mem[curr_code_addr++]=MOV;
				mem[curr_code_addr++]=REG_INT;
				mem[curr_code_addr++]=DWORD;
				mem[curr_code_addr++]=EAX;
				*(uint32_t*)(mem+curr_code_addr)=2;
				curr_code_addr+=4;
				p->len = 2;
				break;
			case 4:
				switch(sym->type){
				case UINT8_PTR:
					printf("\tmov\teax,1\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_INT;
					mem[curr_code_addr++]=DWORD;
					mem[curr_code_addr++]=EAX;
					*(uint32_t*)(mem+curr_code_addr)=1;
					curr_code_addr+=4;
					p->len = 1;
					break;
				case UINT16_PTR:
					printf("\tmov\teax,2\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_INT;
					mem[curr_code_addr++]=DWORD;
					mem[curr_code_addr++]=EAX;
					*(uint32_t*)(mem+curr_code_addr)=2;
					curr_code_addr+=4;
					p->len = 2;
					break;
				default:
					printf("\tmov\teax,4\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_INT;
					mem[curr_code_addr++]=DWORD;
					mem[curr_code_addr++]=EAX;
					*(uint32_t*)(mem+curr_code_addr)=4;
					curr_code_addr+=4;
					p->len = 4;
					break;
				}
				break;
			}

			//calcu index mul size
			printf("\tmul\teax,ebx\n");
			mem[curr_code_addr++]=MUL;
			mem[curr_code_addr++]=REG_REG;
			mem[curr_code_addr++]=DWORD;
			mem[curr_code_addr++]=EAX;
			mem[curr_code_addr++]=EBX;
			

			//add to id addr
			printf("\tadd\teax,edx\n");
			mem[curr_code_addr++]=ADD;
			mem[curr_code_addr++]=REG_REG;
			mem[curr_code_addr++]=DWORD;
			mem[curr_code_addr++]=EAX;
			mem[curr_code_addr++]=EDX;

			p->left_value = 1;
			break;
		case REF://& get addr
			_ex(p->opr.op[0]);
			assert(p->opr.op[0]->left_value == 1);
			p->len = 4;
			p->left_value = 0;//eax == &id
			break;
		case UMINUS:
			_ex(p->opr.op[0]);
			printf("\tNEG(not implement)\n");exit(-1);
			break;
		case DREF://*id
			_ex(p->opr.op[0]);
			assert(p->opr.op[0]->type == typeId);
			assert(p->opr.op[0]->left_value);
			if(p->opr.op[0]->type == typeId){
				printf("\tmov\teax,[eax]\n");
				mem[curr_code_addr++]=MOV;
				mem[curr_code_addr++]=REG_REGADR;
				mem[curr_code_addr++]=DWORD;
				mem[curr_code_addr++]=EAX;
				mem[curr_code_addr++]=EAX;
				sym = find_symbol_in_all(p->opr.op[0]->id.name);
				switch(sym->type){
				case UINT8_PTR:
					p->len = 1;
					break;
				case UINT16_PTR:
					p->len = 2;
					break;
				case UINT32_PTR:
					p->len = 4;
					break;
				default:
					printf("dref type error\n");exit(-1);
					break;
				}
			}else{
				printf("\tmov\teax,[eax]\n");
				mem[curr_code_addr++]=MOV;
				mem[curr_code_addr++]=REG_REGADR;
				mem[curr_code_addr++]=DWORD;
				mem[curr_code_addr++]=EAX;
				mem[curr_code_addr++]=EAX;
				switch(p->opr.op[0]->len){
				case UINT8_PTR:
					p->len = 1;
					break;
				case UINT16_PTR:
					p->len = 2;
					break;
				case UINT32_PTR:
					p->len = 4;
					break;
				default:
					printf("dref type error\n");exit(-1);
					break;
				}
			
			}
			p->left_value = 1;//
			break;
		case _DREF://*(type*)id
			_ex(p->opr.op[1]);
			if(p->opr.op[1]->left_value){
				printf("\tmov\teax,[eax]\n");
				mem[curr_code_addr++]=MOV;
				mem[curr_code_addr++]=REG_REGADR;
				mem[curr_code_addr++]=DWORD;
				mem[curr_code_addr++]=EAX;
				mem[curr_code_addr++]=EAX;
			}
			switch(p->opr.op[0]->con.value){
			case UINT8_PTR:
				p->len = 1;
				break;
			case UINT16_PTR:
				p->len = 2;
				break;
			case UINT32_PTR:
				p->len = 4;
				break;
			default:
				printf("dref type error\n");exit(-1);
				break;
			}
			p->left_value = 1;//
			break;
		case AND:
			lbl1 = lbl++;
			_ex(p->opr.op[0]);
			if(p->opr.op[0]->left_value){
				printf("\tmov\teax,[eax]\n");
				mem[curr_code_addr++]=MOV;
				mem[curr_code_addr++]=REG_REGADR;
				mem[curr_code_addr++]=DWORD;
				mem[curr_code_addr++]=EAX;
				mem[curr_code_addr++]=EAX;
			}
			
			printf("\tcmp\teax,0\n");
			mem[curr_code_addr++]=CMP;
			mem[curr_code_addr++]=EAX;
			*(uint32_t*)(mem+curr_code_addr)=0;
			curr_code_addr+=4;

			printf("\tjz\tL%03d\n",lbl1);
			mem[curr_code_addr++]=JZ;
			code_pos1 = (uint32_t*)(mem+curr_code_addr);
			*((uint32_t*)mem+curr_code_addr)=0;
			curr_code_addr+=4;
			
			_ex(p->opr.op[1]);
			
			printf("L%03d:\n",lbl1);
			*code_pos1 = curr_code_addr;
			p->left_value = 0;
			p->len = 4;
			break;
		case OR:
			lbl1 = lbl++;
			_ex(p->opr.op[0]);
			if(p->opr.op[0]->left_value){
				printf("\tmov\teax,[eax]\n");
				mem[curr_code_addr++]=MOV;
				mem[curr_code_addr++]=REG_REGADR;
				mem[curr_code_addr++]=DWORD;
				mem[curr_code_addr++]=EAX;
				mem[curr_code_addr++]=EAX;
			}
			
			printf("\tcmp\teax,0\n");
			mem[curr_code_addr++]=CMP;
			mem[curr_code_addr++]=EAX;
			*(uint32_t*)(mem+curr_code_addr)=0;
			curr_code_addr+=4;

			printf("\tjnz\tL%03d\n",lbl1);
			mem[curr_code_addr++]=JNZ;
			code_pos1 = (uint32_t*)(mem+curr_code_addr);
			*(uint32_t*)(mem+curr_code_addr)=0;
			curr_code_addr+=4;
			
			_ex(p->opr.op[1]);
			
			printf("L%03d:\n",lbl1);
			*code_pos1 = curr_code_addr;
			p->left_value = 0;
			p->len = 4;
			break;
		case ';':
			_ex(p->opr.op[0]);
			_ex(p->opr.op[1]);
			break;
		default:
			_ex(p->opr.op[0]);
			//case to 32
			printf("\txor\tebx,ebx\n");
			mem[curr_code_addr++]=_XOR;
			mem[curr_code_addr++]=REG_REG;
			mem[curr_code_addr++]=DWORD;
			mem[curr_code_addr++]=EBX;
			mem[curr_code_addr++]=EBX;
			if(p->opr.op[0]->left_value){//left value
				switch(p->opr.op[0]->len){
				case 1:
					printf("\tmov\tbl,[eax]\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_REGADR;
					mem[curr_code_addr++]=BYTE;
					mem[curr_code_addr++]=EBX;
					mem[curr_code_addr++]=EAX;
					break;
				case 2:
					printf("\tmov\tbx,[eax]\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_REGADR;
					mem[curr_code_addr++]=WORD;
					mem[curr_code_addr++]=EBX;
					mem[curr_code_addr++]=EAX;
					break;
				case 4:
					printf("\tmov\tebx,[eax]\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_REGADR;
					mem[curr_code_addr++]=DWORD;
					mem[curr_code_addr++]=EBX;
					mem[curr_code_addr++]=EAX;
					break;
				}
			}else{//right
				switch(p->opr.op[0]->len){
				case 1:
					printf("\tmov\tbl,al\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_REG;
					mem[curr_code_addr++]=BYTE;
					mem[curr_code_addr++]=EBX;
					mem[curr_code_addr++]=EAX;
					break;
				case 2:
					printf("\tmov\tbx,ax\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_REG;
					mem[curr_code_addr++]=WORD;
					mem[curr_code_addr++]=EBX;
					mem[curr_code_addr++]=EAX;
					break;
				case 4:
					printf("\tmov\tebx,eax\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_REG;
					mem[curr_code_addr++]=DWORD;
					mem[curr_code_addr++]=EBX;
					mem[curr_code_addr++]=EAX;
					break;
				}
			}
			printf("\tpush\tebx\n");
			mem[curr_code_addr++]=PUSH;
			mem[curr_code_addr++]=DWORD;
			mem[curr_code_addr++]=EBX;

			_ex(p->opr.op[1]);
			printf("\txor\tedx,edx\n");
			mem[curr_code_addr++]=_XOR;
			mem[curr_code_addr++]=REG_REG;
			mem[curr_code_addr++]=DWORD;
			mem[curr_code_addr++]=EDX;
			mem[curr_code_addr++]=EDX;
			if(p->opr.op[1]->left_value){//left value
				switch(p->opr.op[1]->len){
				case 1:
					printf("\tmov\tdl,[eax]\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_REGADR;
					mem[curr_code_addr++]=BYTE;
					mem[curr_code_addr++]=EDX;
					mem[curr_code_addr++]=EAX;
					break;
				case 2:
					printf("\tmov\tdx,[eax]\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_REGADR;
					mem[curr_code_addr++]=WORD;
					mem[curr_code_addr++]=EDX;
					mem[curr_code_addr++]=EAX;
					break;
				case 4:
					printf("\tmov\tedx,[eax]\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_REGADR;
					mem[curr_code_addr++]=DWORD;
					mem[curr_code_addr++]=EDX;
					mem[curr_code_addr++]=EAX;
					break;
				}
			}else{//right
				switch(p->opr.op[1]->len){
				case 1:
					printf("\tmov\tdl,al\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_REG;
					mem[curr_code_addr++]=BYTE;
					mem[curr_code_addr++]=EDX;
					mem[curr_code_addr++]=EAX;
					break;
				case 2:
					printf("\tmov\tdx,ax\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_REG;
					mem[curr_code_addr++]=WORD;
					mem[curr_code_addr++]=EDX;
					mem[curr_code_addr++]=EAX;
					break;
				case 4:
					printf("\tmov\tedx,eax\n");
					mem[curr_code_addr++]=MOV;
					mem[curr_code_addr++]=REG_REG;
					mem[curr_code_addr++]=DWORD;
					mem[curr_code_addr++]=EDX;
					mem[curr_code_addr++]=EAX;
					break;
				}
			}
			printf("\tpush\tedx\n");
			mem[curr_code_addr++]=PUSH;
			mem[curr_code_addr++]=DWORD;
			mem[curr_code_addr++]=EDX;
			
			//case to 32 len
			p->len = 4;
			p->left_value = 0;

			switch(p->opr.oper){
			case '+':
				printf("\tadd\n");
				mem[curr_code_addr++]=STACK_ADD;
				break;
			case '-':
				printf("\tsub\n");
				mem[curr_code_addr++]=STACK_SUB;
				break;
			case '*':
				printf("\tmul\n");
				mem[curr_code_addr++]=STACK_MUL;
				break;
			case '/':
				printf("\tdiv\n");
				mem[curr_code_addr++]=STACK_DIV;
				break;
			case '%':
				printf("\tmod\n");
				mem[curr_code_addr++]=STACK_MOD;
				break;
			case '<':
				printf("\tcompLT\n");
				mem[curr_code_addr++]=STACK_LT;
				break;
			case '>':
				printf("\tcompGT\n");
				mem[curr_code_addr++]=STACK_GT;
				break;
			case '&':
				printf("\tand\n");
				mem[curr_code_addr++]=STACK_AND;
				break;
			case '|':
				printf("\tor\n");
				mem[curr_code_addr++]=STACK_OR;
				break;
			case '^':
				printf("\txor\n");
				mem[curr_code_addr++]=STACK_XOR;
				break;
			case GE:
				printf("\tcompGE\n");
				mem[curr_code_addr++]=STACK_GE;
				break;
			case LE:
				printf("\tcompLE\n");
				mem[curr_code_addr++]=STACK_LE;
				break;
			case NE:
				printf("\tcompNE\n");
				mem[curr_code_addr++]=STACK_NE;
				break;
			case EQ:
				printf("\tcompEQ\n");
				mem[curr_code_addr++]=STACK_EQ;
				break;
			case LEFT_SHIFT:
				printf("\tlshift\n");
				mem[curr_code_addr++]=STACK_LSHIFT;
				break;
			case RIGHT_SHIFT:
				printf("\trshift\n");
				mem[curr_code_addr++]=STACK_RSHIFT;
				break;
			}
			printf("\tpop\teax\n");
			mem[curr_code_addr++]=POP;
			mem[curr_code_addr++]=DWORD;
			mem[curr_code_addr++]=EAX;
		
		}
	}

	return 0;
}

int push_param(nodeType *params,symbol *param_sym)
{
	int ret = 0;
	int param_count = 0;
	int i;
	int op_size;
	symbol *sym;
	nodeType *p,*n;
	
	sym = param_sym;
	while(sym){
		param_count++;
		sym = sym->next;
	}

	p = params;
	while(p && param_count){
		sym = param_sym;
		for(i = 1;i<param_count;i++){
			sym = sym->next;
		}
		param_count--;
		op_size = determine_op_size(sym);

		n = p->param.next;

		switch(p->param.type){
		case paramId:
			sym = find_symbol_in_all(p->param.name);
			if(sym->is_global){//global var
				printf("\tmov\teax,%d\n",sym->addr);
				mem[curr_code_addr++]=MOV;
				mem[curr_code_addr++]=REG_INT;
				mem[curr_code_addr++]=DWORD;
				mem[curr_code_addr++]=EAX;
				*(int*)&mem[curr_code_addr]=sym->addr;
				curr_code_addr+=4;
			}else{
				printf("\tmov\teax,ebp\n");
				mem[curr_code_addr++]=MOV;
				mem[curr_code_addr++]=REG_REG;
				mem[curr_code_addr++]=DWORD;
				mem[curr_code_addr++]=EAX;
				mem[curr_code_addr++]=EBP;
				if(sym->is_param){//func param
					printf("\tadd\teax,%d\n",sym->addr+4 + 4);//skip ebp and ret addr
					mem[curr_code_addr++]=ADD;
					mem[curr_code_addr++]=REG_INT;
					mem[curr_code_addr++]=DWORD;
					mem[curr_code_addr++]=EAX;
					*(int*)&mem[curr_code_addr]=sym->addr+4+4;
					curr_code_addr+=4;
				}else{//local var
					printf("\tsub\teax,%d\n",sym->end_addr);
					mem[curr_code_addr++]=SUB;
					mem[curr_code_addr++]=REG_INT;
					mem[curr_code_addr++]=DWORD;
					mem[curr_code_addr++]=EAX;
					*(int*)&mem[curr_code_addr]=sym->end_addr;
					curr_code_addr+=4;
				}
			}
			
			//array id and pointer handle
			if(sym->class==ARRAY){
				printf("\tpush\teax\n");
				mem[curr_code_addr++]=PUSH;
				mem[curr_code_addr++]=DWORD;
				mem[curr_code_addr++]=EAX;

				ret += 4;
				break;
			}

			switch(op_size){
			case 1://byte
				printf("\tmov\tal,[eax]\n");
				mem[curr_code_addr++]=MOV;
				mem[curr_code_addr++]=REG_REGADR;
				mem[curr_code_addr++]=BYTE;
				mem[curr_code_addr++]=EAX;
				mem[curr_code_addr++]=EAX;

				printf("\tpush\tal\n");
				mem[curr_code_addr++]=PUSH;
				mem[curr_code_addr++]=BYTE;
				mem[curr_code_addr++]=EAX;
				
				ret += 1;
				break;
			case 2://word
				printf("\tmov\tax,[eax]\n");
				mem[curr_code_addr++]=MOV;
				mem[curr_code_addr++]=REG_REGADR;
				mem[curr_code_addr++]=WORD;
				mem[curr_code_addr++]=EAX;
				mem[curr_code_addr++]=EAX;

				printf("\tpush\tax\n");
				mem[curr_code_addr++]=PUSH;
				mem[curr_code_addr++]=WORD;
				mem[curr_code_addr++]=EAX;
				
				ret += 2;
				break;
			case 4://dword
				printf("\tmov\teax,[eax]\n");
				mem[curr_code_addr++]=MOV;
				mem[curr_code_addr++]=REG_REGADR;
				mem[curr_code_addr++]=DWORD;
				mem[curr_code_addr++]=EAX;
				mem[curr_code_addr++]=EAX;

				printf("\tpush\teax\n");
				mem[curr_code_addr++]=PUSH;
				mem[curr_code_addr++]=DWORD;
				mem[curr_code_addr++]=EAX;

				ret += 4;
				break;
			}
			break;
		case paramCon:
			switch(op_size){
			case 1://byte
				printf("\tmov\tal,%d\n",p->param.value);
				mem[curr_code_addr++]=MOV;
				mem[curr_code_addr++]=REG_INT;
				mem[curr_code_addr++]=BYTE;
				mem[curr_code_addr++]=EAX;
				*(int*)&mem[curr_code_addr]=p->param.value;
				curr_code_addr+=4;

				printf("\tpush\tal\n");
				mem[curr_code_addr++]=PUSH;
				mem[curr_code_addr++]=BYTE;
				mem[curr_code_addr++]=EAX;
				
				ret += 1;
				break;
			case 2://word
				printf("\tmov\tax,%d\n",p->param.value);
				mem[curr_code_addr++]=MOV;
				mem[curr_code_addr++]=REG_INT;
				mem[curr_code_addr++]=WORD;
				mem[curr_code_addr++]=EAX;
				*(int*)&mem[curr_code_addr]=p->param.value;
				curr_code_addr+=4;

				printf("\tpush\tax\n");
				mem[curr_code_addr++]=PUSH;
				mem[curr_code_addr++]=WORD;
				mem[curr_code_addr++]=EAX;
				
				ret += 2;
				break;
			case 4://dword
				printf("\tmov\teax,%d\n",p->param.value);
				mem[curr_code_addr++]=MOV;
				mem[curr_code_addr++]=REG_INT;
				mem[curr_code_addr++]=DWORD;
				mem[curr_code_addr++]=EAX;
				*(int*)&mem[curr_code_addr]=p->param.value;
				curr_code_addr+=4;

				printf("\tpush\teax\n");
				mem[curr_code_addr++]=PUSH;
				mem[curr_code_addr++]=DWORD;
				mem[curr_code_addr++]=EAX;

				ret += 4;
				break;
			}
			break;
		}
		p = n;
	}

	if(p || param_count){
		return -1;
	}

	return ret;
}

static int determine_op_size(symbol *sym)
{
	int ret = 0;
	switch(sym->type){
	case UINT8: ret = 1;break;
	case UINT16: ret = 2;break;
	case UINT32:
	case VOID:
	case VOID_PTR:
	case UINT8_PTR:
	case UINT16_PTR:
	case UINT32_PTR:
		ret = 4;
		break;
	default:
		printf("determine op size error\n");
		exit(-1);
		break;
	}
	return ret;
}

static void init_global_data_mem()
{
	symbol *sym;
	int i = 0;
	sym = global_symbols;
	while(sym){
		if(sym->class == ARRAY_INIT){
			struct arr_elem *elem = sym->arr_elem;
			i = 0;
			while(elem){
				switch(sym->type){
				case UINT8:
					*(uint8_t*)(mem+i) = elem->elem;
					break;
				case UINT16: 
					*(uint16_t*)(mem+i) = elem->elem;
					break;
				case UINT32:
				case VOID:
				case VOID_PTR:
				case UINT8_PTR:
				case UINT16_PTR:
				case UINT32_PTR:
					*(uint32_t*)(mem+i) = elem->elem;
					break;
				}
				elem = elem->next;
				i++;
			}
		}
		sym = sym->next;
	}
}

static symbol* find_symbol_in_all(char *name)
{
	symbol* sym;
	sym = find_symbol(global_symbols,name);
	if(sym){
		return sym;
	}
	
	sym = find_symbol(curr_func->func.local_sym,name);
	if(sym){ 
		return sym;
	}
	
	sym = find_symbol(curr_func->func.param_sym,name);
	if(sym){
		return sym;
	}
	
	printf("symbol not found %s\n",name);
	exit(-1);
	return NULL;
}
