#include "node.h"

nodeType *id(char *name)
{
	nodeType *p;

	if((p = malloc(sizeof(nodeType))) == NULL)
		return NULL;
	memset(p,0,sizeof(nodeType));

	p->type = typeId;
	strcpy(p->id.name,name);

	return p;
}

nodeType *con(int value)
{
	nodeType *p;

	if((p = malloc(sizeof(nodeType))) == NULL)
		return NULL;
	memset(p,0,sizeof(nodeType));

	p->type = typeCon;
	p->con.value = value;

	return p;
}

nodeType *opr(int oper,int nops,...)
{
	va_list ap;
	nodeType *p;
	int i;
	
	if((p = malloc(sizeof(nodeType))) == NULL)
		return NULL;
	memset(p,0,sizeof(nodeType));
	if((p->opr.op = malloc(nops*sizeof(nodeType*))) == NULL){
		free(p);
		return NULL;
	}
	p->type = typeOpr;
	p->opr.oper = oper;
	p->opr.nops = nops;
	
	va_start(ap,nops);
	for(i = 0;i<nops;i++)
		p->opr.op[i] = va_arg(ap,nodeType*);
	va_end(ap);
	return p;
}

nodeType *id_param(char *name)
{
	nodeType *p;
	if((p = malloc(sizeof(nodeType))) == NULL)
		return NULL;
	memset(p,0,sizeof(nodeType));

	p->type = typeParam;
	p->param.type = paramId;
	strcpy(p->param.name,name);

	return p;
}

nodeType *con_param(int con)
{
	nodeType *p;
	if((p = malloc(sizeof(nodeType))) == NULL)
		return NULL;
	memset(p,0,sizeof(nodeType));

	p->type = typeParam;
	p->param.type = paramCon;
	p->param.value = con;

	return p;
}

void free_nodes(nodeType *p)
{
	if(!p) return ;
	int i = 0;
	
	
	if(p->type == typeOpr){
		for(i = 0;i<p->opr.nops;i++)
			free_nodes(p->opr.op[i]);
		free(p->opr.op);
	}

	if(p->type == typeParam){
		nodeType *pp,*next;
		pp = p->param.next;
		while(pp){
			next = pp->param.next;
			free(pp);
			pp = next;
		}
	}

	if(p->type == typeFunc){
		nodeType *q,*n = p->func.next;
		while(n){
			q =  n->func.next;
			free_nodes(n->func.func_body);
			free_symbols(&n->func.local_sym);
			free_symbols(&n->func.param_sym);
			free(n);
			n = q;
		}

		free_nodes(p->func.func_body);
		free_symbols(&p->func.local_sym);
		free_symbols(&p->func.param_sym);
	}

	free(p);
}

nodeType *func_node(nodeType *func_body,symbol *lsym,symbol *psym,char *name)
{
	nodeType *p;
	if((p = malloc(sizeof(nodeType))) == NULL)
		return NULL;
	memset(p,0,sizeof(nodeType));
	
	p->type = typeFunc;
	p->func.local_sym = lsym;
	p->func.param_sym = psym;
	p->func.func_body = func_body;
	strcpy(p->func.name,name);
	p->func.next = NULL;
	return p;
}
