typedef enum {typeCon,typeId,typeOpr} nodeEnum;

/*constants*/
typedef struct{
	int value;
}conNodeType;

/*identifiers*/
typedef struct{
	int i;
}idNodeType;

/*operators*/
typedef struct{
	int oper;//operator
	int nops;//number of operands
	struct nodeTypeTag **op;//operands
}oprNodeType;

typedef struct nodeTypeTag{
	nodeEnum type;	//type of node
	union{
		conNodeType con;
		idNodeType id;
		oprNodeType opr;
	};
}nodeType;

extern int sym[26];
