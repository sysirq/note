#!/bin/bash

bison -d y.y && flex y.l && gcc lex.yy.c y.tab.c compiler.c -o a.out
