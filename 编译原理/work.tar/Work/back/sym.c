#include "sym.h"
/*
//test
int main(void)
{
	sym_table table = {0};

	symbol *sym = create_sym("lizhixi",0,0);
	if(sym)
		printf("create symbol success(%s)\n",sym->name);

	add_sym_to_table(&table,sym);
	
	sym = find_symbol(&table,"lizhixi");
	if(sym)
		printf("find symbol success(%s)\n",sym->name);
	
	sym = create_sym("renli",0,0);
	add_sym_to_table(&table,sym);
	
	sym = find_symbol(&table,"renli");
	if(sym)
		printf("find symbol success(%s)\n",sym->name);

	free_symbols(&table);
	
	sym = find_symbol(&table,"renli");
	if(!sym)
		printf("find symbol fault\n");

	return 0;
}
*/

symbol *create_sym(char *name,uint32_t type,uint32_t addr)
{
	if(!name)return NULL;

	symbol *sym = (symbol*)malloc(sizeof(symbol));
	if(!sym) return NULL;
	
	memset(sym,0,sizeof(symbol));
	
	sym->type = type;
	sym->addr = addr;
	sym->name = (char*)malloc(strlen(name)+1);
	
	if(!name){
		free(sym);
		return NULL;
	}
	strcpy(sym->name,name);
	return sym;
}

void free_sym(symbol *sym)
{
	if(!sym) return;
	if(sym->name)	free(sym->name);
	free(sym);
}	

void free_symbols(sym_table *table)
{
	if(!table || !table->symbols) return;
	
	symbol *p,*n;

	p = n = table->symbols;

	while(p){
		n = p->next;
		free(p);
		p = n;
	}

	table->symbols = NULL;
}


symbol *find_symbol(sym_table *table,char *name)
{
	if(!table || !table->symbols || !name) return NULL;
	
	symbol *p,*n;
	p = n = table->symbols;

	while(p){
		n = p->next;
		if(!strcmp(p->name,name)) return p;
		p = n;
	}

	return NULL;
}

void add_sym_to_table(sym_table *table,symbol *sym)
{
	if(!table || !sym) return;
	
	if(!table->symbols){
		table->symbols = sym;
		sym->next = NULL;
		return;
	}
	symbol *p,*n;
	p = n = table->symbols;

	while(p){
		n = p->next;
		if(!n) break;
		p = n;
	}

	p->next = sym;
	sym->next = NULL;
}
