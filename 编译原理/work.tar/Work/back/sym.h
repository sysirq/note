#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <malloc.h>


typedef struct symbol{
	uint32_t type;
	char *name;
	uint32_t addr;
	struct symbol * next;
}symbol;

typedef struct symbol_table{
	symbol * symbols;
}sym_table;

symbol *create_sym(char *name,uint32_t type,uint32_t addr);
void free_sym(symbol *sym);

void free_symbols(sym_table *table);
symbol *find_symbol(sym_table *table,char *name);
void add_sym_to_table(sym_table *table,symbol *sym);


