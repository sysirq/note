#!/bin/bash

bison -d -v y.y && flex y.l && gcc lex.yy.c y.tab.c sym.c node.c compiler.c -o a.out && cat prog | ./a.out
