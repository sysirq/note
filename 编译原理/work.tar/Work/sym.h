#ifndef _MY_SYM_H_
#define _MY_SYM_H_

#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <malloc.h>

#define SYM_STR_MAX_LEN 255

#define VOID		0x0
#define UINT8		0x1
#define UINT16		0x2
#define UINT32		0x3

#define VOID_PTR	0x100
#define UINT8_PTR	0x101
#define UINT16_PTR	0x102
#define UINT32_PTR	0x103

#define FUNC		0x200
#define VAR		0x201
#define VAR_PTR		0x202
#define ARRAY		0x203
#define ARRAY_INIT	0x204

typedef struct arr_elem{
	uint32_t elem;
	struct arr_elem *next;
}arr_elem;

typedef struct symbol{
	uint32_t type;
	uint32_t class;
	char *name;
	uint32_t addr;
	uint32_t end_addr;

	uint32_t arr_len;
	struct arr_elem *arr_elem;
	
	struct symbol * next;
	struct symbol * param_sym;
	int is_global;
	int is_param;
}symbol;


symbol *create_sym(char *name,uint32_t type);
void free_sym(symbol *sym);

void free_symbols(symbol **symbols);
symbol *find_symbol(symbol *symbols,char *name);

symbol *create_func_sym(char *name,uint32_t type,symbol *param_sym);
symbol *create_var_sym(char *name,uint32_t type);
symbol *create_var_ptr_sym(char *name,uint32_t type);
symbol *create_arr_sym(char *name,uint32_t type,int len);
symbol *create_arr_init_sym(char *name,uint32_t type,int len,struct arr_elem *arr_elems);

arr_elem* create_arr_elem();

symbol *check_sym_dup(symbol *symbols);

void gen_symbols_addr(symbol *sym);
int get_symbols_max_end_addr(symbol *sym);
symbol *global_symbols;
symbol *local_symbols;

#endif
