#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <malloc.h>

uint8_t flag_decode[] = "Pasd@wqd&12qwe@23(*?&";

uint8_t flag_encode[22] = { 0x54, 0xBB, 0x73, 0xF1, 0x10, 0x17, 0xEC, 0xE, 0x8D, 0xE5, 0xD, 0x97, 0xB, 0xE2, 0xED, 0xAA, 0xE4, 0x14, 0x8B, 0xAA, 0x22 ,0x00};

uint32_t flag_len = sizeof(flag_decode)-1;

void encryption(uint8_t *flag, uint8_t *str);

void decode(uint8_t *str, uint8_t *flag,uint32_t len);

void print_hex(uint8_t *str,uint32_t len);

void check(uint8_t *user_input);

int main(void)
{
	uint8_t flag_input[256] = {0};
	decode(flag_encode, flag_input, 21);
	printf("%s\n",flag_input);
	return 0;
}

void check(uint8_t *user_input)
{
	uint32_t len;
	uint32_t real_len;
	uint8_t * str;
	uint32_t i;
	uint8_t error_str[7];
	uint8_t right_str[7];

	error_str[0] = 0x65;
	error_str[1] = 0x72;
	error_str[2] = 0x72;
	error_str[3] = 0x6F;
	error_str[4] = 0x72;
	error_str[5] = 0x0A;
	error_str[6] = 0x00;

	right_str[0] = 0x72;
	right_str[1] = 0x69;
	right_str[2] = 0x67;
	right_str[3] = 0x68;
	right_str[4] = 0x74;
	right_str[5] = 0x0A;
	right_str[6] = 0x00;

	len = 0;
	real_len = 21;
	str = 0;
	i = 0;

	for (i = 0; user_input[i]; i = i + 1) {
		len = len + 1;
	}

	str = (uint8_t*)malloc(len + 1);
	memset(str, 0, len + 1);

	encryption(user_input, str);

	for (i = 0; i < len && i < real_len; i = i + 1) {
		if (str[i] != flag_encode[i]) {
			break;
		}
	}

	if (i != real_len || len != real_len) {
		puts((const char *)error_str);
	}
	else {
		puts((const char *)right_str);
	}
}

/*
void check(uint8_t *user_input)
{
	uint32_t len;
	uint32_t real_len;
	uint8_t * str;
	uint32_t i;

	len = 0;
	real_len = 21;
	str = 0;
	i = 0;

	for (i = 0; user_input[i]; i = i +1) {
		len = len + 1;
	}
	
	str = (uint8_t*)malloc(len+1);
	memset(str, 0, len + 1);

	encryption(user_input, str);

	for (i = 0; i < len && i < real_len; i = i+1) {
		if (str[i] != flag_encode[i]){
			break;
		}
	}

	if (i != real_len || len != real_len) {
		printf("error\n");
	}
	else {
		printf("right\n");
	}
}
*/

void encryption(uint8_t *flag, uint8_t *str)
{
	uint32_t i;
	uint32_t k;
	uint32_t j;
	uint16_t v;
	uint32_t len;
	
	len = 0;

	for (i = 0; flag[i]; i = i+1) {
		str[i] = flag[i] + i + 4;
		len = len + 1;
	}
	str[i] = 0;


	for (i = 0; i < len; i = i + 1) {
		str[i] = str[i] ^ i;
	}


	for (i = 0; i < len; i = i+1) {
		k = i % 9;
		str[i] = str[i] << k | str[i] >> (8 - k);
	}

	for (i = 0; i < len; i = i + j)
	{
		k = i % 2;
		j = k + 1;

		if (j == 1) {
			*(str + i) = *(str + i) ^ ((i * 42) % 255);
		}

		if (j == 2) {
			if (i + 1 >= len) {
				break;
			}
			v = *(uint16_t*)(str + i);
			*(uint16_t*)(str + i) = ((v & 0x3C0) << 6) | (v & 0xFC00) >> 10 | (v & 0x3F) << 6;
		}
	}
}

void print_hex(uint8_t *str, uint32_t len)
{
	printf("{");

	for (uint32_t i = 0; i < len; i++)
	{
		if (str[i + 1]) {
			printf("0x%X,", str[i]);
		}
		else {
			printf("0x%X", str[i]);
		}
	}

	printf("}\n");
}

void decode(uint8_t *str, uint8_t *flag,uint32_t len)
{
	uint32_t i;
	uint32_t j;
	uint32_t k;
	uint16_t v;

	for (i = 0; i<len; i+=j) {
		k = i % 2;
		j = k + 1;

		if (j == 1) {
			*(flag + i) = *(str + i) ^ ((i * 42) % 255);
		}

		if (j == 2) {
			if (i + 1 >= len) {
				break;
			}
			v = *(uint16_t*)(str + i);
			*(uint16_t*)(flag + i) = ((v & 0xFC0) >> 6) | (v & 0xF000) >> 6 | (v & 0x3F) << 10;
		}
	}

	for (i = 0; i < len; i++) {
		k = i % 9;
		flag[i] = flag[i] >> k | flag[i] << (8 - k);
	}

	for (i = 0; i < len; i++) {
		flag[i] = flag[i] ^ i;
	}

	for (i = 0; i<len; i++) {
		flag[i] = flag[i] - i - 4;
	}
	str[i] = 0;
}