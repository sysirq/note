package com.oxkernel.byakugan.view;

import com.oxkernel.byakugan.base.BaseView;

/**
 * Created by i-lizhixi on 2018/3/26.
 */

public interface SignUpView extends BaseView {
    String getUserName();
    String getMailAddr();
    String getPaswd();
    String getPaswdConfirm();

    void showSignProgressDialog();
    void closeSignProgressDialog();
}
