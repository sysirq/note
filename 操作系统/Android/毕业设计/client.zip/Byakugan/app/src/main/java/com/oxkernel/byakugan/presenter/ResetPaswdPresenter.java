package com.oxkernel.byakugan.presenter;

import android.content.Context;

import com.oxkernel.byakugan.base.BasePresenter;
import com.oxkernel.byakugan.base.MyTools;
import com.oxkernel.byakugan.view.ResetPaswdView;

/**
 * Created by 31222 on 2018/3/27.
 */

public class ResetPaswdPresenter extends BasePresenter<ResetPaswdView> {
    private Context mContext;

    public ResetPaswdPresenter(Context mContext){
        this.mContext = mContext;
    }

    public void doResetPaswd(){
        String mail = mvpView.getMailAddr();
        if(!MyTools.isEmail(mail)){
            mvpView.showToast("请确保邮件地址的合法性");
            return ;
        }

        mvpView.showToast("密码已发送至您的邮件，请注意查收");
    }
}
