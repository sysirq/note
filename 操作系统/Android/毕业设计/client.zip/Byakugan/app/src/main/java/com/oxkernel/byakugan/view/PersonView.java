package com.oxkernel.byakugan.view;

import android.content.Intent;

import com.oxkernel.byakugan.base.BaseView;

/**
 * Created by 31222 on 2018/3/27.
 */

public interface PersonView extends BaseView {
    void setLoginedName(String name);
    void setHeadImage(String addr);
    void new_message(int b);
}
