package com.oxkernel.byakugan.base;

/**
 * Created by i-lizhixi on 2018/3/22.
 */

public interface Callback <T>{
    //数据请求成功(data 为请求到的数据)
    void onSucess(T data);

    //错误结果
    void onFailure(String msg);

    //请求数据失败
    void onError();
    
    //请求数据结束时
    void onComplete();
}
