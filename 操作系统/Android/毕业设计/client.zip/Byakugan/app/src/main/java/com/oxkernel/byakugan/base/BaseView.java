package com.oxkernel.byakugan.base;

import android.content.Context;

/**
 * Created by i-lizhixi on 2018/3/22.
 */

public interface BaseView {
    void showToast(String msg);
}
