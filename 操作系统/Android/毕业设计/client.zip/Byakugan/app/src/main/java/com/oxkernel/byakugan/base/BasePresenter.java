package com.oxkernel.byakugan.base;

import rx.subscriptions.CompositeSubscription;

/**
 * Created by i-lizhixi on 2018/3/22.
 */

public class BasePresenter<V extends BaseView> {
    //view
    protected V mvpView;
    private CompositeSubscription mCompositeSubscription;
    //绑定view
    public void attachView(V mvpView){
        this.mvpView = mvpView;
    }

    //断开view
    public void detachView(){
        this.mvpView = null;
        onUnsubscribe();
    }

    //测试该view是否断开
    public boolean isViewAttached(){
        return mvpView!=null;
    }

    public V getView(){
        return mvpView;
    }

    public void onUnsubscribe(){
        if(mCompositeSubscription != null && mCompositeSubscription.hasSubscriptions()){
            mCompositeSubscription.unsubscribe();
        }
    }

    public CompositeSubscription getSubscription(){
        if(mCompositeSubscription == null){
            mCompositeSubscription = new CompositeSubscription();
        }
        return mCompositeSubscription;
    }
}
