package com.oxkernel.byakugan.view;

import com.oxkernel.byakugan.base.BaseView;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by 31222 on 2018/3/28.
 */

public interface ArticleListView extends BaseView {
    void addItems(ArrayList<HashMap<String,Object>> items);
    void notifyListAdapterDataChange();
    void setTotalCount(int count);

    void loadMoreData();
    void loadComplete();

    void setRefreshing(Boolean b);//下拉刷新状态设置

    void clearItems();//清除已经从服务器获得的数据
}
