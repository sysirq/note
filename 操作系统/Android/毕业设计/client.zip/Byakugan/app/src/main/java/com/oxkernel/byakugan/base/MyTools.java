package com.oxkernel.byakugan.base;

import android.text.TextUtils;

import com.oxkernel.byakugan.file.FileHelper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by i-lizhixi on 2018/3/26.
 */

public class MyTools {
    public static String baseUrl = baseUrl = "http://192.168.191.1:2333/";

    public static String session_id = null;
    public static String session_file_name = "session";
    //public static Boolean isLogin = false;//尽在 Login 返回 Person 使用

    public final static String BUG_LIST_ITEM_TITLE = "ItemTitle";
    public final static String BUG_LIST_ITEM_SOURCE = "ItemSource";
    public final static String BUG_LIST_ITEM_TIME = "ItemTime";
    public final static String BUG_LIST_ITEM_DESCRIPTION = "ItemDescription";
    public final static String BUG_LIST_ITEM_ID = "ItemID";

    public final static String INTENT_SOURCE="source";
    public final static String INTENT_ID="id";
    public final static String INTENT_TITLE="title";
    public final static String INTENT_COMMENT_ID="comment_id";

    public static boolean isEmail(String strEmail) {
        String strPattern = "^[a-zA-Z0-9][\\w\\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\\w\\.-]*[a-zA-Z0-9]\\.[a-zA-Z][a-zA-Z\\.]*[a-zA-Z]$";
        if (TextUtils.isEmpty(strPattern)) {
            return false;
        } else {
            return strEmail.matches(strPattern);
        }
    }

    public static boolean fileIsExists(String strFile)
    {
        try
        {
            File f=new File(strFile);
            if(!f.exists())
            {
                return false;
            }

        }
        catch (Exception e)
        {
            return false;
        }

        return true;
    }
}
