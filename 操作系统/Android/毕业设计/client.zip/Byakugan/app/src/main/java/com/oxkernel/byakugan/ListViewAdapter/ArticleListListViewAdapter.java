package com.oxkernel.byakugan.ListViewAdapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.oxkernel.byakugan.R;
import com.oxkernel.byakugan.base.MyTools;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by 31222 on 2018/3/28.
 */

public class ArticleListListViewAdapter extends BaseAdapter {
    private ArrayList<HashMap<String,Object>> items;
    private LayoutInflater mInflater;

    public ArticleListListViewAdapter(Context context, ArrayList<HashMap<String,Object>> items){
        this.items = items;
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if(convertView == null){
            convertView = mInflater.inflate(R.layout.list_view_article_list_item,null);
            holder = new ViewHolder();
            holder.title = convertView.findViewById(R.id.article_list_list_view_title);
            holder.source = convertView.findViewById(R.id.article_list_list_view_source);
            holder.time = convertView.findViewById(R.id.article_list_list_view_time);
            holder.description = convertView.findViewById(R.id.article_list_list_view_description);

            convertView.setTag(holder);
        }
        else{
            holder = (ViewHolder) convertView.getTag();
        }

        holder.title.setText(items.get(position).get(MyTools.BUG_LIST_ITEM_TITLE).toString());
        holder.source.setText(items.get(position).get(MyTools.BUG_LIST_ITEM_SOURCE).toString());
        holder.time.setText(items.get(position).get(MyTools.BUG_LIST_ITEM_TIME).toString());
        holder.description.setText(items.get(position).get(MyTools.BUG_LIST_ITEM_DESCRIPTION).toString());

        return convertView;
    }

    public class ViewHolder{
        public TextView title;
        public TextView source;
        public TextView time;
        public TextView description;
    }
}
