package com.oxkernel.byakugan.entity;

/**
 * Created by 31222 on 2018/4/6.
 */

public class ServerReturnDetail {
    private String content;
    private int isCollection;
    private int collectionCount;
    private int isComment;
    private int commentCount;
    private int code;
    private String msg;

    public void setCollectionCount(int count){
        collectionCount = count;
    }
    public int getCollectionCount(){
        return collectionCount;
    }

    public void setIsComment(int b){
        isComment = b;
    }

    public int getIsComment(){
        return isComment;
    }

    public void setCode(int code){
        this.code = code;
    }

    public int getCode(){
        return code;
    }

    public void setMsg(String msg){
        this.msg = msg;
    }

    public String getMsg(){
        return msg;
    }

    public void setCommentCount(int count){
        commentCount = count;
    }

    public int getCommentCount(){
        return commentCount;
    }

    public void setIsCollection(int isCollection){
        this.isCollection = isCollection;
    }

    public int getIsCollection(){
        return isCollection;
    }

    public void setContent(String content){
        this.content = content;
    }

    public String getContent(){
        return content;
    }
}
