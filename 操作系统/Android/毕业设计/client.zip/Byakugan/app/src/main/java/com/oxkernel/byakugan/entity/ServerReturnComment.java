package com.oxkernel.byakugan.entity;

import java.util.List;

/**
 * Created by 31222 on 2018/4/7.
 */

public class ServerReturnComment {
    private int code;
    private String msg;
    private int totalCount;
    private List<ServerReturnComment.Comment> comments;

    public void setTotalCount(int count){
        totalCount = count;
    }
    public int getTotalCount(){
        return totalCount;
    }

    public void setCode(int code){
        this.code = code;
    }

    public int getCode(){
        return code;
    }

    public void setMsg(String msg){
        this.msg = msg;
    }

    public String getMsg(){
        return msg;
    }

    public void setComments(List<ServerReturnComment.Comment>  c){
        comments = c;
    }

    public List<ServerReturnComment.Comment> getComments(){
        return comments;
    }

    public static class Comment{
        private int code;
        private String msg;
        private String head_addr;
        private String name;
        private String content;
        private String time;
        private String comment_id;
        private int replyCount;
        private List<ServerReturnComment.Comment.Reply> replys;

        public void setCode(int code){
            this.code = code;
        }

        public int getCode(){
            return code;
        }

        public void setMsg(String msg){
            this.msg = msg;
        }

        public String getMsg(){
            return msg;
        }

        public int getReplyCount(){
            return replyCount;
        }

        public void setReplyCount(int count){
            replyCount = count;
        }

        public String getComment_id(){
            return comment_id;
        }

        public void setComment_id(String id){
            comment_id = id;
        }

        public void setHead_addr(String head){
            head_addr = head;
        }

        public String getHead_addr(){
            return head_addr;
        }

        public void setName(String name){
            this.name = name;
        }

        public String getName(){
            return name;
        }

        public void setContent(String content){
            this.content = content;
        }

        public String getContent(){
            return content;
        }

        public void setTime(String time){
            this.time = time;
        }

        public String getTime(){
            return time;
        }

        public void setReplys(List<ServerReturnComment.Comment.Reply> replys){
            this.replys = replys;
        }

        public List<ServerReturnComment.Comment.Reply> getReplys(){
            return replys;
        }

        public static class Reply{
            private String from_head;
            private String to_head;
            private String from_user;
            private String to_user;
            private String content;
            private String time;

            public void setFrom_head(String head){
                from_head = head;
            }
            public String getFrom_head(){
                return from_head;
            }

            public void setTo_head(String head){
                to_head = head;
            }

            public String getTo_head(){
                return to_head;
            }

            public void setFrom_user(String user){
                from_user = user;
            }

            public String getFrom_user(){
                return from_user;
            }

            public void setTo_user(String user){
                to_user = user;
            }

            public String getTo_user(){
                return to_user;
            }

            public void setContent(String content){
                this.content = content;
            }

            public String getContent(){
                return content;
            }

            public void setTime(String time){
                this.time = time;
            }

            public String getTime(){
                return time;
            }
        }
    }
}
