package com.oxkernel.byakugan.view;

import com.oxkernel.byakugan.base.BaseView;

/**
 * Created by 31222 on 2018/4/6.
 */

public interface DetailView extends BaseView {
    void loadContent(String content);//加载内容
    void setCollection(int b,int count);//设置是否已收藏,和收藏数
    void setComment(int b,int count);//设置是否已评论,和评论数
}
