package com.oxkernel.byakugan.ui;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.oxkernel.byakugan.ListViewAdapter.MyCollectionListViewAdapter;
import com.oxkernel.byakugan.ListViewAdapter.MyCommentListViewAdapter;
import com.oxkernel.byakugan.R;
import com.oxkernel.byakugan.base.MyTools;
import com.oxkernel.byakugan.entity.ServerReturnMyCollection;
import com.oxkernel.byakugan.entity.ServerReturnMyComment;
import com.oxkernel.byakugan.presenter.MyCollectionPresenter;
import com.oxkernel.byakugan.presenter.MyCommentPresenter;
import com.oxkernel.byakugan.view.MyCollectionView;
import com.oxkernel.byakugan.view.MyCommentView;

import java.util.ArrayList;

/**
 * Created by 31222 on 2018/4/9.
 */

public class MyCommentActivity extends AppCompatActivity implements View.OnClickListener,MyCommentView,AbsListView.OnScrollListener,AdapterView.OnItemClickListener,SwipeRefreshLayout.OnRefreshListener{
    private Toolbar myToolbar;
    private ImageView returnImageView;

    private SwipeRefreshLayout swipeRefreshLayout;
    private ListView commentListView;
    private View moreView;

    private ArrayList<ServerReturnMyComment.Comment> items = new ArrayList<ServerReturnMyComment.Comment>();
    private MyCommentListViewAdapter myAdapter;
    private int totalCount = 0;
    private Boolean isBottom;//到底部了

    private MyCommentPresenter presenter;

    protected void onCreate(Bundle savedInstanceState) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {//沉浸式设置
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_comment);

        presenter = new MyCommentPresenter(this);
        presenter.attachView(this);

        initViews();

        presenter.doFirstGetComments();
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        presenter.detachView();
    }

    public void initViews(){
        myToolbar = findViewById(R.id.my_toolbar_my_comment);
        myToolbar.setTitle("");
        setSupportActionBar(myToolbar);

        swipeRefreshLayout = this.findViewById(R.id.my_comment_list_refreshLayout);
        swipeRefreshLayout.setColorSchemeColors(android.R.color.holo_blue_bright,android.R.color.holo_orange_light,android.R.color.holo_green_light);
        swipeRefreshLayout.setOnRefreshListener(this);

        returnImageView = findViewById(R.id.my_comment_image_return);
        returnImageView.setOnClickListener(this);

        moreView =  moreView = getLayoutInflater().inflate(R.layout.list_view_my_comment_more_data,null);
        moreView.setVisibility(View.GONE);

        commentListView = findViewById(R.id.my_comment_list_view);
        commentListView.addFooterView(moreView,null,false);

        myAdapter = new MyCommentListViewAdapter(this,items);

        commentListView.setAdapter(myAdapter);
        commentListView.setOnScrollListener(this);
        commentListView.setOnItemClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.my_comment_image_return:
                finish();
                break;
        }
    }

    @Override
    public void showToast(String msg) {
        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void addItem(ServerReturnMyComment.Comment item) {//向List适配器中添加新数据
        this.items.add(item);
    }

    @Override
    public void setTotalCount(int n) {
        totalCount = n;
    }

    @Override
    public void notifyListAdapterDataChange() {
        myAdapter.notifyDataSetChanged();
    }

    @Override
    public void loadMoreData() {
        moreView.setVisibility(View.VISIBLE);
    }

    @Override
    public void loadComplete() {
        moreView.setVisibility(View.GONE);
    }

    @Override
    public int getTotalCount() {
        return totalCount;
    }


    @Override
    public void setRefreshing(Boolean b) {
        if(b == true) {

        }
        else{
            swipeRefreshLayout.setRefreshing(b);
        }
    }

    @Override
    public void clearItems() {
        items.clear();
    }

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {
        if(scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE){
            if(isBottom && totalCount > items.size()){
                //下载更多数据
                presenter.doGetItems(items.size());
            }
            if(isBottom && totalCount == items.size()){
                showToast("已经全部加载完毕");
            }
        }
    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
        if(firstVisibleItem + visibleItemCount == totalItemCount){
            isBottom = true;
        }
        else{
            isBottom = false;
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        String article_id = items.get(position).getArticle_id();
        Intent intent = new Intent(this,CommentActivity.class);
        intent.putExtra(MyTools.INTENT_ID,article_id);
        startActivity(intent);
    }

    @Override
    public void onRefresh() {
        presenter.doRefresh();
    }
}
