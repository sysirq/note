package com.oxkernel.byakugan.entity;

import java.util.List;

/**
 * Created by 31222 on 2018/4/9.
 */

public class ServerReturnMyComment {
    private int code;
    private String msg;
    private int totalCount;
    private List<ServerReturnMyComment.Comment> comments;

    public void setTotalCount(int n){
        totalCount = n;
    }

    public int getTotalCount(){
        return totalCount;
    }

    public void setCode(int n){
        code = n;
    }

    public int getCode(){
        return code;
    }

    public void setMsg(String str){
        msg = str;
    }

    public String getMsg(){
        return msg;
    }

    public void setComments(List<ServerReturnMyComment.Comment> c){
        comments = c;
    }

    public List<ServerReturnMyComment.Comment> getComments(){
        return comments;
    }

    public static class Comment {
        String comment_id;
        String from_u;
        String article_id;
        String time;
        String content;
        String title;

        public String getComment_id() {
            return comment_id;
        }

        public String getFrom_u() {
            return from_u;
        }

        public String getArticle_id() {
            return article_id;
        }

        public String getTime() {
            return time;
        }

        public String getContent() {
            return content;
        }

        public String getTitle() {
            return title;
        }

        public void setComment_id(String comment_id) {
            this.comment_id = comment_id;
        }

        public void setFrom_u(String from_u) {
            this.from_u = from_u;
        }

        public void setArticle_id(String article_id) {
            this.article_id = article_id;
        }

        public void setTime(String time) {
            this.time = time;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public void setTitle(String title) {
            this.title = title;
        }
    }
}
