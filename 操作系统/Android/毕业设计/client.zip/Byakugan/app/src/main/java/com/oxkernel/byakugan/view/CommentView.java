package com.oxkernel.byakugan.view;

import com.oxkernel.byakugan.base.BaseView;
import com.oxkernel.byakugan.entity.ServerReturnComment;

/**
 * Created by 31222 on 2018/4/7.
 */

public interface CommentView extends BaseView {
    void showCommentDialog();
    void showReplayDialog(String to_user);
    void addItem(ServerReturnComment.Comment item);
    void setTotalCount(int n);
    void notifyListAdapterDataChange();

    void loadMoreData();
    void loadComplete();

    int getTotalCount();

    void setRefreshing(Boolean b);

    void clearItems();
}
