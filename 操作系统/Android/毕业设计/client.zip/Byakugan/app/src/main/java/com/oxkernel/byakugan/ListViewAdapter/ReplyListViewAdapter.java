package com.oxkernel.byakugan.ListViewAdapter;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.oxkernel.byakugan.R;
import com.oxkernel.byakugan.base.MyTools;
import com.oxkernel.byakugan.entity.ServerReturnComment;
import com.oxkernel.byakugan.presenter.CommentPresenter;
import com.oxkernel.byakugan.presenter.ReplyPresenter;
import com.oxkernel.byakugan.view.CommentView;
import com.oxkernel.byakugan.view.ReplyView;

import java.util.ArrayList;

import jp.wasabeef.glide.transformations.CropCircleTransformation;

/**
 * Created by 31222 on 2018/4/8.
 */

public class ReplyListViewAdapter extends BaseAdapter {
    private Context mContext;
    private ArrayList<ServerReturnComment.Comment.Reply> items;
    private LayoutInflater mInflater;
    private ReplyView replyView;
    private ReplyPresenter replyPresenter;

    public ReplyListViewAdapter(Context context, ArrayList<ServerReturnComment.Comment.Reply>  items,ReplyView replyView,ReplyPresenter replyPresenter){
        this.items = items;
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mContext = context;

        this.replyView = replyView;
        this.replyPresenter =replyPresenter;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if(convertView == null){
            convertView = mInflater.inflate(R.layout.list_view_reply_item,null);
            holder = new ViewHolder();

            holder.from_head = convertView.findViewById(R.id.h_head_reply_from);
            holder.to_head = convertView.findViewById(R.id.h_head_reply_to);

            holder.from_user = convertView.findViewById(R.id.reply_name_from);
            holder.to_user = convertView.findViewById(R.id.reply_name_to);

            holder.reply = convertView.findViewById(R.id.reply_button);

            holder.content = convertView.findViewById(R.id.reply_content);
            holder.time = convertView.findViewById(R.id.reply_time);

            convertView.setTag(holder);
        }
        else{
            holder =  (ViewHolder)convertView.getTag();
        }

        final ServerReturnComment.Comment.Reply item = items.get(position);

        //头像设置
        if(item.getFrom_head().equals("")){
            Glide.with(mContext).load(R.drawable.default_head).bitmapTransform(new CropCircleTransformation(mContext)).into((ImageView) holder.from_head);
        }
        else{
            Glide.with(mContext).load(MyTools.baseUrl+"head/"+item.getFrom_head()).bitmapTransform(new CropCircleTransformation(mContext)).into((ImageView) holder.from_head);
        }

        if(item.getTo_head().equals("")){
            Glide.with(mContext).load(R.drawable.default_head).bitmapTransform(new CropCircleTransformation(mContext)).into((ImageView) holder.to_head);
        }
        else{
            Glide.with(mContext).load(MyTools.baseUrl+"head/"+item.getTo_head()).bitmapTransform(new CropCircleTransformation(mContext)).into((ImageView) holder.to_head);
        }

        holder.from_user.setText(item.getFrom_user());
        holder.to_user.setText(item.getTo_user());
        holder.content.setText(item.getContent());
        holder.time.setText(item.getTime());

        holder.reply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final EditText editText = new EditText(mContext);
                AlertDialog.Builder inputDialog = new AlertDialog.Builder(mContext);
                inputDialog.setTitle("回复评论").setView(editText);
                inputDialog.setPositiveButton("确定",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                replyPresenter.setReply(replyView.getComment_id(),item.getFrom_user(),editText.getText().toString());
                            }
                        }).show();
            }
        });

        return convertView;
    }

    public class ViewHolder{
        public ImageView from_head;
        public TextView from_user;
        public ImageView to_head;
        public TextView to_user;
        public TextView reply;
        public TextView content;
        public TextView time;
    }
}
