package com.oxkernel.byakugan.entity;

/**
 * Created by 31222 on 2018/4/6.
 */

public class ServerReturnCollection {
    private int code;
    private String msg;
    private int collectionCount;
    private int isCollection;

    public void setIsCollection(int isCollection){
        this.isCollection = isCollection;
    }

    public int getIsCollection(){
        return isCollection;
    }

    public void setCollectionCount(int count){
        collectionCount = count;
    }
    public int getCollectionCount(){
        return collectionCount;
    }

    public void setCode(int code){
        this.code = code;
    }

    public int getCode(){
        return code;
    }

    public void setMsg(String msg){
        this.msg = msg;
    }

    public String getMsg(){
        return msg;
    }
}
