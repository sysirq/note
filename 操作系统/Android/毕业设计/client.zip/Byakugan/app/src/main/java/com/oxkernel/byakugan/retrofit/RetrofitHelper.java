package com.oxkernel.byakugan.retrofit;

import android.content.Context;

import com.google.gson.GsonBuilder;
import com.oxkernel.byakugan.base.MyTools;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Created by i-lizhixi on 2018/3/23.
 * 用于retrofit的初始化
 */


public class RetrofitHelper {
    private static String baseUrl = MyTools.baseUrl;
    private Context mContext;
    private Retrofit mRetrofit = null;

    private OkHttpClient client = new OkHttpClient();
    private GsonConverterFactory factory = GsonConverterFactory.create(new GsonBuilder().create());
    private static RetrofitHelper instance = null;

    private RetrofitHelper(Context context) {
        mContext = context;
        init();
    }

    public static RetrofitHelper getInstance(Context context){
        if(instance == null){
            instance = new RetrofitHelper(context);
        }
        return instance;
    }

    private void init(){
        resetApp();
    }

    private void resetApp(){
        mRetrofit = new Retrofit.Builder()
                .baseUrl(baseUrl)
                .client(client)
                .addConverterFactory(factory)
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .build();
    }

    public RetrofitService getServer(){
        return mRetrofit.create(RetrofitService.class);
    }
}

