package com.oxkernel.byakugan.ListViewAdapter;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.oxkernel.byakugan.R;
import com.oxkernel.byakugan.base.MyTools;
import com.oxkernel.byakugan.entity.ServerReturnComment;
import com.oxkernel.byakugan.presenter.CommentPresenter;
import com.oxkernel.byakugan.view.CommentView;

import java.util.ArrayList;
import java.util.HashMap;

import jp.wasabeef.glide.transformations.CropCircleTransformation;

/**
 * Created by 31222 on 2018/4/7.
 */

public class CommentListViewAdapter extends BaseAdapter {
    private ArrayList<ServerReturnComment.Comment> items;
    private LayoutInflater mInflater;
    private Context mContext;
    private CommentView commentView;
    private CommentPresenter commentPresenter;

    public CommentListViewAdapter(Context context, ArrayList<ServerReturnComment.Comment> items,CommentView commentView,CommentPresenter presenter){
        this.items = items;
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mContext = context;
        this.commentView = commentView;
        this.commentPresenter = presenter;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if(convertView == null){
            convertView = mInflater.inflate(R.layout.list_view_comment_item,null);
            holder = new ViewHolder();
            holder.head = convertView.findViewById(R.id.h_head_comment);
            holder.name = convertView.findViewById(R.id.comment_name);
            holder.reply = convertView.findViewById(R.id.comment_reply);
            holder.content = convertView.findViewById(R.id.comment_content);
            holder.time = convertView.findViewById(R.id.comment_time);
            holder.replyCount = convertView.findViewById(R.id.comment_reply_count);
            convertView.setTag(holder);
        }
        else{
            holder = (ViewHolder) convertView.getTag();
        }

        final ServerReturnComment.Comment item = items.get(position);

        //头像设置
        if(item.getHead_addr().equals("")){
            Glide.with(mContext).load(R.drawable.default_head).bitmapTransform(new CropCircleTransformation(mContext)).into((ImageView) holder.head);
        }
        else{
            Glide.with(mContext).load(MyTools.baseUrl+"head/"+item.getHead_addr()).bitmapTransform(new CropCircleTransformation(mContext)).into((ImageView) holder.head);
        }
        holder.name.setText(item.getName());
        holder.content.setText(item.getContent());
        holder.time.setText(item.getTime());
        holder.replyCount.setText("评论数("+item.getReplyCount()+")");
        holder.reply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final EditText editText = new EditText(mContext);
                AlertDialog.Builder inputDialog = new AlertDialog.Builder(mContext);
                inputDialog.setTitle("回复评论").setView(editText);
                inputDialog.setPositiveButton("确定",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                commentPresenter.setReply(item.getComment_id(),item.getName(),editText.getText().toString());
                            }
                        }).show();
            }
        });

        return convertView;
    }

    public class ViewHolder{
        public ImageView head;
        public TextView name;
        public TextView reply;
        public TextView content;
        public TextView time;
        public TextView replyCount;
    }
}
