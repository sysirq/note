package com.oxkernel.byakugan.presenter;

import android.content.Context;

import com.oxkernel.byakugan.base.BasePresenter;
import com.oxkernel.byakugan.base.MyTools;
import com.oxkernel.byakugan.entity.ServerReturnComment;
import com.oxkernel.byakugan.entity.ServerReturnMyCollection;
import com.oxkernel.byakugan.manager.DataManager;
import com.oxkernel.byakugan.view.MyCollectionView;

import java.util.List;

import rx.Observer;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by 31222 on 2018/4/9.
 */

public class MyCollectionPresenter extends BasePresenter<MyCollectionView> {
    private Context mContext;
    private DataManager manager;
    private static int count = 20;//每次请求的数量

    public MyCollectionPresenter(Context mContext){
        this.mContext = mContext;
        manager = new DataManager(mContext);
    }

    public void doFirstGetCollections(){
        getSubscription().add(manager.getMyCollection(MyTools.session_id, 0,count)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ServerReturnMyCollection>() {
                    ServerReturnMyCollection serverReturn;
                    @Override
                    public void onCompleted() {
                        if(serverReturn.getCode()==0){
                            List<ServerReturnMyCollection.Collection> data = serverReturn.getCollections();
                            for(int i=0;data!= null && i<data.size();i++){
                                mvpView.addItem(data.get(i));
                            }
                            mvpView.setTotalCount(serverReturn.getTotalCount());
                            mvpView.notifyListAdapterDataChange();
                        }
                        else{
                            mvpView.showToast(serverReturn.getMsg());
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        mvpView.showToast("请求失败");
                    }

                    @Override
                    public void onNext(ServerReturnMyCollection serverReturnComment) {
                        serverReturn = serverReturnComment;
                    }
                }));
    }

    public void doGetItems(int start){
        mvpView.loadMoreData();

        getSubscription().add(manager.getMyCollection(MyTools.session_id,start,count)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ServerReturnMyCollection>() {
                    ServerReturnMyCollection serverReturn;
                    @Override
                    public void onCompleted() {

                        if(serverReturn.getCode()==0){//

                            List<ServerReturnMyCollection.Collection> data = serverReturn.getCollections();
                            for(int i=0;data!= null && i<data.size();i++){
                                mvpView.addItem(data.get(i));
                            }
                            mvpView.setTotalCount(serverReturn.getTotalCount());
                            mvpView.notifyListAdapterDataChange();
                            mvpView.loadComplete();
                        }
                        else{
                            mvpView.showToast(serverReturn.getMsg());
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        mvpView.loadComplete();
                        e.printStackTrace();
                        mvpView.showToast("请求失败");
                    }

                    @Override
                    public void onNext(ServerReturnMyCollection serverReturnComment) {
                        serverReturn = serverReturnComment;
                    }
                }));
    }
}
