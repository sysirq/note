package com.oxkernel.byakugan.presenter;

import android.content.Context;

import com.oxkernel.byakugan.base.BasePresenter;
import com.oxkernel.byakugan.base.MyTools;
import com.oxkernel.byakugan.entity.ServerReturnComment;
import com.oxkernel.byakugan.manager.DataManager;
import com.oxkernel.byakugan.view.ReplyView;

import java.util.List;

import rx.Observer;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by 31222 on 2018/4/8.
 */

public class ReplyPresenter extends BasePresenter<ReplyView> {
    private Context mContext;
    private DataManager manager;
    private static int count = 6;//每次获得的评论条数
    public ReplyPresenter(Context mContext){
        this.mContext = mContext;
        manager = new DataManager(mContext);
    }

    public void doFirstGetReplys(String comment_id){
        getSubscription().add(manager.getReply(comment_id, 0,count)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ServerReturnComment.Comment>() {
                    ServerReturnComment.Comment serverReturn;
                    @Override
                    public void onCompleted() {
                        if(serverReturn.getCode()==0){//成功获得回复
                            List<ServerReturnComment.Comment.Reply> data = serverReturn.getReplys();
                            for(int i=0;data!= null && i<data.size();i++){
                                mvpView.addItem(data.get(i));
                            }
                            mvpView.setTotalCount(serverReturn.getReplyCount());
                            mvpView.notifyListAdapterDataChange();
                        }
                        else{
                            mvpView.showToast(serverReturn.getMsg());
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        mvpView.showToast("请求失败");
                    }

                    @Override
                    public void onNext(ServerReturnComment.Comment serverReturnComment) {
                        serverReturn = serverReturnComment;
                    }
                }));
    }

    public void doRefresh(String comment_id){
        getSubscription().add(manager.getReply(comment_id, 0,count)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ServerReturnComment.Comment>() {
                    ServerReturnComment.Comment serverReturn;
                    @Override
                    public void onCompleted() {
                        if(serverReturn.getCode()==0){//成功获得回复
                            mvpView.clearItems();

                            List<ServerReturnComment.Comment.Reply> data = serverReturn.getReplys();
                            for(int i=0;data!= null && i<data.size();i++){
                                mvpView.addItem(data.get(i));
                            }
                            mvpView.setTotalCount(serverReturn.getReplyCount());
                            mvpView.notifyListAdapterDataChange();
                            mvpView.setRefreshing(false);
                        }
                        else{
                            mvpView.setRefreshing(false);
                            mvpView.showToast(serverReturn.getMsg());
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        mvpView.setRefreshing(false);
                        e.printStackTrace();
                        mvpView.showToast("请求失败");
                    }

                    @Override
                    public void onNext(ServerReturnComment.Comment serverReturnComment) {
                        serverReturn = serverReturnComment;
                    }
                }));
    }

    public void doGetItems(String comment_id,int start){
        mvpView.loadMoreData();

        getSubscription().add(manager.getReply(comment_id, start,count)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ServerReturnComment.Comment>() {
                    ServerReturnComment.Comment serverReturn;
                    @Override
                    public void onCompleted() {

                        if(serverReturn.getCode()==0){//成功获得评论
                            List<ServerReturnComment.Comment.Reply> data = serverReturn.getReplys();
                            for(int i=0;data!= null && i<data.size();i++){
                                mvpView.addItem(data.get(i));
                            }
                            mvpView.setTotalCount(serverReturn.getReplyCount());
                            mvpView.notifyListAdapterDataChange();
                            mvpView.loadComplete();
                        }
                        else{
                            mvpView.showToast(serverReturn.getMsg());
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        mvpView.loadComplete();
                        e.printStackTrace();
                        mvpView.showToast("请求失败");
                    }

                    @Override
                    public void onNext(ServerReturnComment.Comment serverReturnComment) {
                        serverReturn = serverReturnComment;
                    }
                }));
    }

    public void setReply(String comment_id,String to_u,String content) {
        final String commentId = comment_id;
        getSubscription().add(manager.setReply(comment_id, MyTools.session_id, to_u, content)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ServerReturnComment>() {
                    ServerReturnComment serverReturn;

                    @Override
                    public void onCompleted() {
                        if (serverReturn.getCode() == 0) {
                            mvpView.showToast("回复成功");
                            doRefresh(commentId);
                        } else {
                            mvpView.showToast(serverReturn.getMsg());
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        mvpView.showToast("请求失败");
                    }

                    @Override
                    public void onNext(ServerReturnComment serverReturnComment) {
                        serverReturn = serverReturnComment;
                    }
                }));
    }
}
