package com.oxkernel.byakugan.presenter;

import android.content.Context;

import com.oxkernel.byakugan.base.BasePresenter;
import com.oxkernel.byakugan.base.MyTools;
import com.oxkernel.byakugan.entity.ServerReturnStateForSignUp;
import com.oxkernel.byakugan.manager.DataManager;
import com.oxkernel.byakugan.view.SignUpView;

import rx.Observer;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;


/**
 * Created by i-lizhixi on 2018/3/26.
 */

public class SignUpPresenter extends BasePresenter<SignUpView>{
    private DataManager manager;
    private Context mContext;
    private ServerReturnStateForSignUp serverReturnStateForSignUp;

    public SignUpPresenter(Context mContext){
        this.mContext = mContext;
        manager = new DataManager(mContext);
    }

    public void doSign(){
        String name;
        String mail;
        String paswd;
        String paswdConfirm;

        name = mvpView.getUserName();
        mail = mvpView.getMailAddr();
        paswd = mvpView.getPaswd();
        paswdConfirm = mvpView.getPaswdConfirm();

        if(!doCheck(name,mail,paswd,paswdConfirm)){
            return ;
        }

        mvpView.showSignProgressDialog();

        getSubscription().add(manager.signUp(name, mail, paswd)
                            .subscribeOn(Schedulers.io())
                            .observeOn(AndroidSchedulers.mainThread())
                            .subscribe(new Observer<ServerReturnStateForSignUp>(){

                                @Override
                                public void onNext(ServerReturnStateForSignUp value) {
                                    serverReturnStateForSignUp = value;
                                }

                                @Override
                                public void onCompleted() {
                                    mvpView.closeSignProgressDialog();
                                    mvpView.showToast(serverReturnStateForSignUp.getMsg());
                                }

                                @Override
                                public void onError(Throwable e) {
                                    mvpView.closeSignProgressDialog();
                                    e.printStackTrace();
                                    mvpView.showToast("请求失败");
                                }
                            }));

    }

    private Boolean doCheck(String name,String mail,String paswd,String paswdConfirm){//合法性检测
        if(name.isEmpty() || mail.isEmpty()||paswd.isEmpty()||paswdConfirm.isEmpty()){
            mvpView.showToast("请确保所有数据已经输入");
            return false;
        }

        if(name.length() < 6 ){
            mvpView.showToast("请确保用户名长度必须大于等于6");
            return false;
        }

        if(!MyTools.isEmail(mail)){
            mvpView.showToast("请确保邮件地址的合法性");
            return false;
        }

        if(!paswd.equals(paswdConfirm)){
            mvpView.showToast("请确保两次输入的密码一致");
            return false;
        }

        if(paswd.length() < 6 ){
            mvpView.showToast("请确保密码长度必须大于等于6");
            return false;
        }

        return true;
    }
}
