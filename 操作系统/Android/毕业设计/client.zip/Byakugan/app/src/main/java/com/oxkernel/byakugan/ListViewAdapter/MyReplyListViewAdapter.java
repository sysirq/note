package com.oxkernel.byakugan.ListViewAdapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.oxkernel.byakugan.R;
import com.oxkernel.byakugan.base.MyTools;
import com.oxkernel.byakugan.entity.ServerReturnMyComment;
import com.oxkernel.byakugan.entity.ServerReturnMyReply;
import com.oxkernel.byakugan.ui.DetailActivity;

import java.util.ArrayList;

/**
 * Created by 31222 on 2018/4/9.
 */

public class MyReplyListViewAdapter extends BaseAdapter {
    private Context mContext;
    private ArrayList<ServerReturnMyReply.Reply> items;
    private LayoutInflater mInflater;

    public MyReplyListViewAdapter(Context context, ArrayList<ServerReturnMyReply.Reply> items){
        mContext =  context;
        this.items = items;
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if(convertView == null){
            convertView = mInflater.inflate(R.layout.list_view_my_reply_item,null);
            holder = new ViewHolder();

            holder.title = convertView.findViewById(R.id.my_reply_title);
            holder.name = convertView.findViewById(R.id.my_reply_name);
            holder.content = convertView.findViewById(R.id.my_reply_content);
            holder.time = convertView.findViewById(R.id.my_reply_time);

            //下划线
            holder.title.getPaint().setFlags(Paint. UNDERLINE_TEXT_FLAG);
            holder.title.getPaint().setAntiAlias(true);

            convertView.setTag(holder);
        }
        else{
            holder =  (ViewHolder)convertView.getTag();
        }

        final ServerReturnMyReply.Reply item = items.get(position);

        holder.title.setText(item.getTitle());
        holder.content.setText(item.getContent());
        holder.name.setText(item.getTo_u());
        holder.time.setText(item.getTime());

        holder.title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, DetailActivity.class);
                intent.putExtra(MyTools.INTENT_ID,item.getArticle_id());
                mContext.startActivity(intent);
            }
        });

        return convertView;
    }
    public class ViewHolder{
        public TextView title;
        public TextView content;
        public TextView name;
        public TextView time;
    }
}
