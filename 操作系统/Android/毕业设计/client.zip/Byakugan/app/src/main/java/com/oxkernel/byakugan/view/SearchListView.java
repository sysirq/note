package com.oxkernel.byakugan.view;

import com.oxkernel.byakugan.base.BaseView;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by 31222 on 2018/4/10.
 */

public interface SearchListView extends BaseView{
    void addItems(ArrayList<HashMap<String,Object>> items);
    void notifyListAdapterDataChange();
    void setTotalCount(int count);

    void loadMoreData();
    void loadComplete();
    void clearItems();
}
