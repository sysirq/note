package com.oxkernel.byakugan.view;

import com.oxkernel.byakugan.base.BaseView;

/**
 * Created by 31222 on 2018/4/10.
 */

public interface MainView extends BaseView {
    void new_message(int b);
}
