package com.oxkernel.byakugan.ListViewAdapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.oxkernel.byakugan.R;
import com.oxkernel.byakugan.entity.ServerReturnMyCollection;

import java.util.ArrayList;

/**
 * Created by 31222 on 2018/4/9.
 */

public class MyCollectionListViewAdapter  extends BaseAdapter {
    private Context mContext;
    private ArrayList<ServerReturnMyCollection.Collection> items;
    private LayoutInflater mInflater;

    public MyCollectionListViewAdapter(Context context,ArrayList<ServerReturnMyCollection.Collection> items){
        mContext =  context;
        this.items = items;
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if(convertView == null){
            convertView = mInflater.inflate(R.layout.list_view_my_collection_item,null);
            holder = new ViewHolder();

            holder.title = convertView.findViewById(R.id.my_collecion_title);


            convertView.setTag(holder);
        }
        else{
            holder =  (ViewHolder)convertView.getTag();
        }

        ServerReturnMyCollection.Collection item = items.get(position);

        holder.title.setText(item.getTitle());

        return convertView;
    }
    public class ViewHolder{
        public TextView title;
    }
}
