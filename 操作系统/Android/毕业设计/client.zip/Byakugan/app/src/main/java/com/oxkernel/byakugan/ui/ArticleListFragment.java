package com.oxkernel.byakugan.ui;

import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.oxkernel.byakugan.ListViewAdapter.ArticleListListViewAdapter;
import com.oxkernel.byakugan.R;
import com.oxkernel.byakugan.base.MyTools;
import com.oxkernel.byakugan.presenter.ArticleListPresenter;
import com.oxkernel.byakugan.view.ArticleListView;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by i-lizhixi on 2018/3/23.
 */

public class ArticleListFragment extends Fragment implements AbsListView.OnScrollListener,AdapterView.OnItemClickListener,ArticleListView,SwipeRefreshLayout.OnRefreshListener {
    private ArticleListPresenter presenter;

    private ArticleListListViewAdapter myAdapter;

    private View mRootView;
    private Context mContext;
    private View moreView;

    private Boolean isBottom;//到底部了
    private Boolean isRefresh = false;//是否正在刷新加载数据

    private SwipeRefreshLayout swipeRefreshLayout;
    private ListView bugListView;

    private ArrayList<HashMap<String,Object>> items = new ArrayList<HashMap<String,Object>>();
    private int totalCount;//服务器中，总的数据量

    private String type="WarningNotice";
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mRootView = inflater.inflate(R.layout.fragment_article_list, container,
                false);

        this.mContext = getActivity();

        if(getArguments()!=null){
            //取出保存的值
            type = getArguments().getString("type");
        }

        initViews();

        presenter = new ArticleListPresenter(mContext,type);
        presenter.attachView(this);
        presenter.doFirstGetItems();

        return mRootView;
    }

    @Override
    public void onDestroy(){
        super.onDestroy();
        presenter.detachView();
    }

    private void initViews(){
        swipeRefreshLayout = mRootView.findViewById(R.id.article_list_refreshLayout);
        swipeRefreshLayout.setColorSchemeColors(android.R.color.holo_blue_bright,android.R.color.holo_orange_light,android.R.color.holo_green_light);
        swipeRefreshLayout.setOnRefreshListener(this);

        moreView = getActivity().getLayoutInflater().inflate(R.layout.list_view_article_list_more_data,null);

        bugListView = mRootView.findViewById(R.id.article_list_list_view);
        myAdapter = new ArticleListListViewAdapter(mContext,items);

        moreView.setVisibility(View.GONE);
        bugListView.addFooterView(moreView,null,false);

        bugListView.setAdapter(myAdapter);
        bugListView.setOnScrollListener(this);
        bugListView.setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {//item点击
        //showToast("您点击了： "+position + "标题： "+items.get(position).get(MyTools.BUG_LIST_ITEM_TITLE).toString()+"ID： "+items.get(position).get(MyTools.BUG_LIST_ITEM_ID).toString());
        Intent intent = new Intent(mContext,DetailActivity.class);
        intent.putExtra(MyTools.INTENT_SOURCE,"BUG");
        intent.putExtra(MyTools.INTENT_ID,items.get(position).get(MyTools.BUG_LIST_ITEM_ID).toString());
        intent.putExtra(MyTools.INTENT_TITLE,items.get(position).get(MyTools.BUG_LIST_ITEM_TITLE).toString());
        startActivity(intent);
    }

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {
        if(scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE){
            if(isBottom && totalCount > items.size()){
                //下载更多数据
                presenter.doGetItems(items.size());
            }
            if(isBottom && totalCount == items.size()){
                showToast("已经全部加载完毕");
            }
        }
    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
        if(firstVisibleItem + visibleItemCount == totalItemCount){
            isBottom = true;
        }
        else{
            isBottom = false;
        }
    }

    @Override
    public void showToast(String msg) {
        Toast.makeText(mContext,msg,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void addItems(ArrayList<HashMap<String, Object>> items) {//向List适配器中添加新数据
        this.items.addAll(items);
    }

    @Override
    public void notifyListAdapterDataChange() {
        myAdapter.notifyDataSetChanged();//数据集变化，通知adapter
    }

    @Override
    public void setTotalCount(int count) {//设置服务器上总的数据条数
        totalCount = count;
    }

    @Override
    public void loadMoreData() {//显示加载更多
        moreView.setVisibility(View.VISIBLE);
    }

    @Override
    public void loadComplete() {//关闭加载更多
        moreView.setVisibility(View.GONE);
    }

    @Override
    public void setRefreshing(Boolean b) {
        if(b == true) {

        }
        else{
            swipeRefreshLayout.setRefreshing(b);
        }
    }

    @Override
    public void clearItems() {
        items.clear();
    }

    @Override
    public void onRefresh() {//下拉刷新
        presenter.doRefresh();
    }
}