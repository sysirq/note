package com.oxkernel.byakugan.base;

import android.support.annotation.NonNull;

import java.util.concurrent.TimeUnit;

import io.reactivex.disposables.Disposable;
import rx.Observable;
import rx.Observer;
import rx.android.schedulers.AndroidSchedulers;

/**
 * Created by 31222 on 2018/4/10.
 */

public class RxTimerUtil {

        private static Disposable mDisposable;

        /** milliseconds毫秒后执行next操作
         *
         * @param milliseconds
         * @param next
         */
        public static void timer(long milliseconds,final IRxNext next) {
            Observable.timer(milliseconds, TimeUnit.MILLISECONDS)
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Observer<Long>() {

                        @Override
                        public void onNext(@NonNull Long number) {
                            if(next!=null){
                                next.doNext(number);
                            }
                        }

                        @Override
                        public void onCompleted() {
                            cancel();
                        }

                        @Override
                        public void onError(@NonNull Throwable e) {
                            //取消订阅
                            cancel();
                        }

                    });
        }


        /** 每隔milliseconds毫秒后执行next操作
         *
         * @param milliseconds
         * @param next
         */
        public static void interval(long milliseconds,final IRxNext next){
            Observable.interval(milliseconds, TimeUnit.MILLISECONDS)
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Observer<Long>() {

                        @Override
                        public void onNext(@NonNull Long number) {
                            if(next!=null){
                                next.doNext(number);
                            }
                        }

                        @Override
                        public void onCompleted() {

                        }

                        @Override
                        public void onError(@NonNull Throwable e) {

                        }
                    });
        }


        /**
         * 取消订阅
         */
        public static void cancel(){
            if(mDisposable!=null&&!mDisposable.isDisposed()){
                mDisposable.dispose();
            }
        }

        public interface IRxNext{
            void doNext(long number);
        }
}
