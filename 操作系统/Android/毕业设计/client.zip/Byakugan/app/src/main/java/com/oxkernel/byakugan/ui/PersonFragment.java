package com.oxkernel.byakugan.ui;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.oxkernel.byakugan.R;
import com.oxkernel.byakugan.base.MyTools;
import com.oxkernel.byakugan.file.FileHelper;
import com.oxkernel.byakugan.presenter.MyCommentPresenter;
import com.oxkernel.byakugan.presenter.PersonPresenter;
import com.oxkernel.byakugan.view.MyReplyView;
import com.oxkernel.byakugan.view.PersonView;

import org.w3c.dom.Text;

import jp.wasabeef.glide.transformations.BlurTransformation;
import jp.wasabeef.glide.transformations.CropCircleTransformation;
import jp.wasabeef.glide.transformations.CropSquareTransformation;

/**
 * Created by i-lizhixi on 2018/3/23.
 */

public class PersonFragment extends Fragment implements View.OnClickListener,PersonView{
    private ImageView headImageView;//头像
    private ImageView backImageView;//背景头像
    private TextView nameTextView;
    private TextView collection;//我的收藏
    private TextView comment;//我的评论
    private TextView reply;//我的回复
    private TextView message;//我的消息
    private TextView head;//头像更改
    private TextView loginOff;//退出登陆

    private View mRootView;
    private Context mContext;
    private PersonPresenter presenter;
    private static final int LOGIN_BUTTON_CODE = 1001;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
         mRootView = inflater.inflate(R.layout.fragment_person, container,
                false);

        this.mContext = getActivity();

        initViews();

        presenter = new PersonPresenter(mContext);

        presenter.attachView(this);
        presenter.getUserInfo();

        return mRootView;
    }

    @Override
    public void onHiddenChanged(boolean hidden){
        super.onHiddenChanged(hidden);
        if (hidden) {   // 不在最前端显示 相当于调用了onPause();
            return;
        }else{  // 在最前端显示 相当于调用了onResume();
            presenter.getUserInfo();
        }
    }

    @Override
    public void onResume(){
        super.onResume();
        presenter.getUserInfo();
    }

    @Override
    public void onDestroy(){
        super.onDestroy();
        presenter.detachView();
    }

    private void initViews(){
        headImageView = mRootView.findViewById(R.id.h_head);
        backImageView = mRootView.findViewById(R.id.h_back);

        nameTextView = mRootView.findViewById(R.id.logined_name);
        headImageView.setOnClickListener(this);

        collection = mRootView.findViewById(R.id.my_collection_text_view);
        collection.setOnClickListener(this);

        comment = mRootView.findViewById(R.id.my_comment_text_view);
        comment.setOnClickListener(this);

        reply = mRootView.findViewById(R.id.my_reply_text_view);
        reply.setOnClickListener(this);

        message = mRootView.findViewById(R.id.my_message_text_view);
        message.setOnClickListener(this);

        head = mRootView.findViewById(R.id.my_head_change_text_view);
        head.setOnClickListener(this);

        loginOff = mRootView.findViewById(R.id.my_login_off_text_view);
        loginOff.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.h_head://登录
                if(MyTools.session_id.equals("")) {
                    startActivityForResult(new Intent(mContext, LoginActivity.class), LOGIN_BUTTON_CODE);
                }
                else{//图片上传

                }
                break;
            case R.id.my_collection_text_view:
                if(MyTools.session_id.equals("")) {
                    startActivityForResult(new Intent(mContext, LoginActivity.class), LOGIN_BUTTON_CODE);
                }
                else{
                    Intent intent = new Intent(mContext, MyCollectionActivity.class);
                    startActivity(intent);
                }
                break;
            case R.id.my_comment_text_view:
                if(MyTools.session_id.equals("")) {
                    startActivityForResult(new Intent(mContext, LoginActivity.class), LOGIN_BUTTON_CODE);
                }
                else {
                    Intent intent = new Intent(mContext, MyCommentActivity.class);
                    startActivity(intent);
                }
                break;
            case R.id.my_reply_text_view:
                if(MyTools.session_id.equals("")) {
                    startActivityForResult(new Intent(mContext, LoginActivity.class), LOGIN_BUTTON_CODE);
                }
                else {
                    Intent intent = new Intent(mContext, MyReplyActivity.class);
                    startActivity(intent);
                }
                break;
            case R.id.my_message_text_view:
                if(MyTools.session_id.equals("")) {
                    startActivityForResult(new Intent(mContext, LoginActivity.class), LOGIN_BUTTON_CODE);
                }
                else {
                    Intent intent = new Intent(mContext, MyMessageActivity.class);
                    startActivity(intent);
                }
                break;
            case R.id.my_head_change_text_view:
                if(MyTools.session_id.equals("")) {
                    startActivityForResult(new Intent(mContext, LoginActivity.class), LOGIN_BUTTON_CODE);
                }
                else {
                    Intent intent = new Intent(mContext, MyHeadChangeActivity.class);
                    startActivity(intent);
                }
                break;
            case R.id.my_login_off_text_view:
                final AlertDialog.Builder normalDialog = new AlertDialog.Builder(mContext);
                normalDialog.setTitle("退出登陆");
                normalDialog.setMessage("确定要退出当前账号吗？");
                normalDialog.setPositiveButton("确定",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                setHeadImage(null);
                                setLoginedName(null);
                                //session 处理
                                FileHelper fileHelper = new FileHelper(mContext);
                                MyTools.session_id = "";
                                fileHelper.save(MyTools.session_file_name, "");
                            }
                        });
                normalDialog.setNegativeButton("关闭",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //...To-do
                            }
                        });
                // 显示
                normalDialog.show();
                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode == LOGIN_BUTTON_CODE && resultCode == Activity.RESULT_OK){
            presenter.getUserInfo();
        }
    }

    @Override
    public void showToast(String msg) {
        Toast.makeText(mContext,msg,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void setLoginedName(String name) {
        if(name != null) {
            nameTextView.setText(name);
        }
        else{
            nameTextView.setText("尚未登录(点击头像进行登陆)");
        }
    }

    @Override
    public void setHeadImage(String addr) {
        if(addr != null) {
            Glide.with(this).load(MyTools.baseUrl+"head/"+addr).bitmapTransform(new CropCircleTransformation(mContext)).into(headImageView);
        }
        else{
            Glide.with(this).load(R.drawable.default_head).bitmapTransform(new CropCircleTransformation(mContext)).into(headImageView);
        }
    }

    @Override
    public void new_message(int b) {
        if(b == 0){//无新消息
            message.setTextColor(getResources().getColor(R.color.preson_text));
            ((MainActivity)mContext).new_message(b);
        }
        else{//有新消息
            message.setTextColor(getResources().getColor(R.color.red));
            ((MainActivity)mContext).new_message(b);
        }
    }
}
