package com.oxkernel.byakugan.presenter;

import android.content.Context;

import com.oxkernel.byakugan.base.BasePresenter;
import com.oxkernel.byakugan.base.MyTools;
import com.oxkernel.byakugan.entity.UserInfo;
import com.oxkernel.byakugan.manager.DataManager;
import com.oxkernel.byakugan.view.MainView;

import rx.Observer;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by 31222 on 2018/4/10.
 */

public class MainPresenter extends BasePresenter<MainView> {
    private Context mContext;
    private DataManager manager;

    public MainPresenter(Context mContext){
        this.mContext = mContext;
        manager = new DataManager(mContext);
    }

    public void getUserInfo(){//获取用户信息
        getSubscription().add(manager.userInfo(MyTools.session_id)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<UserInfo>(){
                    private UserInfo userInfo;
                    @Override
                    public void onNext(UserInfo value) {
                        userInfo = value;
                    }

                    @Override
                    public void onCompleted() {
                        if(userInfo.getCode() == 0){
                            //success
                            mvpView.new_message(userInfo.getNew_message());
                        }
                        else {
                            //fail
                        }

                    }

                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                    }
                }));
    }
}
