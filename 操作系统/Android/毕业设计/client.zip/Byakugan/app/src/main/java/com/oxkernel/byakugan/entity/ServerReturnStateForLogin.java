package com.oxkernel.byakugan.entity;

/**
 * Created by 31222 on 2018/3/27.
 */

public class ServerReturnStateForLogin {
    private int code;
    private String msg;
    private String session_id;

    public void setCode(int code){
        this.code = code;
    }

    public int getCode(){
        return code;
    }

    public void setMsg(String msg){
        this.msg = msg;
    }

    public String getMsg(){
        return msg;
    }

    public void setSession_id(String session_id){
        this.session_id = session_id;
    }

    public String getSession_id(){
        return session_id;
    }
}
