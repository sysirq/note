package com.oxkernel.byakugan.presenter;

import android.content.Context;

import com.oxkernel.byakugan.base.BasePresenter;
import com.oxkernel.byakugan.base.MyTools;
import com.oxkernel.byakugan.entity.ServerReturnMyHead;
import com.oxkernel.byakugan.entity.ServerReturnMyMessage;
import com.oxkernel.byakugan.manager.DataManager;
import com.oxkernel.byakugan.view.MyHeadChangeView;

import java.util.List;

import rx.Observer;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by 31222 on 2018/4/9.
 */

public class MyHeadChangePresenter extends BasePresenter<MyHeadChangeView> {
    private Context mContext;
    private DataManager manager;
    private static int count = 10;//每次请求的数量

    public MyHeadChangePresenter(Context mContext){
        this.mContext = mContext;
        manager = new DataManager(mContext);
    }
    public void doFirstGetHeads(){
        getSubscription().add(manager.getHeadImageAddr(0,count)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ServerReturnMyHead>() {
                    ServerReturnMyHead serverReturn;
                    @Override
                    public void onCompleted() {
                        if(serverReturn.getCode()==0){
                            List<String> data = serverReturn.getAddrs();
                            for(int i=0;data!= null && i<data.size();i++){
                                mvpView.addItem(data.get(i));
                            }
                            mvpView.setTotalCount(serverReturn.getTotalCount());
                            mvpView.notifyListAdapterDataChange();
                        }
                        else{
                            mvpView.showToast(serverReturn.getMsg());
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        mvpView.showToast("请求失败");
                    }

                    @Override
                    public void onNext(ServerReturnMyHead serverReturnComment) {
                        serverReturn = serverReturnComment;
                    }
                }));
    }

    public void doGetItems(int start){
        mvpView.loadMoreData();

        getSubscription().add(manager.getHeadImageAddr(start,count)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ServerReturnMyHead>() {
                    ServerReturnMyHead serverReturn;
                    @Override
                    public void onCompleted() {

                        if(serverReturn.getCode()==0){//
                            List<String> data = serverReturn.getAddrs();
                            for(int i=0;data!= null && i<data.size();i++){
                                mvpView.addItem(data.get(i));
                            }
                            mvpView.setTotalCount(serverReturn.getTotalCount());
                            mvpView.notifyListAdapterDataChange();
                            mvpView.loadComplete();
                        }
                        else{
                            mvpView.showToast(serverReturn.getMsg());
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        mvpView.loadComplete();
                        e.printStackTrace();
                        mvpView.showToast("请求失败");
                    }

                    @Override
                    public void onNext(ServerReturnMyHead serverReturnComment) {
                        serverReturn = serverReturnComment;
                    }
                }));
    }

    public void doRefresh(){
        getSubscription().add(manager.getHeadImageAddr(0,count)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ServerReturnMyHead>() {
                    ServerReturnMyHead serverReturn;
                    @Override
                    public void onCompleted() {
                        if(serverReturn.getCode()==0){//成功获得评论
                            mvpView.clearItems();

                            List<String> data = serverReturn.getAddrs();
                            for(int i=0;data!=null && i<data.size();i++){
                                mvpView.addItem(data.get(i));
                            }
                            mvpView.setTotalCount(serverReturn.getTotalCount());
                            mvpView.notifyListAdapterDataChange();
                            mvpView.setRefreshing(false);
                        }
                        else{
                            mvpView.setRefreshing(false);
                            mvpView.showToast(serverReturn.getMsg());
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        mvpView.setRefreshing(false);
                        e.printStackTrace();
                        mvpView.showToast("请求失败");
                    }

                    @Override
                    public void onNext(ServerReturnMyHead serverReturnComment) {
                        serverReturn = serverReturnComment;
                    }
                }));
    }

    public void setHeadImage(int index){
        mvpView.showSignProgressDialog();

        getSubscription().add(manager.setHeadImage(MyTools.session_id,index)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ServerReturnMyHead>() {
                    ServerReturnMyHead serverReturn;
                    @Override
                    public void onCompleted() {
                        mvpView.closeSignProgressDialog();

                        if(serverReturn.getCode()==0){//成功
                            mvpView.showToast("头像更改成功");
                        }
                        else{
                            mvpView.showToast(serverReturn.getMsg());
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        mvpView.closeSignProgressDialog();
                        e.printStackTrace();
                        mvpView.showToast("请求失败");
                    }

                    @Override
                    public void onNext(ServerReturnMyHead serverReturnComment) {
                        serverReturn = serverReturnComment;
                    }
                }));
    }
}
