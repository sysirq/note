package com.oxkernel.byakugan.ui;

import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.oxkernel.byakugan.R;
import com.oxkernel.byakugan.presenter.ResetPaswdPresenter;
import com.oxkernel.byakugan.view.ResetPaswdView;

/**
 * Created by i-lizhixi on 2018/3/26.
 */

public class ResetPaswdActivity extends AppCompatActivity  implements View.OnClickListener,ResetPaswdView{
    private Toolbar myToolbar;
    private ImageView returnImage;
    private ResetPaswdPresenter presenter;
    private EditText mailEditText;
    private Button resetButton;

    protected void onCreate(Bundle savedInstanceState) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {//沉浸式设置
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_paswd);

        presenter = new ResetPaswdPresenter(this);
        presenter.attachView(this);

        initViews();
    }

    private void initViews(){
        myToolbar = findViewById(R.id.my_toolbar_reset);
        myToolbar.setTitle("");
        setSupportActionBar(myToolbar);

        returnImage = findViewById(R.id.reset_image_return);
        returnImage.setOnClickListener(this);

        resetButton = findViewById(R.id.reset);
        resetButton.setOnClickListener(this);

        mailEditText = findViewById(R.id.reset_user_mail);

    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        presenter.detachView();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.reset_image_return:
                finish();
                break;
            case R.id.reset:
                presenter.doResetPaswd();
                break;
        }
    }

    @Override
    public void showToast(String msg) {
        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
    }

    @Override
    public String getMailAddr() {
        return mailEditText.getText().toString();
    }
}
