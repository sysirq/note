package com.oxkernel.byakugan.view;

import com.oxkernel.byakugan.base.BaseView;
import com.oxkernel.byakugan.entity.ServerReturnMyCollection;
import com.oxkernel.byakugan.entity.ServerReturnMyComment;

/**
 * Created by 31222 on 2018/4/9.
 */

public interface MyCommentView extends BaseView {
    void loadMoreData();
    void loadComplete();

    void addItem(ServerReturnMyComment.Comment item);
    void setTotalCount(int n);
    void notifyListAdapterDataChange();

    int getTotalCount();

    void setRefreshing(Boolean b);

    void clearItems();
}
