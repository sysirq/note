package com.oxkernel.byakugan.ui;

import android.annotation.SuppressLint;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.oxkernel.byakugan.R;
import com.oxkernel.byakugan.base.MyTools;
import com.oxkernel.byakugan.file.FileHelper;
import com.oxkernel.byakugan.presenter.MainPresenter;
import com.oxkernel.byakugan.view.MainView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener,MainView{

    private ArticleListFragment homeFragment;
    private ArticleListFragment articleListFragment;
    private ArticleListFragment reportFragment;
    private PersonFragment personFragment;

    private View homeLayout;
    private View bugLayout;
    private View reportLayout;
    private View personLayout;

    private ImageView homeImage;
    private ImageView bugImage;
    private ImageView reportImage;
    private ImageView personImage;
    private ImageView searchImage;

    private TextView homeText;
    private TextView bugText;
    private TextView reportText;
    private TextView personText;
    private TextView toolBarTitle;

    private FragmentManager fragmentManager;

    private Toolbar myToolbar;

    private MainPresenter presenter;

    private boolean person_select = false;//判断person是否被选中
    private int person_icon;
    private int person_icon_select;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {//沉浸式设置
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        presenter = new MainPresenter(this);
        presenter.attachView(this);

        initViews();
        new_message(0);
        fragmentManager = getFragmentManager();


        //加载保存的session
        FileHelper fileHelper = new FileHelper(this);
        String session_id = fileHelper.read(MyTools.session_file_name);
        MyTools.session_id = session_id;

        presenter.getUserInfo();//判断是否有新消息
        setTableSelection(0);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        presenter.getUserInfo();//判断是否有新消息
        Log.e("info", "MainActivity onRestart~~~");
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        if(presenter != null) {
            presenter.detachView();
        }
    }

    @Override
    public void showToast(String msg){
        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.home_layout:
                setTableSelection(0);
                break;
            case R.id.bug_layout:
                setTableSelection(1);
                break;
            case R.id.report_layout:
                setTableSelection(2);
                break;
            case R.id.person_layout:
                setTableSelection(3);
                break;
            case R.id.my_toolbar_search_image:
                Intent intent = new Intent(this,SearchListActivity.class);
                startActivity(intent);
                break;
        }
    }

    private void initViews(){
        //设置ToolBar
        myToolbar = findViewById(R.id.my_toolbar);
        myToolbar.setTitle("");
        setSupportActionBar(myToolbar);

        homeLayout = findViewById(R.id.home_layout);
        bugLayout = findViewById(R.id.bug_layout);
        reportLayout = findViewById(R.id.report_layout);
        personLayout = findViewById(R.id.person_layout);

        homeImage = findViewById(R.id.home_image);
        bugImage = findViewById(R.id.bug_image);
        reportImage = findViewById(R.id.report_image);
        personImage = findViewById(R.id.person_image);
        searchImage = findViewById(R.id.my_toolbar_search_image);

        homeText = findViewById(R.id.home_text);
        bugText = findViewById(R.id.bug_text);
        reportText = findViewById(R.id.report_text);
        personText = findViewById(R.id.person_text);
        toolBarTitle = findViewById(R.id.my_toolbar_title);

        homeLayout.setOnClickListener(this);
        bugLayout.setOnClickListener(this);
        reportLayout.setOnClickListener(this);
        personLayout.setOnClickListener(this);
        searchImage.setOnClickListener(this);

    }

    public void setTableSelection(int index){
        clearSelection();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        hideFragments(transaction);
        switch (index){
            case 0:
                toolBarTitle.setText("主页");
                homeImage.setImageResource(R.drawable.home_24_select);
                homeText.setTextColor(getResources().getColor(R.color.tab_bg_text_select));
                if(homeFragment == null){
                    homeFragment = new ArticleListFragment();
                    Bundle bundle = new Bundle();
                    bundle.putString("type", "home");
                    //fragment保存参数，传入一个Bundle对象
                    homeFragment.setArguments(bundle);
                    transaction.add(R.id.content,homeFragment);
                }
                else{
                    transaction.show(homeFragment);
                }
                break;
            case 1:
                toolBarTitle.setText("预警通告");
                bugImage.setImageResource(R.drawable.bug_24_select);
                bugText.setTextColor(getResources().getColor(R.color.tab_bg_text_select));
                if(articleListFragment == null){
                    articleListFragment = new ArticleListFragment();
                    Bundle bundle = new Bundle();
                    bundle.putString("type", "WarningNotice");
                    //fragment保存参数，传入一个Bundle对象
                    articleListFragment.setArguments(bundle);

                    transaction.add(R.id.content, articleListFragment);
                }
                else{
                    transaction.show(articleListFragment);
                }
                break;
            case 2:
                toolBarTitle.setText("安全报告");
                reportImage.setImageResource(R.drawable.report_24_select);
                reportText.setTextColor(getResources().getColor(R.color.tab_bg_text_select));
                if(reportFragment == null){
                    reportFragment = new ArticleListFragment();
                    Bundle bundle = new Bundle();
                    bundle.putString("type", "report");
                    //fragment保存参数，传入一个Bundle对象
                    reportFragment.setArguments(bundle);

                    transaction.add(R.id.content,reportFragment);
                }
                else{
                    transaction.show(reportFragment);
                }
                break;
            case 3:
                toolBarTitle.setText("我的");
                person_select = true;
                personImage.setImageResource(person_icon_select);
                personText.setTextColor(getResources().getColor(R.color.tab_bg_text_select));
                if(personFragment == null){
                    personFragment = new PersonFragment();
                    transaction.add(R.id.content,personFragment);
                }
                else{
                    transaction.show(personFragment);
                }
                break;
        }
        transaction.commit();
    }

    @SuppressLint("ResourceAsColor")
    private void clearSelection(){
        homeImage.setImageResource(R.drawable.home_24);
        bugImage.setImageResource(R.drawable.bug_24);
        reportImage.setImageResource(R.drawable.report_24);
        personImage.setImageResource(person_icon);

        homeText.setTextColor(getResources().getColor(R.color.tab_bg_text));
        bugText.setTextColor(getResources().getColor(R.color.tab_bg_text));
        reportText.setTextColor(getResources().getColor(R.color.tab_bg_text));
        personText.setTextColor(getResources().getColor(R.color.tab_bg_text));
        person_select = false;
    }

    private void hideFragments(FragmentTransaction transaction){
        if(homeFragment != null){
            transaction.hide(homeFragment);
        }
        if(articleListFragment != null){
            transaction.hide(articleListFragment);
        }
        if(reportFragment != null){
            transaction.hide(reportFragment);
        }
        if(personFragment != null){
            transaction.hide(personFragment);
        }
    }

    @Override
    public void new_message(int b) {
        if(b!=0){//新消息
            person_icon = R.drawable.person_24_message;
            person_icon_select = R.drawable.person_24_select_message;
        }
        else{
            person_icon = R.drawable.person_24;
            person_icon_select = R.drawable.person_24_select;
        }

        if(person_select == true){
            personImage.setImageResource(person_icon_select);
        }
        else{
            personImage.setImageResource(person_icon);
        }
    }
}
