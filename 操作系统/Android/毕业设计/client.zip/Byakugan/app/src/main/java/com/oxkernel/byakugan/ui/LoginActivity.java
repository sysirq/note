package com.oxkernel.byakugan.ui;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.oxkernel.byakugan.R;
import com.oxkernel.byakugan.base.MyTools;
import com.oxkernel.byakugan.file.FileHelper;
import com.oxkernel.byakugan.presenter.LoginPresenter;
import com.oxkernel.byakugan.view.LoginView;

import org.w3c.dom.Text;

/**
 * Created by i-lizhixi on 2018/3/26.
 */

public class LoginActivity extends AppCompatActivity implements View.OnClickListener,LoginView {
    private Toolbar myToolbar;
    private ImageView returnImageView;
    private TextView signUpTextView;
    private TextView resetPaswdTextView;
    private ProgressDialog progressDialog;

    private EditText nameEditText;
    private EditText passwordEditText;
    private Button loginButton;

    private LoginPresenter presenter;

    boolean isFinish = false;

    protected void onCreate(Bundle savedInstanceState) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {//沉浸式设置
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        presenter = new LoginPresenter(this);
        presenter.attachView(this);

        initViews();
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        presenter.detachView();
    }

    private void initViews(){
        myToolbar = findViewById(R.id.my_toolbar_login);
        myToolbar.setTitle("");
        setSupportActionBar(myToolbar);

        returnImageView = findViewById(R.id.login_image_return);
        returnImageView.setOnClickListener(this);


        signUpTextView = findViewById(R.id.sign_up_text_view);
        signUpTextView.setOnClickListener(this);

        resetPaswdTextView = findViewById(R.id.reset_password_text_view);
        resetPaswdTextView.setOnClickListener(this);

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("提示信息");
        progressDialog.setMessage("登陆中......");
        progressDialog.setCancelable(false);

        nameEditText = findViewById(R.id.login_user_name);
        passwordEditText = findViewById(R.id.login_user_paswd);
        loginButton = findViewById(R.id.login);

        loginButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.login_image_return:
                setResult(RESULT_CANCELED);
                finish();
                break;
            case R.id.sign_up_text_view:
                startActivity(new Intent(this,SignUpActivity.class));
                break;
            case R.id.reset_password_text_view:
                startActivity(new Intent(this,ResetPaswdActivity.class));
                break;
            case R.id.login:
                presenter.doLogin();
                break;
        }
    }

    @Override
    public void showToast(String msg) {
        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
    }

    @Override
    public String getName() {
        return nameEditText.getText().toString();
    }

    @Override
    public String getPassword() {
        return passwordEditText.getText().toString();
    }

    @Override
    public void myFinish()  {
        FileHelper fileHelper = new FileHelper(this);

        fileHelper.save(MyTools.session_file_name, MyTools.session_id);

        setResult(RESULT_OK);
        finish();
    }

    @Override
    public void showSignProgressDialog() {
        progressDialog.show();
    }

    @Override
    public void closeSignProgressDialog() {
        progressDialog.dismiss();
    }
}
