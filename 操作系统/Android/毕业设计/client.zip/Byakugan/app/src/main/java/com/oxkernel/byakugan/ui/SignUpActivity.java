package com.oxkernel.byakugan.ui;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.oxkernel.byakugan.R;
import com.oxkernel.byakugan.base.BasePresenter;
import com.oxkernel.byakugan.presenter.SignUpPresenter;
import com.oxkernel.byakugan.view.SignUpView;

/**
 * Created by i-lizhixi on 2018/3/26.
 */

public class SignUpActivity extends AppCompatActivity implements View.OnClickListener,SignUpView {
    private Toolbar myToolbar;
    private ImageView returnImage;
    private EditText userNameEditText;
    private EditText mailAddrEditText;
    private EditText paswdEditText;
    private EditText paswdConfirmEditText;
    private Button signButton;

    private ProgressDialog progressDialog;

    private SignUpPresenter presenter;

    protected void onCreate(Bundle savedInstanceState) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {//沉浸式设置
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        initViews();

        presenter = new SignUpPresenter(this);
        presenter.attachView(this);

    }

    private void initViews(){


        myToolbar = findViewById(R.id.my_toolbar_sign);
        myToolbar.setTitle("");
        setSupportActionBar(myToolbar);

        returnImage = findViewById(R.id.sign_image_return);
        returnImage.setOnClickListener(this);

        signButton = findViewById(R.id.sign);
        signButton.setOnClickListener(this);

        userNameEditText = findViewById(R.id.sign_user_name);
        mailAddrEditText = findViewById(R.id.sign_user_mail);
        paswdEditText = findViewById(R.id.sign_user_paswd_1);
        paswdConfirmEditText = findViewById(R.id.sign_user_paswd_2);

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("提示信息");
        progressDialog.setMessage("注册中......");
        progressDialog.setCancelable(false);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.sign_image_return:
                finish();
                break;
            case R.id.sign:
                presenter.doSign();
                break;
        }
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        presenter.detachView();
    }

    @Override
    public void showToast(String msg) {
        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
    }

    @Override
    public String getUserName() {
        return userNameEditText.getText().toString();
    }

    @Override
    public String getMailAddr() {
        return mailAddrEditText.getText().toString();
    }

    @Override
    public String getPaswd() {
        return paswdEditText.getText().toString();
    }

    @Override
    public String getPaswdConfirm() {
        return paswdConfirmEditText.getText().toString();
    }

    @Override
    public void showSignProgressDialog() {
        progressDialog.show();
    }

    @Override
    public void closeSignProgressDialog() {
        progressDialog.dismiss();
    }
}
