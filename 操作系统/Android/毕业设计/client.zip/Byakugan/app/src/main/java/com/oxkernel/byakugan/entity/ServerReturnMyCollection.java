package com.oxkernel.byakugan.entity;

import java.util.List;

/**
 * Created by 31222 on 2018/4/9.
 */

public class ServerReturnMyCollection {
    private int code;
    private String msg;
    private int totalCount;
    private List<Collection> collections;

    public void setTotalCount(int n){
        totalCount = n;
    }

    public int getTotalCount(){
        return totalCount;
    }

    public void setCode(int n){
        code = n;
    }

    public int getCode(){
        return code;
    }

    public void setMsg(String str){
        msg = str;
    }

    public String getMsg(){
        return msg;
    }

    public void setCollections(List<Collection> c){
        collections = c;
    }

    public List<Collection> getCollections(){
        return collections;
    }

    public static class Collection{
        String title;
        String article_id;

        public void setTitle(String title){
            this.title = title;
        }

        public String getTitle(){
            return title;
        }

        public void setArticle_id(String id){
            article_id = id;
        }

        public String getArticle_id(){
            return article_id;
        }
    }
}
