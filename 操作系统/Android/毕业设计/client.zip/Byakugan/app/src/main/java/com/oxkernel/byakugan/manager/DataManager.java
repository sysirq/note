package com.oxkernel.byakugan.manager;

import android.content.Context;

import com.oxkernel.byakugan.entity.ServerReturnArticleList;
import com.oxkernel.byakugan.entity.ServerReturnCollection;
import com.oxkernel.byakugan.entity.ServerReturnComment;
import com.oxkernel.byakugan.entity.ServerReturnDetail;
import com.oxkernel.byakugan.entity.ServerReturnMyCollection;
import com.oxkernel.byakugan.entity.ServerReturnMyComment;
import com.oxkernel.byakugan.entity.ServerReturnMyHead;
import com.oxkernel.byakugan.entity.ServerReturnMyMessage;
import com.oxkernel.byakugan.entity.ServerReturnMyReply;
import com.oxkernel.byakugan.entity.ServerReturnStateForLogin;
import com.oxkernel.byakugan.entity.ServerReturnStateForSignUp;
import com.oxkernel.byakugan.entity.UserInfo;
import com.oxkernel.byakugan.retrofit.RetrofitHelper;
import com.oxkernel.byakugan.retrofit.RetrofitService;

import retrofit2.http.Query;
import rx.Observable;


/**
 * Created by i-lizhixi on 2018/3/26.
 */

public class DataManager {
    private RetrofitService mRetrofitService;

    public DataManager(Context context){
        this.mRetrofitService = RetrofitHelper.getInstance(context).getServer();
    }
    public Observable<ServerReturnStateForSignUp> signUp(String name, String mail, String paswd){
        return mRetrofitService.signUp(name,mail,paswd);
    }

    public Observable<ServerReturnStateForLogin> login(String name,String password){
        return mRetrofitService.login(name,password);
    }

    public Observable<UserInfo> userInfo(String sessionId){
        return mRetrofitService.userInfo(sessionId);
    }

    public Observable<ServerReturnArticleList> getArticleList(int start, int count,String type){
        return mRetrofitService.getArticleList(start,count,type);
    }


    public Observable<ServerReturnDetail> getDetail(String id,String sessionId){
        return mRetrofitService.getDetail(id,sessionId);
    }

    public Observable<ServerReturnCollection> setCollection(String id,String sessionId ,int state){
        return mRetrofitService.setCollection(id,sessionId,state);
    }

    public Observable<ServerReturnComment> setComment(String id, String sessionId , String content){
        return mRetrofitService.setComment(id,sessionId,content);
    }

    public Observable<ServerReturnComment> getComment(String id, int start, int count){
        return mRetrofitService.getComment(id,start,count);
    }

    public Observable<ServerReturnComment> setReply( String comment_id, String sessionId, String to_u, String content){
        return mRetrofitService.setReply(comment_id,sessionId,to_u,content);
    }

    public Observable<ServerReturnComment.Comment> getReply(String comment_id, int start, int count){
        return mRetrofitService.getReply(comment_id,start,count);
    }

    public Observable<ServerReturnMyCollection> getMyCollection(String sessionId, int start, int count){
        return mRetrofitService.getMyCollection(sessionId,start,count);
    }

    public Observable<ServerReturnMyComment> getMyComment(String sessionId, int start, int count){
        return mRetrofitService.getMyComment(sessionId,start,count);
    }

    public Observable<ServerReturnMyReply> getMyReply(String sessionId, int start, int count){
        return mRetrofitService.getMyReply(sessionId,start,count);
    }

    public Observable<ServerReturnMyMessage> getMyMessage(String sessionId, int start, int count){
        return mRetrofitService.getMyMessage(sessionId,start,count);
    }

    public Observable<ServerReturnMyHead> getHeadImageAddr(int start, int count){
        return mRetrofitService.getHeadImageAddr(start,count);
    }

    public Observable<ServerReturnMyHead> setHeadImage(String sessionId, int index){
        return mRetrofitService.setHeadImage(sessionId,index);
    }

    public Observable<ServerReturnArticleList> getSearchList(String content,int start,int count){
        return mRetrofitService.getSearchList(content,start,count);
    }
}
