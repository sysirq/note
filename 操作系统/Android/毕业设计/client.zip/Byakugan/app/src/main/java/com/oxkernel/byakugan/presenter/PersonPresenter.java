package com.oxkernel.byakugan.presenter;

import android.content.Context;

import com.oxkernel.byakugan.base.BasePresenter;
import com.oxkernel.byakugan.base.MyTools;
import com.oxkernel.byakugan.entity.ServerReturnStateForLogin;
import com.oxkernel.byakugan.entity.UserInfo;
import com.oxkernel.byakugan.manager.DataManager;
import com.oxkernel.byakugan.view.PersonView;

import rx.Observer;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by 31222 on 2018/3/27.
 */

public class PersonPresenter extends BasePresenter<PersonView> {
    private Context mContext;
    private DataManager manager;

    public PersonPresenter(Context mContext){
        this.mContext = mContext;
        manager = new DataManager(mContext);
    }

    public void getUserInfo(){//获取用户信息
        getSubscription().add(manager.userInfo(MyTools.session_id)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<UserInfo>(){
                    private UserInfo userInfo;
                    @Override
                    public void onNext(UserInfo value) {
                        userInfo = value;
                    }

                    @Override
                    public void onCompleted() {
                        if(userInfo.getCode() == 0){
                            //success
                            mvpView.setLoginedName(userInfo.getName());
                            mvpView.setHeadImage(userInfo.getHead_image());
                            mvpView.new_message(userInfo.getNew_message());
                        }
                        else {
                            //fail
                            MyTools.session_id = "";
                            mvpView.setLoginedName(userInfo.getName());
                            mvpView.setHeadImage(userInfo.getHead_image());
                            mvpView.showToast(userInfo.getMsg()
                            );
                        }

                    }

                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        MyTools.session_id = "";
                        mvpView.setLoginedName(null);
                        mvpView.setHeadImage(null);
                        mvpView.showToast("请求失败");
                    }
                }));
    }
}
