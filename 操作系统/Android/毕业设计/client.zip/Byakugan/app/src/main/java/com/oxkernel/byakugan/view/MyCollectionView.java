package com.oxkernel.byakugan.view;

import com.oxkernel.byakugan.base.BaseView;
import com.oxkernel.byakugan.entity.ServerReturnCollection;
import com.oxkernel.byakugan.entity.ServerReturnComment;
import com.oxkernel.byakugan.entity.ServerReturnMyCollection;

/**
 * Created by 31222 on 2018/4/9.
 */

public interface MyCollectionView extends BaseView {
    void loadMoreData();
    void loadComplete();

    void addItem(ServerReturnMyCollection.Collection item);
    void setTotalCount(int n);
    void notifyListAdapterDataChange();

    int getTotalCount();
    void clearItems();
}
