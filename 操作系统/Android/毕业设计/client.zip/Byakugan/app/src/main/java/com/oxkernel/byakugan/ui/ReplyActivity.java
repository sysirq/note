package com.oxkernel.byakugan.ui;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.oxkernel.byakugan.ListViewAdapter.CommentListViewAdapter;
import com.oxkernel.byakugan.ListViewAdapter.ReplyListViewAdapter;
import com.oxkernel.byakugan.R;
import com.oxkernel.byakugan.base.MyTools;
import com.oxkernel.byakugan.entity.ServerReturnComment;
import com.oxkernel.byakugan.presenter.ReplyPresenter;
import com.oxkernel.byakugan.presenter.ResetPaswdPresenter;
import com.oxkernel.byakugan.view.ReplyView;

import java.util.ArrayList;

/**
 * Created by 31222 on 2018/4/8.
 */

public class ReplyActivity extends AppCompatActivity implements View.OnClickListener,ReplyView,SwipeRefreshLayout.OnRefreshListener,AbsListView.OnScrollListener,AdapterView.OnItemClickListener {
    private Toolbar myToolbar;
    private ImageView returnImageView;

    private ListView replyListView;
    private ReplyListViewAdapter myAdapter;
    private View moreView;
    private SwipeRefreshLayout swipeRefreshLayout;

    private ReplyPresenter presenter;

    private ArrayList<ServerReturnComment.Comment.Reply> items = new ArrayList<ServerReturnComment.Comment.Reply>();
    private int totalCount;//服务器中，总的数据量
    private Boolean isBottom;//到底部了

    private String comment_id;

    protected void onCreate(Bundle savedInstanceState) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {//沉浸式设置
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reply);
        //intent中的数据获取
        Intent intent = getIntent();
        comment_id = intent.getStringExtra(MyTools.INTENT_COMMENT_ID);

        presenter = new ReplyPresenter(this);
        presenter.attachView(this);

        initViews();

        presenter.doFirstGetReplys(comment_id);
    }


    @Override
    protected void onDestroy(){
        super.onDestroy();
        presenter.detachView();
    }

    private void initViews(){
        myToolbar = findViewById(R.id.my_toolbar_reply);
        myToolbar.setTitle("");
        setSupportActionBar(myToolbar);

        swipeRefreshLayout = this.findViewById(R.id.reply_list_refreshLayout);
        swipeRefreshLayout.setColorSchemeColors(android.R.color.holo_blue_bright,android.R.color.holo_orange_light,android.R.color.holo_green_light);
        swipeRefreshLayout.setOnRefreshListener(this);

        returnImageView = findViewById(R.id.reply_image_return);
        returnImageView.setOnClickListener(this);

        moreView = getLayoutInflater().inflate(R.layout.list_view_reply_more_data,null);
        moreView.setVisibility(View.GONE);

        replyListView = findViewById(R.id.reply_list_view);
        replyListView.addFooterView(moreView,null,false);

        myAdapter = new ReplyListViewAdapter(this,items,this,presenter);

        replyListView.setAdapter(myAdapter);
        replyListView.setOnScrollListener(this);
        replyListView.setOnItemClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.reply_image_return:
                finish();
                break;
        }
    }

    @Override
    public void showToast(String msg) {
        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRefresh() {
        presenter.doRefresh(comment_id);
    }

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {
        if(scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE){
            if(isBottom && totalCount > items.size()){
                presenter.doGetItems(comment_id,items.size());
            }
            if(isBottom && totalCount == items.size()){
                showToast("已经全部加载完毕");
            }
        }
    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
        if(firstVisibleItem + visibleItemCount == totalItemCount){
            isBottom = true;
        }
        else{
            isBottom = false;
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void loadMoreData() {
        moreView.setVisibility(View.VISIBLE);
    }

    @Override
    public void loadComplete() {
        moreView.setVisibility(View.GONE);
    }

    @Override
    public int getTotalCount() {
        return totalCount;
    }

    @Override
    public void setRefreshing(Boolean b) {
        if(b == true) {

        }
        else{
            swipeRefreshLayout.setRefreshing(b);
        }
    }

    @Override
    public void clearItems() {
        items.clear();
    }

    @Override
    public String getComment_id() {
        return comment_id;
    }

    @Override
    public void notifyListAdapterDataChange() {
        myAdapter.notifyDataSetChanged();
    }

    @Override
    public void setTotalCount(int n) {
        totalCount = n;
    }

    @Override
    public void addItem(ServerReturnComment.Comment.Reply item) {
        items.add(item);
    }
}
