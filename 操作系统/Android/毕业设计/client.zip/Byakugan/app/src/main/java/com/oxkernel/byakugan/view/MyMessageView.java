package com.oxkernel.byakugan.view;

import com.oxkernel.byakugan.base.BaseView;
import com.oxkernel.byakugan.entity.ServerReturnMyMessage;
import com.oxkernel.byakugan.entity.ServerReturnMyReply;

/**
 * Created by 31222 on 2018/4/9.
 */

public interface MyMessageView  extends BaseView{
    void loadMoreData();
    void loadComplete();

    void addItem(ServerReturnMyMessage.Message item);
    void setTotalCount(int n);
    void notifyListAdapterDataChange();

    int getTotalCount();

    void setRefreshing(Boolean b);

    void clearItems();
}
