package com.oxkernel.byakugan.presenter;

import android.content.Context;

import com.oxkernel.byakugan.base.BasePresenter;
import com.oxkernel.byakugan.base.MyTools;
import com.oxkernel.byakugan.entity.ServerReturnArticleList;
import com.oxkernel.byakugan.manager.DataManager;
import com.oxkernel.byakugan.view.ArticleListView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import rx.Observer;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by 31222 on 2018/3/28.
 */

public class ArticleListPresenter extends BasePresenter<ArticleListView> {
    private Context mContext;
    private DataManager manager;
    private static int count = 6;
    private String type;

    public ArticleListPresenter(Context mContext, String type){
        this.mContext = mContext;
        manager = new DataManager(mContext);
        this.type = type;
    }

    public void doFirstGetItems(){
        getSubscription().add(manager.getArticleList(0, count,type)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ServerReturnArticleList>(){
                    private ServerReturnArticleList serverReturnArticleList;
                    @Override
                    public void onCompleted() {
                        ArrayList<HashMap<String,Object>> items = new ArrayList<HashMap<String,Object>>();

                        List<ServerReturnArticleList.Data> data = serverReturnArticleList.getData();
                        for(int i=0;data!= null && i<data.size();i++) {
                            ServerReturnArticleList.Data a = data.get(i);

                            HashMap<String, Object> map = new HashMap<String, Object>();
                            map.put(MyTools.BUG_LIST_ITEM_ID, a.getId());
                            map.put(MyTools.BUG_LIST_ITEM_TIME, a.getTime());
                            map.put(MyTools.BUG_LIST_ITEM_TITLE, a.getTitle());
                            map.put(MyTools.BUG_LIST_ITEM_SOURCE, a.getSource());
                            map.put(MyTools.BUG_LIST_ITEM_DESCRIPTION, a.getDescription());
                            items.add(map);

                        }
                        mvpView.addItems(items);
                        mvpView.setTotalCount(serverReturnArticleList.getTotalCount());
                        mvpView.notifyListAdapterDataChange();
                    }

                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        mvpView.showToast("请求失败");
                    }

                    @Override
                    public void onNext(ServerReturnArticleList value) {
                        serverReturnArticleList = value;
                    }
                }));;
    }

    public void doGetItems(int start){
        mvpView.loadMoreData();

        getSubscription().add(manager.getArticleList(start, count,type)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ServerReturnArticleList>(){
                    private ServerReturnArticleList serverReturnArticleList;
                    @Override
                    public void onCompleted() {
                        ArrayList<HashMap<String,Object>> items = new ArrayList<HashMap<String,Object>>();

                        List<ServerReturnArticleList.Data> data = serverReturnArticleList.getData();
                        for(int i=0;data!= null && i<data.size();i++) {
                            ServerReturnArticleList.Data a = data.get(i);

                            HashMap<String, Object> map = new HashMap<String, Object>();
                            map.put(MyTools.BUG_LIST_ITEM_ID, a.getId());
                            map.put(MyTools.BUG_LIST_ITEM_TIME, a.getTime());
                            map.put(MyTools.BUG_LIST_ITEM_TITLE, a.getTitle());
                            map.put(MyTools.BUG_LIST_ITEM_SOURCE, a.getSource());
                            map.put(MyTools.BUG_LIST_ITEM_DESCRIPTION, a.getDescription());
                            items.add(map);

                        }
                        mvpView.addItems(items);
                        mvpView.setTotalCount(serverReturnArticleList.getTotalCount());
                        mvpView.notifyListAdapterDataChange();
                        mvpView.loadComplete();
                    }

                    @Override
                    public void onError(Throwable e) {
                        mvpView.loadComplete();
                        e.printStackTrace();
                        mvpView.showToast("请求失败");
                    }

                    @Override
                    public void onNext(ServerReturnArticleList value) {
                        serverReturnArticleList = value;
                    }
                }));;
    }

    public void doRefresh(){
        getSubscription().add(manager.getArticleList(0, count,type)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ServerReturnArticleList>(){
                    private ServerReturnArticleList serverReturnArticleList;
                    @Override
                    public void onCompleted() {

                        ArrayList<HashMap<String,Object>> items = new ArrayList<HashMap<String,Object>>();

                        List<ServerReturnArticleList.Data> data = serverReturnArticleList.getData();
                        for(int i=0;data != null && i<data.size();i++) {
                            ServerReturnArticleList.Data a = data.get(i);

                            HashMap<String, Object> map = new HashMap<String, Object>();
                            map.put(MyTools.BUG_LIST_ITEM_ID, a.getId());
                            map.put(MyTools.BUG_LIST_ITEM_TIME, a.getTime());
                            map.put(MyTools.BUG_LIST_ITEM_TITLE, a.getTitle());
                            map.put(MyTools.BUG_LIST_ITEM_SOURCE, a.getSource());
                            map.put(MyTools.BUG_LIST_ITEM_DESCRIPTION, a.getDescription());
                            items.add(map);

                        }

                        mvpView.clearItems();
                        mvpView.addItems(items);

                        mvpView.setTotalCount(serverReturnArticleList.getTotalCount());
                        mvpView.notifyListAdapterDataChange();

                        mvpView.setRefreshing(false);
                    }

                    @Override
                    public void onError(Throwable e) {
                        mvpView.setRefreshing(false);
                        e.printStackTrace();
                        mvpView.showToast("请求失败");
                    }

                    @Override
                    public void onNext(ServerReturnArticleList value) {
                        serverReturnArticleList = value;
                    }
                }));;
    }
}
