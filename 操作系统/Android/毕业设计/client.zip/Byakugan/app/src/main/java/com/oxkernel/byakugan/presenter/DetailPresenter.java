package com.oxkernel.byakugan.presenter;

import android.content.Context;

import com.oxkernel.byakugan.base.BasePresenter;
import com.oxkernel.byakugan.base.MyTools;
import com.oxkernel.byakugan.entity.ServerReturnCollection;
import com.oxkernel.byakugan.entity.ServerReturnDetail;
import com.oxkernel.byakugan.manager.DataManager;
import com.oxkernel.byakugan.view.DetailView;

import rx.Observer;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by 31222 on 2018/4/6.
 */

public class DetailPresenter extends BasePresenter<DetailView> {
    private Context mContext;
    private DataManager manager;

    public DetailPresenter(Context mContext){
        this.mContext = mContext;
        manager = new DataManager(mContext);
    }

    public void doGetDetail(String id,String sessionId){
        getSubscription().add(manager.getDetail(id,sessionId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ServerReturnDetail>(){
                    private ServerReturnDetail detail;

                    @Override
                    public void onCompleted() {
                        if(detail.getCode() == 0) {//成功
                            mvpView.loadContent(detail.getContent());
                            mvpView.setCollection( detail.getIsCollection(),detail.getCollectionCount());
                            mvpView.setComment(detail.getIsComment(),detail.getCommentCount());
                        }
                        else{
                            mvpView.showToast(detail.getMsg());
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        mvpView.showToast("请求失败");
                    }

                    @Override
                    public void onNext(ServerReturnDetail serverReturnDetail) {
                        detail = serverReturnDetail;
                    }
                }));
    }

    public void doCollection(String id,int state){
        getSubscription().add(manager.setCollection(id, MyTools.session_id,state)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ServerReturnCollection>() {
                    ServerReturnCollection serverReturn;
                    @Override
                    public void onCompleted() {
                        if(serverReturn.getCode() == 0){
                            mvpView.setCollection(serverReturn.getIsCollection(),serverReturn.getCollectionCount());
                        }
                        else{
                            mvpView.showToast(serverReturn.getMsg());
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        mvpView.showToast("请求失败");
                    }

                    @Override
                    public void onNext(ServerReturnCollection serverReturnCollection) {
                        serverReturn = serverReturnCollection;
                    }
                }));
    }

    public void getCommentReplyInfo(String id,String sessionId){
        getSubscription().add(manager.getDetail(id,sessionId)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ServerReturnDetail>(){
                    private ServerReturnDetail detail;

                    @Override
                    public void onCompleted() {
                        if(detail.getCode() == 0) {//成功
                            mvpView.setCollection( detail.getIsCollection(),detail.getCollectionCount());
                            mvpView.setComment(detail.getIsComment(),detail.getCommentCount());
                        }
                        else{
                            mvpView.showToast(detail.getMsg());
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        mvpView.showToast("请求失败");
                    }

                    @Override
                    public void onNext(ServerReturnDetail serverReturnDetail) {
                        detail = serverReturnDetail;
                    }
                }));
    }
}
