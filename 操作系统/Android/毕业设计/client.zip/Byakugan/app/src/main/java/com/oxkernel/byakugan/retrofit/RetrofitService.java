package com.oxkernel.byakugan.retrofit;

import com.oxkernel.byakugan.entity.ServerReturnArticleList;
import com.oxkernel.byakugan.entity.ServerReturnCollection;
import com.oxkernel.byakugan.entity.ServerReturnComment;
import com.oxkernel.byakugan.entity.ServerReturnDetail;
import com.oxkernel.byakugan.entity.ServerReturnMyCollection;
import com.oxkernel.byakugan.entity.ServerReturnMyComment;
import com.oxkernel.byakugan.entity.ServerReturnMyHead;
import com.oxkernel.byakugan.entity.ServerReturnMyMessage;
import com.oxkernel.byakugan.entity.ServerReturnMyReply;
import com.oxkernel.byakugan.entity.ServerReturnStateForLogin;
import com.oxkernel.byakugan.entity.ServerReturnStateForSignUp;
import com.oxkernel.byakugan.entity.UserInfo;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;
import rx.Observable;

/**
 * Created by i-lizhixi on 2018/3/23.
 */

public interface RetrofitService {
    @FormUrlEncoded
    @POST("sign_up.php")
    Observable<ServerReturnStateForSignUp> signUp(@Field("name") String name,
                                                  @Field("mail") String mail,
                                                  @Field("paswd") String paswd);

    @FormUrlEncoded
    @POST("login.php")
    Observable<ServerReturnStateForLogin> login(@Field("name") String name,
                                                @Field("password") String password);

    @FormUrlEncoded
    @POST("user_info.php")
    Observable<UserInfo> userInfo(@Field("sessionId") String sessionId);

    @GET("getArticleList.php")
    Observable<ServerReturnArticleList> getArticleList(@Query("start") int start, @Query("count") int count, @Query("type") String type);

    @GET("getDetail.php")
    Observable<ServerReturnDetail> getDetail(@Query("id") String id,@Query("sessionId") String sessionId);

    @GET("setCollection.php")
    Observable<ServerReturnCollection> setCollection(@Query("id") String id, @Query("sessionId") String sessionId,@Query("state") int state);

    @GET("setComment.php")
    Observable<ServerReturnComment> setComment(@Query("id") String id, @Query("sessionId") String sessionId, @Query("content") String content);

    @GET("getComment.php")
    Observable<ServerReturnComment> getComment(@Query("id") String id, @Query("start") int start, @Query("count") int count);

    @GET("setReply.php")
    Observable<ServerReturnComment> setReply(@Query("comment_id") String comment_id, @Query("sessionId") String sessionId,
                                             @Query("to_u") String to_u,@Query("content") String content);

    @GET("getReply.php")
    Observable<ServerReturnComment.Comment> getReply(@Query("comment_id") String comment_id, @Query("start") int start, @Query("count") int count);

    @GET("getMyCollection.php")
    Observable<ServerReturnMyCollection> getMyCollection(@Query("sessionId") String sessionId, @Query("start") int start, @Query("count") int count);

    @GET("getMyComment.php")
    Observable<ServerReturnMyComment> getMyComment(@Query("sessionId") String sessionId, @Query("start") int start, @Query("count") int count);

    @GET("getMyReply.php")
    Observable<ServerReturnMyReply> getMyReply(@Query("sessionId") String sessionId, @Query("start") int start, @Query("count") int count);

    @GET("getMyMessage.php")
    Observable<ServerReturnMyMessage> getMyMessage(@Query("sessionId") String sessionId, @Query("start") int start, @Query("count") int count);

    @GET("getHeadImageAddr.php")
    Observable<ServerReturnMyHead> getHeadImageAddr(@Query("start") int start, @Query("count") int count);

    @GET("setHeadImage.php")
    Observable<ServerReturnMyHead> setHeadImage(@Query("sessionId") String sessionId, @Query("index") int index);

    @GET("getSearchList.php")
    Observable<ServerReturnArticleList> getSearchList(@Query("content") String content,@Query("start") int start, @Query("count") int count);
}
