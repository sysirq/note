package com.oxkernel.byakugan.ListViewAdapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.oxkernel.byakugan.R;
import com.oxkernel.byakugan.base.MyTools;
import com.oxkernel.byakugan.entity.ServerReturnMyMessage;
import com.oxkernel.byakugan.retrofit.RetrofitHelper;
import com.oxkernel.byakugan.ui.DetailActivity;

import java.util.ArrayList;

import jp.wasabeef.glide.transformations.CropCircleTransformation;

/**
 * Created by 31222 on 2018/4/9.
 */

public class MyHeadChangeListViewAdapter extends BaseAdapter {
    private Context mContext;
    private ArrayList<String> items;
    private LayoutInflater mInflater;

    public MyHeadChangeListViewAdapter(Context context, ArrayList<String> items){
        mContext =  context;
        this.items = items;
        mInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if(convertView == null){
            convertView = mInflater.inflate(R.layout.list_view_my_head_change_item,null);
            holder = new ViewHolder();

            holder.head = convertView.findViewById(R.id.h_head_change);

            convertView.setTag(holder);
        }
        else{
            holder =  (ViewHolder)convertView.getTag();
        }

        String item = items.get(position);
        String addr = MyTools.baseUrl+"head/"+item;

        Glide.with(mContext).load(addr).bitmapTransform(new CropCircleTransformation(mContext)).into((ImageView) holder.head);

        return convertView;
    }
    public class ViewHolder{
        public ImageView head;
    }
}
