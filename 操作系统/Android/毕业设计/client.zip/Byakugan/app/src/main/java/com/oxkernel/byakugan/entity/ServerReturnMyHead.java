package com.oxkernel.byakugan.entity;

import java.util.List;

/**
 * Created by 31222 on 2018/4/9.
 */

public class ServerReturnMyHead {
    private int code;
    private String msg;
    private int totalCount;
    private List<String> addrs;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public List<String> getAddrs() {
        return addrs;
    }

    public void setAddrs(List<String> addrs) {
        this.addrs = addrs;
    }
}
