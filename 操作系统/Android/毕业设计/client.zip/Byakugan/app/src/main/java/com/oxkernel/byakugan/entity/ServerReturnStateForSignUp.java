package com.oxkernel.byakugan.entity;

/**
 * Created by 31222 on 2018/3/26.
 */

public class ServerReturnStateForSignUp {
    private int code;
    private String msg;

    public void setCode(int code){
        this.code = code;
    }

    public int getCode(){
        return code;
    }

    public void setMsg(String msg){
        this.msg = msg;
    }

    public String getMsg(){
        return msg;
    }
}
