package com.oxkernel.byakugan.entity;

/**
 * Created by 31222 on 2018/3/27.
 */

public class UserInfo {
    private String name;
    private String mail;
    private String head_image;
    private String msg;
    private int code;

    public int getNew_message() {
        return new_message;
    }

    public void setNew_message(int new_message) {
        this.new_message = new_message;
    }

    private int new_message;

    public void setName(String name){
        this.name = name;
    }

    public void setMail(String mail){
        this.mail = mail;
    }

    public void setHead_image(String head_image){
        this.head_image = head_image;
    }

    public void setCode(int code){
        this.code = code;
    }

    public void setMsg(String msg){
        this.msg = msg;
    }

    public String getName(){
        return name;
    }

    public String getMail(){
        return mail;
    }

    public String getHead_image(){
        return head_image;
    }

    public String getMsg(){
        return msg;
    }

    public int getCode(){
        return code;
    }
}
