package com.oxkernel.byakugan.ui;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.oxkernel.byakugan.R;
import com.oxkernel.byakugan.base.BasePresenter;
import com.oxkernel.byakugan.base.HtmlFormat;
import com.oxkernel.byakugan.base.MyTools;
import com.oxkernel.byakugan.presenter.DetailPresenter;
import com.oxkernel.byakugan.view.DetailView;

import java.net.Inet4Address;

/**
 * Created by 31222 on 2018/4/6.
 * 文章详情页面
 */

public class DetailActivity extends AppCompatActivity implements DetailView,View.OnClickListener {
    private ImageView returnImageView;
    private Toolbar myToolbar;
    private TextView myToolbarTitle;
    private WebView webView;

    private ImageView collectionImageView;
    private ImageView commentImageView;
    private TextView collectionTextView;
    private TextView commentTextView;

    private View collection_layout;
    private View comment_layout;

    //保存利用intent传递过来的数据
    private String source;
    private String title;
    private String id;

    private int isCollection = 0;

    private DetailPresenter presenter;

    protected void onCreate(Bundle savedInstanceState) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {//沉浸式设置
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        //获取通过intent 传递过来的数据
        Intent intent = getIntent();
        source = intent.getStringExtra(MyTools.INTENT_SOURCE);
        id = intent.getStringExtra(MyTools.INTENT_ID);
        title = intent.getStringExtra(MyTools.INTENT_TITLE);
        //showToast("source: "+source+" id: "+id+" title: "+title);

        initViews();

        presenter = new DetailPresenter(this);
        presenter.attachView(this);
        presenter.doGetDetail(id,MyTools.session_id);

    }

    @Override
    protected void onRestart() {
        super.onRestart();
        presenter.getCommentReplyInfo(id,MyTools.session_id);
        Log.e("info", "DetailActivity onRestart~~~");
    }


    @Override
    protected void onDestroy(){
        super.onDestroy();
        presenter.detachView();
    }

    public void initViews(){
        myToolbar = findViewById(R.id.my_toolbar_detail);
        myToolbar.setTitle("");
        setSupportActionBar(myToolbar);

        returnImageView = findViewById(R.id.detail_image_return);
        returnImageView.setOnClickListener(this);

        myToolbarTitle = findViewById(R.id.my_toolbar_title_detail);

        webView = findViewById(R.id.detail_webview);
//        WebSettings settings = webView.getSettings();
//        settings.setUseWideViewPort(true);
//        settings.setLoadWithOverviewMode(true);

        collectionImageView = findViewById(R.id.collect_image);
        collectionTextView = findViewById(R.id.collect_text);

        commentImageView = findViewById(R.id.comment_image);
        commentTextView = findViewById(R.id.comment_text);

        collection_layout = findViewById(R.id.collect_layout);
        comment_layout = findViewById(R.id.comment_layout);

        collection_layout.setOnClickListener(this);
        comment_layout.setOnClickListener(this);

        setCollection(0,0);
        setComment(0,0);
    }

    @Override
    public void showToast(String msg) {
        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.detail_image_return:
                finish();
                break;
            case R.id.collect_layout://收藏
                if(isCollection == 0) {
                    presenter.doCollection(id, 1);
                }
                else{
                    presenter.doCollection(id, 0);
                }
                break;
            case R.id.comment_layout://评论
                Intent intent = new Intent(this,CommentActivity.class);
                intent.putExtra(MyTools.INTENT_ID,id);
                startActivity(intent);
                break;
        }
    }

    @Override
    public void loadContent(String content) {
        webView.loadDataWithBaseURL(null, HtmlFormat.getNewContent(content),"text/html","utf-8",null);
    }

    @Override
    public void setCollection(int b,int count) {
        if(b == 1){
            collectionImageView.setImageResource(R.drawable.collection_select);
            collectionTextView.setTextColor(getResources().getColor(R.color.tab_bg_text_select));
            isCollection = 1;
        }
        else{
            collectionImageView.setImageResource(R.drawable.collection);
            collectionTextView.setTextColor(getResources().getColor(R.color.tab_bg_text));
            isCollection = 0;
        }
        collectionTextView.setText("收藏数("+count+")");
    }

    @Override
    public void setComment(int b, int count) {
        if(b == 1){
            commentImageView.setImageResource(R.drawable.comment_select);
            commentTextView.setTextColor(getResources().getColor(R.color.tab_bg_text_select));
        }
        else{
            commentImageView.setImageResource(R.drawable.comment);
            commentTextView.setTextColor(getResources().getColor(R.color.tab_bg_text));
        }
        commentTextView.setText("评论数("+count+")");
    }
}
