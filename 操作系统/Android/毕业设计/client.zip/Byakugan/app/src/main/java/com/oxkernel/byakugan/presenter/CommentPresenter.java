package com.oxkernel.byakugan.presenter;

import android.content.Context;

import com.oxkernel.byakugan.base.BasePresenter;
import com.oxkernel.byakugan.base.MyTools;
import com.oxkernel.byakugan.entity.ServerReturnComment;
import com.oxkernel.byakugan.manager.DataManager;
import com.oxkernel.byakugan.view.CommentView;

import java.util.List;

import rx.Observer;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by 31222 on 2018/4/7.
 */

public class CommentPresenter extends BasePresenter<CommentView> {
    private Context mContext;
    private DataManager manager;
    private static int count = 6;//每次获得的评论条数

    public CommentPresenter(Context mContext){
        this.mContext = mContext;
        manager = new DataManager(mContext);
    }

    public void setComment(final String id, String content){//添加评论
        final String comment_id = id;
        getSubscription().add(manager.setComment(id, MyTools.session_id,content)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ServerReturnComment>() {
                    ServerReturnComment serverReturn;
                    @Override
                    public void onCompleted() {
                        if(serverReturn.getCode()==0){
                            mvpView.showToast("评论添加成功");
                            doRefresh(comment_id);
                        }
                        else{
                            mvpView.showToast(serverReturn.getMsg());
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        mvpView.showToast("请求失败");
                    }

                    @Override
                    public void onNext(ServerReturnComment serverReturnComment) {
                        serverReturn = serverReturnComment;
                    }
                })
        );
    }

    public void doFirstGetComments(String id){
        getSubscription().add(manager.getComment(id, 0,count)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ServerReturnComment>() {
                    ServerReturnComment serverReturn;
                    @Override
                    public void onCompleted() {
                        if(serverReturn.getCode()==0){//成功获得评论
                            List<ServerReturnComment.Comment> data = serverReturn.getComments();
                            for(int i=0;data!= null && i<data.size();i++){
                                mvpView.addItem(data.get(i));
                            }
                            mvpView.setTotalCount(serverReturn.getTotalCount());
                            mvpView.notifyListAdapterDataChange();
                        }
                        else{
                            mvpView.showToast(serverReturn.getMsg());
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        mvpView.showToast("请求失败");
                    }

                    @Override
                    public void onNext(ServerReturnComment serverReturnComment) {
                        serverReturn = serverReturnComment;
                    }
                }));
    }

    public void doGetItems(String id,int start){
        mvpView.loadMoreData();

        getSubscription().add(manager.getComment(id, start,count)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ServerReturnComment>() {
                    ServerReturnComment serverReturn;
                    @Override
                    public void onCompleted() {

                        if(serverReturn.getCode()==0){//成功获得评论
                            List<ServerReturnComment.Comment> data = serverReturn.getComments();
                            for(int i=0;data!= null && i<data.size();i++){
                                mvpView.addItem(data.get(i));
                            }
                            mvpView.setTotalCount(serverReturn.getTotalCount());
                            mvpView.notifyListAdapterDataChange();
                            mvpView.loadComplete();
                        }
                        else{
                            mvpView.showToast(serverReturn.getMsg());
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        mvpView.loadComplete();
                        e.printStackTrace();
                        mvpView.showToast("请求失败");
                    }

                    @Override
                    public void onNext(ServerReturnComment serverReturnComment) {
                        serverReturn = serverReturnComment;
                    }
                }));
    }

    public void doRefresh(String id){
        getSubscription().add(manager.getComment(id, 0,count)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ServerReturnComment>() {
                    ServerReturnComment serverReturn;
                    @Override
                    public void onCompleted() {
                        if(serverReturn.getCode()==0){//成功获得评论
                            mvpView.clearItems();

                            List<ServerReturnComment.Comment> data = serverReturn.getComments();
                            for(int i=0;data!=null && i<data.size();i++){
                                mvpView.addItem(data.get(i));
                            }
                            mvpView.setTotalCount(serverReturn.getTotalCount());
                            mvpView.notifyListAdapterDataChange();
                            mvpView.setRefreshing(false);
                        }
                        else{
                            mvpView.setRefreshing(false);
                            mvpView.showToast(serverReturn.getMsg());
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        mvpView.setRefreshing(false);
                        e.printStackTrace();
                        mvpView.showToast("请求失败");
                    }

                    @Override
                    public void onNext(ServerReturnComment serverReturnComment) {
                        serverReturn = serverReturnComment;
                    }
                }));
    }

    public void setReply(String comment_id,String to_u,String content){
        getSubscription().add(manager.setReply(comment_id,MyTools.session_id,to_u,content)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ServerReturnComment>(){
                    ServerReturnComment serverReturn;
                    @Override
                    public void onCompleted() {
                        if(serverReturn.getCode() == 0){
                            mvpView.showToast("回复成功");
                        }
                        else{
                            mvpView.showToast(serverReturn.getMsg());
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        mvpView.showToast("请求失败");
                    }

                    @Override
                    public void onNext(ServerReturnComment serverReturnComment) {
                        serverReturn = serverReturnComment;
                    }
                }));
    }
}
