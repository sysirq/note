package com.oxkernel.byakugan.presenter;

import android.content.Context;

import com.oxkernel.byakugan.base.BasePresenter;
import com.oxkernel.byakugan.base.MyTools;
import com.oxkernel.byakugan.entity.ServerReturnComment;
import com.oxkernel.byakugan.entity.ServerReturnMyComment;
import com.oxkernel.byakugan.entity.ServerReturnMyReply;
import com.oxkernel.byakugan.manager.DataManager;
import com.oxkernel.byakugan.view.MyReplyView;

import java.util.List;

import rx.Observer;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by 31222 on 2018/4/9.
 */

public class MyReplyPresenter extends BasePresenter<MyReplyView> {
    private Context mContext;
    private DataManager manager;
    private static int count = 10;//每次请求的数量

    public MyReplyPresenter(Context mContext){
        this.mContext = mContext;
        manager = new DataManager(mContext);
    }

    public void doFirstGetReplys(){
        getSubscription().add(manager.getMyReply(MyTools.session_id, 0,count)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ServerReturnMyReply>() {
                    ServerReturnMyReply serverReturn;
                    @Override
                    public void onCompleted() {
                        if(serverReturn.getCode()==0){
                            List<ServerReturnMyReply.Reply> data = serverReturn.getReplys();
                            for(int i=0;data!= null && i<data.size();i++){
                                mvpView.addItem(data.get(i));
                            }
                            mvpView.setTotalCount(serverReturn.getTotalCount());
                            mvpView.notifyListAdapterDataChange();
                        }
                        else{
                            mvpView.showToast(serverReturn.getMsg());
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        e.printStackTrace();
                        mvpView.showToast("请求失败");
                    }

                    @Override
                    public void onNext(ServerReturnMyReply serverReturnComment) {
                        serverReturn = serverReturnComment;
                    }
                }));
    }

    public void doGetItems(int start){
        mvpView.loadMoreData();

        getSubscription().add(manager.getMyReply(MyTools.session_id,start,count)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ServerReturnMyReply>() {
                    ServerReturnMyReply serverReturn;
                    @Override
                    public void onCompleted() {

                        if(serverReturn.getCode()==0){//
                            List<ServerReturnMyReply.Reply> data = serverReturn.getReplys();
                            for(int i=0;data!= null &&i<data.size();i++){
                                mvpView.addItem(data.get(i));
                            }
                            mvpView.setTotalCount(serverReturn.getTotalCount());
                            mvpView.notifyListAdapterDataChange();
                            mvpView.loadComplete();
                        }
                        else{
                            mvpView.showToast(serverReturn.getMsg());
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        mvpView.loadComplete();
                        e.printStackTrace();
                        mvpView.showToast("请求失败");
                    }

                    @Override
                    public void onNext(ServerReturnMyReply serverReturnComment) {
                        serverReturn = serverReturnComment;
                    }
                }));
    }

    public void doRefresh(){
        getSubscription().add(manager.getMyReply(MyTools.session_id,0,count)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ServerReturnMyReply>() {
                    ServerReturnMyReply serverReturn;
                    @Override
                    public void onCompleted() {
                        if(serverReturn.getCode()==0){//成功获得评论
                            mvpView.clearItems();

                            List<ServerReturnMyReply.Reply> data = serverReturn.getReplys();
                            for(int i=0;data!= null && i<data.size();i++){
                                mvpView.addItem(data.get(i));
                            }
                            mvpView.setTotalCount(serverReturn.getTotalCount());
                            mvpView.notifyListAdapterDataChange();
                            mvpView.setRefreshing(false);
                        }
                        else{
                            mvpView.setRefreshing(false);
                            mvpView.showToast(serverReturn.getMsg());
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        mvpView.setRefreshing(false);
                        e.printStackTrace();
                        mvpView.showToast("请求失败");
                    }

                    @Override
                    public void onNext(ServerReturnMyReply serverReturnComment) {
                        serverReturn = serverReturnComment;
                    }
                }));
    }
}
