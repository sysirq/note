package com.oxkernel.byakugan.ui;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.oxkernel.byakugan.ListViewAdapter.MyCollectionListViewAdapter;
import com.oxkernel.byakugan.R;
import com.oxkernel.byakugan.base.MyTools;
import com.oxkernel.byakugan.entity.ServerReturnMyCollection;
import com.oxkernel.byakugan.presenter.DetailPresenter;
import com.oxkernel.byakugan.presenter.MyCollectionPresenter;
import com.oxkernel.byakugan.view.MyCollectionView;

import java.util.ArrayList;


/**
 * Created by 31222 on 2018/4/9.
 */

public class MyCollectionActivity extends AppCompatActivity implements View.OnClickListener,MyCollectionView,AbsListView.OnScrollListener,AdapterView.OnItemClickListener {
    private Toolbar myToolbar;
    private ImageView returnImageView;

    private ListView collectionListView;
    private View moreView;

    private ArrayList<ServerReturnMyCollection.Collection> items = new ArrayList<ServerReturnMyCollection.Collection>();
    private MyCollectionListViewAdapter myAdapter;
    private int totalCount = 0;
    private Boolean isBottom;//到底部了

    private MyCollectionPresenter presenter;

    protected void onCreate(Bundle savedInstanceState) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {//沉浸式设置
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_collection);
        initViews();

        presenter = new MyCollectionPresenter(this);
        presenter.attachView(this);
        presenter.doFirstGetCollections();
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        presenter.detachView();
    }

    public void initViews(){
        myToolbar = findViewById(R.id.my_toolbar_my_collection);
        myToolbar.setTitle("");
        setSupportActionBar(myToolbar);

        returnImageView = findViewById(R.id.my_collection_image_return);
        returnImageView.setOnClickListener(this);

        moreView =  moreView = getLayoutInflater().inflate(R.layout.list_view_my_collection_more_data,null);
        moreView.setVisibility(View.GONE);

        collectionListView = findViewById(R.id.my_collection_list_view);
        collectionListView.addFooterView(moreView,null,false);

        myAdapter = new MyCollectionListViewAdapter(this,items);
        collectionListView.setAdapter(myAdapter);
        collectionListView.setOnScrollListener(this);
        collectionListView.setOnItemClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.my_collection_image_return:
                finish();
                break;
        }
    }

    @Override
    public void showToast(String msg) {
        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void addItem(ServerReturnMyCollection.Collection item) {//向List适配器中添加新数据
        this.items.add(item);
    }

    @Override
    public void setTotalCount(int n) {
        totalCount = n;
    }

    @Override
    public void notifyListAdapterDataChange() {
        myAdapter.notifyDataSetChanged();
    }

    @Override
    public void loadMoreData() {
        moreView.setVisibility(View.VISIBLE);
    }

    @Override
    public void loadComplete() {
        moreView.setVisibility(View.GONE);
    }

    @Override
    public int getTotalCount() {
        return totalCount;
    }

    @Override
    public void clearItems() {
        items.clear();
    }

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {
        if(scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE){
            if(isBottom && totalCount > items.size()){
                //下载更多数据
                presenter.doGetItems(items.size());
            }
            if(isBottom && totalCount == items.size()){
                showToast("已经全部加载完毕");
            }
        }
    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
        if(firstVisibleItem + visibleItemCount == totalItemCount){
            isBottom = true;
        }
        else{
            isBottom = false;
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = new Intent(this, DetailActivity.class);
        intent.putExtra(MyTools.INTENT_ID,items.get(position).getArticle_id());
        startActivity(intent);
    }
}
