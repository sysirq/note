package com.oxkernel.byakugan.ui;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.oxkernel.byakugan.ListViewAdapter.MyHeadChangeListViewAdapter;
import com.oxkernel.byakugan.ListViewAdapter.MyMessageListViewAdapter;
import com.oxkernel.byakugan.R;
import com.oxkernel.byakugan.base.MyTools;
import com.oxkernel.byakugan.entity.ServerReturnMyMessage;
import com.oxkernel.byakugan.presenter.MyHeadChangePresenter;
import com.oxkernel.byakugan.presenter.MyMessagePresenter;
import com.oxkernel.byakugan.view.MyHeadChangeView;
import com.oxkernel.byakugan.view.MyMessageView;

import java.util.ArrayList;

/**
 * Created by 31222 on 2018/4/9.
 */

public class MyHeadChangeActivity extends AppCompatActivity implements View.OnClickListener,MyHeadChangeView,AbsListView.OnScrollListener,AdapterView.OnItemClickListener,SwipeRefreshLayout.OnRefreshListener  {
    private Toolbar myToolbar;
    private ImageView returnImageView;

    private SwipeRefreshLayout swipeRefreshLayout;
    private ListView headChangeListView;
    private View moreView;

    private ArrayList<String> items = new ArrayList<String>();
    private MyHeadChangeListViewAdapter myAdapter;
    private int totalCount = 0;
    private Boolean isBottom;//到底部了

    private MyHeadChangePresenter presenter;

    private ProgressDialog progressDialog;

    protected void onCreate(Bundle savedInstanceState) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {//沉浸式设置
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_head_change);

        presenter = new MyHeadChangePresenter(this);
        presenter.attachView(this);

        initViews();

        presenter.doFirstGetHeads();


    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        presenter.detachView();
    }

    public void initViews(){
        myToolbar = findViewById(R.id.my_toolbar_my_head_change);
        myToolbar.setTitle("");
        setSupportActionBar(myToolbar);

        swipeRefreshLayout = this.findViewById(R.id.my_head_change_list_refreshLayout);
        swipeRefreshLayout.setColorSchemeColors(android.R.color.holo_blue_bright,android.R.color.holo_orange_light,android.R.color.holo_green_light);
        swipeRefreshLayout.setOnRefreshListener(this);

        returnImageView = findViewById(R.id.my_head_change_image_return);
        returnImageView.setOnClickListener(this);

        moreView =  moreView = getLayoutInflater().inflate(R.layout.list_view_my_head_change_more_data,null);
        moreView.setVisibility(View.GONE);

        headChangeListView = findViewById(R.id.my_head_change_list_view);
        headChangeListView.addFooterView(moreView,null,false);

        myAdapter = new MyHeadChangeListViewAdapter(this,items);

        headChangeListView.setAdapter(myAdapter);
        headChangeListView.setOnScrollListener(this);
        headChangeListView.setOnItemClickListener(this);

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("提示信息");
        progressDialog.setMessage("头像更换中......");
        progressDialog.setCancelable(false);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.my_head_change_image_return:
                finish();
                break;
        }
    }

    @Override
    public void showToast(String msg) {
        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void addItem(String item) {//向List适配器中添加新数据
        this.items.add(item);
    }

    @Override
    public void setTotalCount(int n) {
        totalCount = n;
    }

    @Override
    public void notifyListAdapterDataChange() {
        myAdapter.notifyDataSetChanged();
    }

    @Override
    public void loadMoreData() {
        moreView.setVisibility(View.VISIBLE);
    }

    @Override
    public void loadComplete() {
        moreView.setVisibility(View.GONE);
    }


    @Override
    public int getTotalCount() {
        return totalCount;
    }

    @Override
    public void setRefreshing(Boolean b) {
        if(b == true) {

        }
        else{
            swipeRefreshLayout.setRefreshing(b);
        }
    }


    @Override
    public void clearItems() {
        items.clear();
    }

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {
        if(scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE){
            if(isBottom && totalCount > items.size()){
                //下载更多数据
                presenter.doGetItems(items.size());
            }
            if(isBottom && totalCount == items.size()){
                showToast("已经全部加载完毕");
            }
        }
    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
        if(firstVisibleItem + visibleItemCount == totalItemCount){
            isBottom = true;
        }
        else{
            isBottom = false;
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
        final AlertDialog.Builder normalDialog = new AlertDialog.Builder(this);
        normalDialog.setTitle("确认信息");
        normalDialog.setMessage("你确认要更改为该头像?");
        normalDialog.setPositiveButton("确定",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        presenter.setHeadImage(position);
                    }
                });
        normalDialog.setNegativeButton("关闭",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
        // 显示
        normalDialog.show();
    }

    @Override
    public void onRefresh() {
        presenter.doRefresh();
    }

    @Override
    public void showSignProgressDialog() {
        progressDialog.show();
    }

    @Override
    public void closeSignProgressDialog() {
        progressDialog.dismiss();
    }

}
