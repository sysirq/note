package com.oxkernel.byakugan.presenter;

import android.content.Context;

import com.oxkernel.byakugan.base.BasePresenter;
import com.oxkernel.byakugan.base.BaseView;
import com.oxkernel.byakugan.base.MyTools;
import com.oxkernel.byakugan.entity.ServerReturnStateForLogin;
import com.oxkernel.byakugan.entity.ServerReturnStateForSignUp;
import com.oxkernel.byakugan.manager.DataManager;
import com.oxkernel.byakugan.view.LoginView;

import rx.Observer;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Created by 31222 on 2018/3/27.
 */

public class LoginPresenter extends BasePresenter<LoginView> {
    private DataManager manager;
    private Context mContext;
    private ServerReturnStateForLogin serverReturnStateForLogin;

    public LoginPresenter(Context mContext){
        this.mContext = mContext;
        manager = new DataManager(mContext);
    }

    public void doLogin(){
        String name = mvpView.getName();
        String password = mvpView.getPassword();

        if(doCheck(name,password) == false){
            return ;
        }

        mvpView.showSignProgressDialog();

        getSubscription().add(manager.login(name, password)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Observer<ServerReturnStateForLogin>(){

                    @Override
                    public void onNext(ServerReturnStateForLogin value) {
                        serverReturnStateForLogin = value;
                    }

                    @Override
                    public void onCompleted() {
                        mvpView.closeSignProgressDialog();
                        mvpView.showToast(serverReturnStateForLogin.getMsg());
                        if(serverReturnStateForLogin.getCode() == 0){
                            MyTools.session_id =  serverReturnStateForLogin.getSession_id();
                            mvpView.myFinish();
                        }
                    }

                    @Override
                    public void onError(Throwable e) {
                        mvpView.closeSignProgressDialog();
                        e.printStackTrace();
                        mvpView.showToast("请求失败");
                    }
                }));

    }

    //合法性检查
    private Boolean doCheck(String name,String password){
        if( name.isEmpty() || password.isEmpty() ){
            mvpView.showToast("请确保已经输入账号和密码");
            return false;
        }
        return true;
    }
}
