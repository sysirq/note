package com.oxkernel.byakugan.view;

import com.oxkernel.byakugan.base.BaseView;

/**
 * Created by 31222 on 2018/3/27.
 */

public interface LoginView extends BaseView {
    String getName();
    String getPassword();

    void myFinish();

    void showSignProgressDialog();
    void closeSignProgressDialog();
}
