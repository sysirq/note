package com.oxkernel.byakugan.entity;

import java.util.List;

/**
 * Created by 31222 on 2018/4/6.
 */

public class ServerReturnArticleList {
    private int totalCount;
    private List<ServerReturnArticleList.Data> data;

    public void setTotalCount(int value){
        totalCount = value;
    }

    public int getTotalCount(){
        return totalCount;
    }

    public void setData(List<ServerReturnArticleList.Data> d){
        data = d;
    }

    public List<Data> getData(){
        return data;
    }

    public static class Data{
        private String id;
        private String title;
        private String source;
        private String time;
        private String description;

        public void setId(String id){
            this.id = id;
        }
        public String getId(){
            return id;
        }

        public void setTitle(String title){
            this.title = title;
        }
        public String  getTitle(){
            return title;
        }

        public void setSource(String source){
            this.source = source;
        }
        public String getSource(){
            return source;
        }

        public void setTime(String time){
            this.time = time;
        }
        public String getTime(){
            return time;
        }

        public void setDescription(String description){
            this.description = description;
        }
        public String getDescription(){
            return description;
        }
    }
}
