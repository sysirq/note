<?php
require "session/session_check.php";
require "sql/sql_connection_begin.php";

//参数获取
$name = $_SESSION['name'];
//$name = "lizhixi";
$start = $_GET['start'];
$count = $_GET['count'];

//返回数据初始化
$code = 0;
$msg = "";
$totalCount = 0;
$collections = array();

//totalCount获取
$sql = "SELECT count(*) as cont FROM t_collection WHERE name='$name'";
$result = $conn->query($sql);
if($result->num_rows > 0){
	$row = $result->fetch_assoc();
	$totalCount = $row['cont'];
}

//收藏数据获取
$sql = "SELECT article_id,title FROM t_collection,t_article_detail WHERE name ='$name' AND t_collection.article_id = t_article_detail.id order by t_collection.time desc limit $start,$count";
$result = $conn->query($sql);
if($result->num_rows > 0){
	while($row = $result->fetch_assoc()){
		$collection['title'] = $row['title'];
		$collection['article_id'] = $row['article_id'];
		$collections[] = $collection;
	}
}

echo json_encode(array("code"=>$code,'msg'=>$msg,"totalCount"=>$totalCount,"collections"=>$collections));

require "sql/sql_connection_end.php";
?>
