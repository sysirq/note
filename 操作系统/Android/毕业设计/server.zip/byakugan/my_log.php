<?php
function myLog($str){
	error_log(date('y-m-d h:i:s',time())." ".$str."\n",3,"/home/dog/code/cat_dog/log/cat_dog.log");
}
?>
