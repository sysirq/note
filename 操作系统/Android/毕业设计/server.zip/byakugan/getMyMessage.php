<?php
require "session/session_check.php";
require "sql/sql_connection_begin.php";

//参数获取
$name = $_SESSION['name'];
//$name = "lizhixi";
$start = $_GET['start'];
$count = $_GET['count'];

//返回数据初始化
$code = 0;
$msg = "";
$totalCount = 0;
$messages = array();

//totalCount获取
$sql = "SELECT count(*) as cont FROM t_reply WHERE to_u='$name'";
$result = $conn->query($sql);
if($result->num_rows > 0){
	$row = $result->fetch_assoc();
	$totalCount = $row['cont'];
}

//评论数据获取
$sql = "SELECT t_comment.id as comment_id,article_id,title,t_reply.time as time,t_reply.content as content,t_reply.from_u as from_u FROM t_comment,t_article_detail,t_reply WHERE t_reply.to_u ='$name' AND t_reply.comment_id = t_comment.id AND t_comment.article_id = t_article_detail.id order by t_reply.time desc limit $start,$count";

$result = $conn->query($sql);
if($result->num_rows > 0){
	while($row = $result->fetch_assoc()){
		$message['comment_id'] = $row['comment_id'];
		$message['article_id'] = $row['article_id'];
		$message['title'] = $row['title'];
		$message['from_u'] = $row['from_u'];
		$message['to_u'] = $name;
		$message['time'] = $row['time'];
		$message['content'] = $row['content'];
		$messages[] = $message;
	}
}

if($start == 0){
	//时间修改
	$time = date("Y-m-d H:i:s");
	$sql = "UPDATE t_user_info SET last_get_message_time='$time' WHERE name = '$name'";
	if($conn->query($sql) != TRUE){
		$code = 3;
		$msg = "数据库错误";
		goto end;
	}
}

end:

echo json_encode(array("code"=>$code,'msg'=>$msg,"totalCount"=>$totalCount,"messages"=>$messages));

require "sql/sql_connection_end.php";
?>
