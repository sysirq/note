<?php
require "session/session_check.php";
require "sql/sql_connection_begin.php";


//返回数据初始化
$name = $_SESSION['name'];
$mail = $_SESSION['mail'];
$head_image = "";
$new_message = 0;
//头像地址以及最后一次消息获取时间获取
$sql = "SELECT head_image,last_get_message_time FROM t_user_info WHERE name = '$name'";
$result = $conn->query($sql);
if($result->num_rows > 0){
	$rows = $result->fetch_assoc();
	$head_image = $rows['head_image'];
	$time = $rows['last_get_message_time'];
}

//是否有新消息
$sql = "SELECT count(*) as cont FROM t_reply WHERE to_u = '$name' AND time >= '$time'";
$result = $conn->query($sql);
if($result->num_rows>0){
	$rows = $result->fetch_assoc();
	$cont = $rows['cont'];
	if($cont > 0){//存在新消息
		$new_message = 1;
	}
}

echo json_encode(array("code"=>0,"msg"=>"成功获得用户数据",
						"name"=>$name,
						"mail"=>$mail,
						"head_image"=>$head_image,
						"new_message"=>$new_message));

require "sql/sql_connection_end.php";

?>
