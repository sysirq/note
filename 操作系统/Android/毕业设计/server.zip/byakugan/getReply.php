<?php


require "sql/sql_connection_begin.php";

function getHeadAddr($conn,$name){//头像地址获取
	$head_addr = "";
	$sql = "SELECT head_image FROM t_user_info WHERE name='$name'";
	$result = $conn->query($sql);
	if($result->num_rows>0){
		$row = $result->fetch_assoc();
		$head_addr = $row['head_image'];
	}

	return $head_addr;

}

//参数获取
$start = $_GET['start'];
$count = $_GET['count'];
$comment_id = $_GET['comment_id'];
//$start = 0;
//$count = 20;
//$id = "d347c0d0e666e29bfc1ac65e99ca0b5d";


//返回数据初始化
$code = 0;
$msg = "";
$replyCount = 0;
$replys = array();

//获得该文章的总回复数
$sql = "SELECT count(*) as cont FROM t_reply WHERE comment_id = '$comment_id'";
$result = $conn->query($sql);
if($result->num_rows>0){
	$row = $result->fetch_assoc();
	$replyCount = $row['cont'];
}

//回复获取
$sql = "SELECT from_u,to_u,time,content  FROM t_reply WHERE comment_id='$comment_id' order by time asc limit $start,$count";
$reply_result = $conn->query($sql);
while($rrow = $reply_result->fetch_assoc()){
	$reply = array();
	
	$from_user = $rrow['from_u'];
	$from_head = getHeadAddr($conn,$from_user);
	$to_user = $rrow["to_u"];
	$to_head = getHeadAddr($conn,$to_user);
	$content = $rrow['content'];
	$time = $rrow['time'];
			
	$reply['from_head'] = $from_head;
	$reply['from_user'] = $from_user;
	$reply['to_head'] = $to_head;
	$reply['to_user'] = $to_user;
	$reply['content'] = $content;
	$reply['time'] = $time;

	$replys[] = $reply;
}


echo json_encode(array("code"=>$code,"msg"=>$msg,"replyCount"=>$replyCount,"replys"=>$replys));

require "sql/sql_connection_end.php";
?>
