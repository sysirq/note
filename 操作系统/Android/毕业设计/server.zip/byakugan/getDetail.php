<?php
$sessionId = $_GET["sessionId"];
Session_id("$sessionId");
Session_start();
$id = $_GET["id"];



require "sql/sql_connection_begin.php";


//返回给客户端的数据初始化
$code = 0;
$msg = "";
$content = "";
$isCollection = 0;
$collectionCount = 0;
$isComment = 0;
$commentCount = 0;

//获得content
$sql = "SELECT content FROM t_article_detail WHERE id='$id'";
$result = $conn->query($sql);

if($result->num_rows>0){
	$row = $result->fetch_assoc();
	$content = $row["content"];
		
	$code = 0;
	$msg = "right";
}
else{
	$code = 2;
	$msg = "ID错误";
}


if($code != 0){
	goto end;
}

//收藏相关处理
//收藏数获得
$sql = "SELECT count(*) as cont FROM t_collection WHERE article_id='$id'";
$result = $conn->query($sql);
if($result->num_rows > 0){
	$row = $result->fetch_assoc();
	$collectionCount = $row["cont"];
}
//是否收藏判断
if( isset( $_SESSION['name']) ){
	$name = $_SESSION['name'];
	
	$sql = "SELECT article_id FROM t_collection WHERE article_id='$id' AND name = '$name'";
	$result = $conn->query($sql);
	
	if($result->num_rows > 0){
		$isCollection = 1;
	}

}

//评论相关处理
//评论数获得
$sql = "SELECT count(*) as cont FROM t_comment WHERE article_id='$id'";
$result = $conn->query($sql);
if($result->num_rows > 0){
	$row = $result->fetch_assoc();
	$commentCount = $row["cont"];
}
//是否评论判断
if( isset( $_SESSION['name']) ){
	$name = $_SESSION['name'];
	
	$sql = "SELECT article_id FROM t_comment WHERE article_id='$id' AND from_u = '$name'";
	$result = $conn->query($sql);
	
	if($result->num_rows > 0){
		$isComment = 1;
	}

}

end:

echo json_encode(array("code"=>$code,"msg"=>$msg,"content"=>$content,"isCollection"=>$isCollection,
						"collectionCount"=>$collectionCount,"isComment"=>$isComment,"commentCount"=>$commentCount));

require "sql/sql_connection_end.php";
?>
