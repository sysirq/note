<?php
require "sql/sql_connection_begin.php";
require "my_log.php";

$name = $_POST["name"];
$password = $_POST["paswd"];
$mail = $_POST["mail"];
$time = date("Y-m-d H:i:s");

if(!isset($name) || !isset($password) || !isset($mail)){
	echo json_encode(array("code"=>3,"msg"=>"您提交的数据有误"));
}

$sql = "INSERT INTO t_user_info(mail,name,password,last_get_message_time,sign_up_time) VALUES('$mail','$name','$password','$time','$time')";

if($conn->query($sql) === TRUE){
	echo json_encode(array("code"=>0,"msg"=>"注册成功"));
}
else{
	myLog("Error: ".$sql." ".$conn->error."\n");
	echo json_encode(array("code"=>2,"msg"=>"该账号已注册"));
}

require "sql/sql_connection_end.php";
?>
