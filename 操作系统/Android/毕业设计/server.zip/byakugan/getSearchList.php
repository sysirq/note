<?php
require "sql/sql_connection_begin.php";

//参数获取
$start=$_GET["start"];
$count=$_GET["count"];
$content =$_GET["content"];

$totalCount = 0;
$sql = "SELECT count(id) as cont FROM t_article_detail WHERE title LIKE '%$content%'";

$result = $conn->query($sql);
if($result->num_rows == 1 ){
	$row = $result->fetch_assoc();
	$totalCount = $row["cont"];
}

$arr = array();
$arr["totalCount"]=$totalCount;

$sql = "SELECT id,title,source,time,description FROM t_article_detail WHERE title LIKE '%$content%' order by time desc limit $start,$count";

$result = $conn->query($sql);
if($result->num_rows != 0 ){
	while($row = $result->fetch_assoc()){
		$item = array();
		$item["id"] = $row["id"];
		$item["title"] = $row["title"];
		$item["source"] = $row["source"];
		$item["time"] = $row["time"];
		$item["description"] = $row["description"];

		$arr["data"][] = $item;
	}
}

echo json_encode($arr);

require "sql/sql_connection_end.php";
?>
