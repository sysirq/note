<?php
require "session/session_check.php";
require "sql/sql_connection_begin.php";

$id = $_GET["id"];
$state = $_GET["state"];
$name = $_SESSION['name'];

//返回值初始化
$code = 0;
$msg = "";
$collectionCount = 0;
$isCollection = 0;

if($state == 1){//添加
	$time = date("Y-m-d H:i:s");
	$sql = "INSERT INTO t_collection(article_id,name,time) VALUES('$id','$name','$time')";
	if($conn->query($sql) === TRUE){
		$code = 0;
		$isCollection = 1;
	}
	else{
		$code = 3;
		$msg = "收藏失败";
	}
}
else if($state == 0){//删除
	$sql = "DELETE FROM t_collection WHERE article_id = '$id' AND name = '$name'";
	$result = $conn->query($sql);
	if($result === true){
		$code = 0;
		$isCollection = 0;
	}
	else{
		$code = 4;
		$msg = "取消收藏失败";
	}
}
else{
	$code = 2;
	$msg = "state错误";
}

if($code != 0){
	goto end;
}

//获取收藏数
$sql = "SELECT count(*) as cont FROM t_collection WHERE article_id = '$id'";
$result = $conn->query($sql);
if($result->num_rows>0){
	$row = $result->fetch_assoc();
	$collectionCount = $row['cont'];
}


end:

echo json_encode(array("code"=>$code,"msg"=>$msg,"collectionCount"=>$collectionCount,"isCollection"=>$isCollection));

require "sql/sql_connection_end.php";
?>
