<?php
require "session/session_check.php";
require "sql/sql_connection_begin.php";

//客户端传递的数据获取
$name = $_SESSION['name'];
$id   = $_REQUEST['id'];
$content   = $_REQUEST['content'];

//服务端返回数据初始化
$code = 0;
$msg = "";


$time = date("Y-m-d H:i:s");

$sql = "INSERT INTO t_comment (from_u,article_id,time,content) VALUES ('$name','$id','$time','$content')";
if($conn->query($sql) === TRUE){
	$code = 0;
	$msg = $time;
}
else{
	$code = 3;
	$msg = "添加评论失败 name:".$name." id:".$id." time:".$time." content:".$content;
}

echo json_encode(array("code"=>$code,"msg"=>$msg));

require "sql/sql_connection_end.php";
?>
