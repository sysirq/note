<?php
require "session/session_check.php";
require "sql/sql_connection_begin.php";

//参数获取
$name = $_SESSION['name'];
//$name = 'lizhixi';
$index = $_GET['index'];

$dir = "./head/";

$handler = opendir($dir);

//返回数据初始化
$code = 0;
$msg = "";

while( ($filename = readdir($handler)) !== false){
	if($filename != "." && $filename != ".."){	
		$files[] = $filename;
	}
}

$totalCount = count($files);

if($index < 0 || $index >= $totalCount){
	$code = 2;
	$msg = "参数错误";
	goto end;
}


$filename = $files[$index];

$sql = "UPDATE t_user_info set head_image='$filename' WHERE name = '$name'";
if($conn->query($sql) != TRUE){
	$code = 2;
	$msg = "数据库错误";
	goto end;
}

end:
echo json_encode(array("code"=>$code,"msg"=>$msg));

require "sql/sql_connection_end.php";
?>
