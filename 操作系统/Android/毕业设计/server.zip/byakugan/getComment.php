<?php


require "sql/sql_connection_begin.php";

function getHeadAddr($conn,$name){//头像地址获取
	$head_addr = "";
	$sql = "SELECT head_image FROM t_user_info WHERE name='$name'";
	$result = $conn->query($sql);
	if($result->num_rows>0){
		$row = $result->fetch_assoc();
		$head_addr = $row['head_image'];
	}

	return $head_addr;

}

//参数获取
$start = $_GET['start'];
$count = $_GET['count'];
$id = $_GET['id'];
//$start = 0;
//$count = 20;
//$id = "d347c0d0e666e29bfc1ac65e99ca0b5d";


//返回数据初始化
$code = 0;
$msg = "";
$totalCount = 0;
$comments = array();

//获得该文章的总评论数
$sql = "SELECT count(*) as cont FROM t_comment WHERE article_id = '$id'";
$result = $conn->query($sql);
if($result->num_rows>0){
	$row = $result->fetch_assoc();
	$totalCount = $row['cont'];
}

//评论获取
$sql = "SELECT id,article_id,from_u,time,content FROM t_comment WHERE article_id = '$id' order by time desc limit $start,$count";
$comments_result = $conn->query($sql);
if($comments_result->num_rows>0){
	while($crow = $comments_result->fetch_assoc()){
		$comment = array();
		$head_addr = "";
		$name = $crow['from_u'];	
		$content = $crow['content'];
		$time = $crow['time'];
		$comment_id = $crow['id'];
		//头像地址获取
		$head_addr = getHeadAddr($conn,$name);

		$comment['head_addr'] = $head_addr;
		$comment['name'] = $name;
		$comment['content'] = $content;
		$comment['time'] = $time;
		$comment['comment_id'] = $comment_id;
		$comment['replyCount'] = 0;
		/*
		//回复获取
		$sql = "SELECT from_u,to_u,time,content  FROM t_reply WHERE comment_id='$comment_id' order by time asc";
		$reply_result = $conn->query($sql);
		while($rrow = $reply_result->fetch_assoc()){
			$reply = array();
			
			$from_user = $rrow['from_u'];
			$from_head = getHeadAddr($conn,$from_user);
			$to_user = $rrow["to_u"];
			$to_head = getHeadAddr($conn,$to_user);
			$content = $rrow['content'];
			$time = $rrow['time'];
			
			$reply['from_head'] = $from_head;
			$reply['from_user'] = $from_user;
			$reply['to_head'] = $to_head;
			$reply['to_user'] = $to_user;
			$reply['content'] = $content;
			$reply['time'] = $time;

			$comment["replys"][] = $reply;
		}
		 */
		//回复数获取
		$sql = "SELECT count(*) as cont  FROM t_reply WHERE comment_id='$comment_id' order by time asc";
		$reply_result = $conn->query($sql);
		if($reply_result->num_rows > 0){
			$row = $reply_result->fetch_assoc();
			$comment['replyCount'] = $row['cont'];
			
		}

		$comments[] = $comment;
	}
}


echo json_encode(array("code"=>$code,"msg"=>$msg,"totalCount"=>$totalCount,"comments"=>$comments));

require "sql/sql_connection_end.php";
?>
