<?php
require "sql/sql_connection_begin.php";

//参数获取
$start = $_GET['start'];
$count = $_GET['count'];

$dir = "./head/";

$handler = opendir($dir);

//返回数据初始化
$code = 0;
$totalCount = 0;
$msg = "";
$addrs = array();

while( ($filename = readdir($handler)) !== false){
	if($filename != "." && $filename != ".."){	
		$files[] = $filename;
	}
}

$totalCount = count($files);

while($start < $totalCount && $count != 0){
	$addrs[] = $files[$start];
	$start++;
	$count -=1;
}


echo json_encode(array("code"=>$code,"msg"=>$msg,"totalCount"=>$totalCount,"addrs"=>$addrs));

require "sql/sql_connection_end.php";
?>
