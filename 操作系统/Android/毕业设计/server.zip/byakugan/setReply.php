<?php
require "sql/sql_connection_begin.php";
require "session/session_check.php";

//参数获取
$from_u = $_SESSION['name'];
$to_u = $_GET['to_u'];
$comment_id = $_GET['comment_id'];
$time = date("Y-m-d H:i:s");
$content = $_GET["content"];

//返回数据初始化
$code = 0;
$msg = "";

$sql = "INSERT INTO t_reply (comment_id,from_u,to_u,time,content) VALUES('$comment_id','$from_u','$to_u','$time','$content')";
if($conn->query($sql) != TRUE){
	$code = 2;
	$msg = "回复失败";
}

echo json_encode(array("code"=>$code,"msg"=>$msg));

require "sql/sql_connection_end.php";
?>
