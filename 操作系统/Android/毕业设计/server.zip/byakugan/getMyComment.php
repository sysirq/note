<?php
require "session/session_check.php";
require "sql/sql_connection_begin.php";

//参数获取
$name = $_SESSION['name'];
$start = $_GET['start'];
$count = $_GET['count'];

//返回数据初始化
$code = 0;
$msg = "";
$totalCount = 0;
$comments = array();

//totalCount获取
$sql = "SELECT count(*) as cont FROM t_comment WHERE from_u='$name'";
$result = $conn->query($sql);
if($result->num_rows > 0){
	$row = $result->fetch_assoc();
	$totalCount = $row['cont'];
}

//评论数据获取
$sql = "SELECT t_comment.id as comment_id,article_id,title,t_comment.time as time,t_comment.content as content FROM t_comment,t_article_detail WHERE from_u ='$name' AND t_comment.article_id = t_article_detail.id order by t_comment.time desc limit $start,$count";

$result = $conn->query($sql);
if($result->num_rows > 0){
	while($row = $result->fetch_assoc()){
		$comment['comment_id'] = $row['comment_id'];
		$comment['from_u'] = $name;
		$comment['article_id'] = $row['article_id'];
		$comment['time'] = $row['time'];
		$comment['title'] = $row['title'];
		$comment['content'] = $row['content'];
		$comments[] = $comment;
	}
}

echo json_encode(array("code"=>$code,'msg'=>$msg,"totalCount"=>$totalCount,"comments"=>$comments));

require "sql/sql_connection_end.php";
?>
