<?php
$servername = "localhost";
$username="lizhixi";
$password="root123123";
$dbname="byakugan";

$conn = new mysqli($servername,$username,$password,$dbname);
if($conn->connect_error){
	echo json_encode(array("code"=>1,"msg"=>"服务器内部错误"));
	error_log("服务器内部错误\n",3,"../log/cat_dog.log");
	exit();
}
?>
