<?php

function getContent($type,$id){
	$url="https://cert.360.cn/".$type."/detail?id=".$id;
	$text = file_get_contents($url);
	preg_match("/<div class=\"news-conent\".*?>.*?<\/div>/ism",$text,$match);
	$content = $match[0];

	preg_match("/<div class=\"detail-title-head\".*?>.*?<\/div>/ism",$text,$match);
	$title = $match[0];

	return array("title"=>$title,"content"=>$content);
}
?>
