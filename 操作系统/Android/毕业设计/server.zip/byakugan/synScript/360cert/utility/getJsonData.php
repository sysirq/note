<?php
function getJsonData($type,$length,$start){
	$url = "https://cert.360.cn/".$type."/searchbypage?length=".$length."&start=".$start;
	$html = file_get_contents($url);

	$array = json_decode($html);
	return $array;
}
?>
