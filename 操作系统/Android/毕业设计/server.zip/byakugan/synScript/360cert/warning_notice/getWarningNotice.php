<?php

require "../utility/getContent.php";
require "../utility/getJsonData.php";
require "../../../sql/sql_connection_begin.php";

//打印当前时间
echo "[".date("Y-m-d H:i:s")."]\n";

$length=6;
$type = "WarningNotice";

//获得总Total
$array = getJsonData("warning",$length,0);
$recordsTotal = $array->recordsTotal;

echo "recordsTotal = ".$recordsTotal."\n";

//获取当前数据库中的360cert预警报告最新时间
$sql = "select time from t_article_detail where source = '360cert' AND type = '$type' order by time desc limit 1";
$result = $conn->query($sql);

if($result->num_rows == 1){
	$row = $result->fetch_assoc();
	$last_update_time = $row['time'];
}
else{
	$last_update_time = "2013-04-21 00:00";	//该网页上的数据的创建时间最少不会到该数
}

echo "last_update_time: ".$last_update_time."\n";


//添加数据

$isNeedUpdate = 1;
//
for($i = 0;$i<$recordsTotal;$i+=6){
	$data = getJsonData("warning",$length,$i)->data;
   
	$data_len =	count($data,0);

	for($j = 0;$j < $data_len;$j++){
		$title = mysqli_real_escape_string($conn,html_entity_decode($data[$j]->title));
		$time = $data[$j]->add_time_str;
		$description = mysqli_real_escape_string($conn,html_entity_decode($data[$j]->description));
		$id = md5($title. $time . "360cert".$type);
		$source = mysqli_real_escape_string($conn,"360cert");
		$content = mysqli_real_escape_string($conn,getContent("warning",$data[$j]->id)["content"]);
		

		if(strtotime($last_update_time) == strtotime($time)){
			echo "Now don't need update \n";
			$isNeedUpdate = 0;
			break;
		}
		
		echo "title: ".$title." time: ".$time."\n";

		$sql = "INSERT INTO t_article_detail(title,time,description,id,source,content,type) VALUES('$title','$time','$description','$id','$source','$content','$type')";
		if($conn->query($sql) === TRUE){
			echo "insert right \n";
		}
		else{
			echo "insert error: ".$conn->error." \n";
		}

	}

	if($isNeedUpdate == 0){
		break;
	}
}

require "../../../sql/sql_connection_end.php";
?>
