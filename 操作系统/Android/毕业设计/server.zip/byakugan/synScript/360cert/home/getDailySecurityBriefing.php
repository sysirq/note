<?php
require "../../../sql/sql_connection_begin.php";

function getContent($time){
	$url = "https://cert.360.cn/daily?date=$time";
	$text = file_get_contents($url);

	return $text;
}

$type = "daily";

//最晚时间获取
$sql = "SELECT time FROM t_article_detail WHERE source='360cert' AND type='$type' order by time desc limit 1";
$result = $conn->query($sql);
if($result->num_rows > 0){
	$row = $result->fetch_assoc();
	$last_update_time = $row['time'];
}
else{
	$last_update_time = "2018-03-29";
}

echo "last_update_time: ".$last_update_time."\n";

$time = date("Y-m-d");

if(strcmp($time,$last_update_time) == 0){
	echo "Now don't need update\n";
	goto end;
}


while(strcmp($time,$last_update_time) != 0){
	//插入数据库中的数据
	$title = mysqli_real_escape_string($conn,"360-CERT每日安全简报($time)");
	$id = md5($title.$time."360cert".$type);
	$description = mysqli_real_escape_string($conn,"");
	$source = mysqli_real_escape_string($conn,"360cert");
	
	$content = getContent($time);
	preg_match_all("/<div class=\"report-block\".*?>.*?<\/div>[\s]*<\/div>[\s]*<\/div>[\s]*<\/div>/ism",$content,$match);
	if(count($match[0]) == 0){
		$time = date("Y-m-d",strtotime($time) - 3600*24);
		continue;
	}
	$content = "";
	foreach( $match[0] as $key => $value){
		$content = $content."<hr />".$value;
	}
	
	$content = mysqli_real_escape_string($conn,$content);
	
	echo $title."\n";
	
	$sql = "INSERT INTO t_article_detail(title,time,description,id,source,content,type) VALUES('$title','$time','$description','$id','$source','$content','$type')";
	if($conn->query($sql) === TRUE){
		echo "insert right\n";
	}
	else{
		echo "insert error: ".$conn->error." \n";
	}


	$time = date("Y-m-d",strtotime($time) - 3600*24);
}


end:

require "../../../sql/sql_connection_end.php";
?>
