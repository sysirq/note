<?php
Session_start();
require "sql/sql_connection_begin.php";
require "my_log.php";
$session_id = session_id();

$name = $_POST["name"];
$password = $_POST["password"];

if(!isset($name) || !isset($password) ){
	echo json_encode(array("code"=>3,"msg"=>"您提交的数据有误"));
}

$sql = "SELECT name,mail,head_image FROM t_user_info WHERE name='$name' AND password='$password'";
$result = $conn->query($sql);

if($result->num_rows > 0){

	while($row = $result->fetch_assoc()){
		$_SESSION['name'] = $row['name'];
		$_SESSION['mail'] = $row['mail'];
		$_SESSION['head_image'] = $row['head_image'];
	}

	echo json_encode(array("code"=>0,"msg"=>"登陆成功","session_id"=>$session_id));
}
else{
	myLog("Error: ".$sql." ".$conn->error."\n");
	echo json_encode(array("code"=>2,"msg"=>"账号不存在或密码错误"));
}

require "sql/sql_connection_end.php";
?>
