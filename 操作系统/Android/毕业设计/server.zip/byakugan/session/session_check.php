<?php
//登陆验证
$sessionId = $_REQUEST["sessionId"];
Session_id("$sessionId");
Session_start();

if(!isset($_SESSION['name'])){
		echo json_encode(array("code"=>1,"msg"=>"请先登陆"));
		exit();
}

?>
