/* 
 * Copyright holder: Invisible Things Lab
 * 
 * This software is protected by domestic and International
 * copyright laws. Any use (including publishing and
 * distribution) of this software requires a valid license
 * from the copyright holder.
 *
 * This software is provided for the educational use only
 * during the Black Hat training. This software should not
 * be used on production systems.
 *
 */

#include "newbp.h"

extern BOOLEAN g_bDisableComOutput;

NTSTATUS DriverUnload (
  PDRIVER_OBJECT DriverObject
)
{
  //FIXME: do not turn SVM/VMX when it has been turned on by the guest in the meantime (e.g. VPC, VMWare)
  NTSTATUS Status;

  _KdPrint (("\r\n"));
  _KdPrint (("NEWBLUEPILL: Unloading started\n"));
  g_bDisableComOutput = TRUE;

  if (!NT_SUCCESS (Status = HvmSpitOutBluepill ())) {
    _KdPrint (("NEWBLUEPILL: HvmSpitOutBluepill() failed with status 0x%08hX\n", Status));
  }

  g_bDisableComOutput = FALSE;
  _KdPrint (("NEWBLUEPILL: Unloading finished\n"));

#ifdef USE_LOCAL_DBGPRINTS
  DbgUnregisterWindow ();
#endif

  return STATUS_SUCCESS;
}

NTSTATUS DriverEntry (
  PDRIVER_OBJECT DriverObject,
  PUNICODE_STRING RegistryPath
)
{
  NTSTATUS Status;

#ifdef USE_COM_PRINTS
  PioInit ((PUCHAR) COM_PORT_ADDRESS);
#endif
  ComInit ();

  //
  // 是否使用调试输出
  //
#ifdef USE_LOCAL_DBGPRINTS
  Status = DbgRegisterWindow (g_BpId);
  if (!NT_SUCCESS (Status)) {
    _KdPrint (("NEWBLUEPILL: DbgRegisterWindow() failed with status 0x%08hX\n", Status));
    return Status;
  }
#endif

  _KdPrint (("\r\n"));
  _KdPrint (("NEWBLUEPILL v%d.%d.%d.%d. Instance Id: 0x%02X\n",
             (NBP_VERSION >> 48) & 0xff,
             (NBP_VERSION >> 32) & 0xff, (NBP_VERSION >> 16) & 0xff, NBP_VERSION & 0xff, g_BpId));

  //
  // 初始化Hvm, 失败则撤销更改
  //
  if (!NT_SUCCESS (Status = HvmInit ())) {
    _KdPrint (("NEWBLUEPILL: HvmInit() failed with status 0x%08hX\n", Status));
#ifdef USE_LOCAL_DBGPRINTS
    DbgUnregisterWindow ();
#endif
    return Status;
  }

  //
  // 吞下BluePill，开启VMM模式, 失败则撤销更改
  //
  if (!NT_SUCCESS (Status = HvmSwallowBluepill ())) {
    _KdPrint (("NEWBLUEPILL: HvmSwallowBluepill() failed with status 0x%08hX\n", Status));
#ifdef USE_LOCAL_DBGPRINTS
    DbgUnregisterWindow ();
#endif
    return Status;
  }

  //
  // 卸载函数
  //
  DriverObject->DriverUnload = DriverUnload;

  //
  // 打印加载信息
  //
  _KdPrint (("NEWBLUEPILL: Initialization finished\n"));
#if DEBUG_LEVEL>1
  _KdPrint (("NEWBLUEPILL: RFLAGS = %#x, CR8 = %#x\n", RegGetRflags (), RegGetCr8 ()));
#endif

  return STATUS_SUCCESS;
}
