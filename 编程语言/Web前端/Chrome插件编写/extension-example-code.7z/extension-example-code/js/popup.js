let onBtn = document.querySelector("#on-btn")
let offBtn = document.querySelector("#off-btn")

async function onBtnClick(){
    const [tab] = await chrome.tabs.query({active: true, lastFocusedWindow: true});
    await chrome.tabs.sendMessage(tab.id, {msg: "openUI"});
}

async function offBtnClick(){
    const [tab] = await chrome.tabs.query({active: true, lastFocusedWindow: true});
    await chrome.tabs.sendMessage(tab.id, {msg: "closeUI"});
}

onBtn.addEventListener('click',onBtnClick)
offBtn.addEventListener('click',offBtnClick)