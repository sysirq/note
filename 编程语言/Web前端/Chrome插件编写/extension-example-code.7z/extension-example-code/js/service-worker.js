chrome.runtime.onInstalled.addListener(({ reason }) => {
    if (reason === 'install' || reason === 'update') {
        chrome.storage.local.set({
            switchBtn: 0
        });
        chrome.alarms.clearAll()
    }
});

chrome.runtime.onMessage.addListener(
    async function (request, sender, sendResponse) {
        if (request.msg === "start"){

            chrome.alarms.clearAll()

            let value = request.value
            chrome.storage.local.set({count:value})

            const ALARM_NAME = "myAlarm"

            const alarm = await chrome.alarms.get(ALARM_NAME);
            if (typeof alarm === 'undefined') {
              chrome.alarms.create(ALARM_NAME, {
                periodInMinutes:0.01
              });
            }
            
        }
        if((request.msg === "cancel")){
            chrome.alarms.clearAll()
        }
    }
);

const updateTip = async () => {
    let {count} = await chrome.storage.local.get('count')
    console.log(count)
    chrome.storage.local.set({count:--count})

    
    const [tab] = await chrome.tabs.query({active: true, lastFocusedWindow: true});
    await chrome.tabs.sendMessage(tab.id, {msg: "updateResult",result:count});

};

chrome.alarms.onAlarm.addListener(updateTip);