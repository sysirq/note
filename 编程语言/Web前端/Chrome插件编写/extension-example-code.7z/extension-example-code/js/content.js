chrome.runtime.onMessage.addListener(
    function (request, sender, sendResponse) {
        if (request.msg === "openUI") {
            openUI()
        } else if (request.msg === "closeUI") {
            closeUI()
        }else if (request.msg === "updateResult"){
            let stateSpan = document.querySelector("#mainDivStateSpan")
            if(!stateSpan) return
            stateSpan.textContent = request.result

        }
    }
);

function createUI() {
    const mainDiv = document.createElement("div")
    mainDiv.setAttribute('id', 'mainDiv')
    mainDiv.style.padding = '20px'
    mainDiv.style.width = '400px'
    mainDiv.style.marginLeft = '-200px'
    mainDiv.style.height = '200px'
    mainDiv.style.marginTop = '-100px'
    mainDiv.style.background = 'white'
    mainDiv.style.border="solid 4px"
    mainDiv.style.borderRadius= "30px"
    mainDiv.style.position = 'fixed'
    mainDiv.style.top = '50%'
    mainDiv.style.left = '50%'

    //信息框提示
    const headH4 = document.createElement("h4")
    headH4.textContent = "插件框"
    mainDiv.appendChild(headH4)
    headH4.style.textAlign="center"

    //用户输入数据区域
    
    const inputFlexDiv = document.createElement("div")
    inputFlexDiv.style.display = 'flex'
    mainDiv.appendChild(inputFlexDiv)
    inputFlexDiv.style.height="100px"
    inputFlexDiv.style.alignItems="center"
    inputFlexDiv.style.justifyContent="space-around"
    
    //输入数据区1
    const span1Node = document.createElement("span")
    span1Node.textContent="目标值："
    inputFlexDiv.appendChild(span1Node)

    const inputNode = document.createElement('input')
    inputNode.setAttribute('type',"text")
    inputFlexDiv.appendChild(inputNode)

    //按钮flex div区
    const BtnFlexDiv = document.createElement("div")
    BtnFlexDiv.style.display = 'flex'
    BtnFlexDiv.style.alignItems="center"
    BtnFlexDiv.style.justifyContent="space-around"
    mainDiv.appendChild(BtnFlexDiv)
    //开始按钮
    const confirmBtn = document.createElement("button")
    confirmBtn.setAttribute('id',"mainDivConfirmBtn")
    confirmBtn.textContent = "确认"
    confirmBtn.style.textAlign="center"
    BtnFlexDiv.appendChild(confirmBtn)

    confirmBtn.addEventListener("click",async function(){
        let value = inputNode.value
        const response = await chrome.runtime.sendMessage({msg: "start",value});
    })

    const cancelBtn = document.createElement("button")
    cancelBtn.setAttribute('id',"mainDivcancelBtn")
    cancelBtn.textContent = "取消"
    cancelBtn.style.textAlign="center"
    BtnFlexDiv.appendChild(cancelBtn)
    cancelBtn.addEventListener("click",async function(){
        const response = await chrome.runtime.sendMessage({msg: "cancel"});
    })



    //结果 flex div区
    const resultFlexDiv = document.createElement("div")
    resultFlexDiv.style.display = 'flex'
    resultFlexDiv.style.alignItems="center"
    resultFlexDiv.style.justifyContent="space-around"
    mainDiv.appendChild(resultFlexDiv)

    //显示结果
    const stateSpan = document.createElement("span")
    stateSpan.setAttribute('id',"mainDivStateSpan")
    stateSpan.style.color="red"
    resultFlexDiv.appendChild(stateSpan)
    

    return mainDiv
}

async function openUI() {
    let uiNode = document.querySelector("#mainDiv")
    if (uiNode) return
    uiNode = createUI()
    document.body.appendChild(uiNode)
}

function closeUI() {
    let uiNode = document.querySelector("#mainDiv")
    if (uiNode) {
        uiNode.parentNode.removeChild(uiNode)
    }
}