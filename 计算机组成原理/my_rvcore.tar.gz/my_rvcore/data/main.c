int main(void)
{
	int i = 0;
	int sum = 0;
	for(i;i<10;i++){
		sum = sum + i;
	}
	return 0;
}
