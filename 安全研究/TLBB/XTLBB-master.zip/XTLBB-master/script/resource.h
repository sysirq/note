//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by script.rc
//
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDC_STATIC0                     1000
#define IDC_STATIC1                     1001
#define IDC_STATIC7                     1005
#define IDC_STATIC6                     1006
#define IDC_STATIC2                     1007
#define IDC_STATIC3                     1008
#define IDC_STATIC4                     1009
#define IDC_STATIC5                     1010
#define IDC_CHECK1                      1011
#define IDC_EDIT1                       1012
#define IDC_CHECK2                      1014
#define IDC_CHECK3                      1015
#define IDC_CHECK4                      1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        204
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
