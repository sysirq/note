#ifndef LOG_H
#define LOG_H

void MyLog(const char *format, ...);

#endif