#ifndef INJECT_HELPER_H
#define INJECT_HELPER_H

// use ANSI name only
void StartInject(HWND hWnd, LPCSTR lpszDllName);
void StopInject(HWND hWnd, LPCSTR lpszDllName);

#endif // INJECT_HELPER_H