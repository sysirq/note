#ifndef FILE_UTILITY_H
#define FILE_UTILITY_H

#include <windows.h>

char * GetInjectDllName();
char * GetLuaFileName(HMODULE hModule);

#endif