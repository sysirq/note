#ifndef LUA_CLIENT_H
#define LUA_CLIENT_H

namespace LuaClient
{
	BYTE GetSelectCode();
	BYTE GetSkillCode();
}

#endif