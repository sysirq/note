#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/sched.h>
#include <linux/string.h>
#include <linux/slab.h>

static char *ptr;

static int m_init(void){
	ptr = (char*)kzalloc(256,GFP_KERNEL);
	
	strcpy(ptr,"cert.360.cn");

	if(ptr == NULL){
		printk("kmalloc error\n");
		return -1;
	}
	else{
		printk("ptr: 0x%p , values: %s\n",ptr,ptr);
	}
	
	return 0;
}

static void m_exit(void){
	kfree(ptr);
}

module_init(m_init);
module_exit(m_exit);
MODULE_LICENSE("GPL");

