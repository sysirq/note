# kenrel 文件
	createKernelValue内核模块： 在内核中创建数据，然后可以通过dmesg 获取其地址。

	kernelValue2cache内核模块： 用于让用户将内核数据加载进缓存。

# user 文件
	利用：在cache中的数据，访问时间最短的原理。获得内核数据