#![feature(c_variadic)]

use std::{collections::HashMap, mem, os::raw::c_void};

use beacon_api::{beacon_func_idx_to_func_addr, beacon_func_idx_to_func_name};

#[cfg(target_os = "windows")]
use bof_common::{
    common_bof_data_parser, BSS_SECTION_NUMBER, DATA_SECTION_NUMBER, DYN_FUNCTION,
    END_SECTION_NUMBER, IMAGE_REL_AMD64_ADDR64, IMAGE_REL_AMD64_REL32, IMAGE_REL_I386_DIR32,
    IMAGE_REL_I386_REL32, RDATA_SECTION_NUMBER, TEXT_SECTION_NUMBER,OS_TYPE_WINDOWS,ARCH_X86_64,ARCH_X86_32
};

#[cfg(target_os = "windows")]
use std::ffi::CString;
#[cfg(target_os = "windows")]
use windows::{
    core::PCSTR,
    Win32::System::{
        LibraryLoader::{GetModuleHandleA, GetProcAddress, LoadLibraryA},
        Memory::{VirtualAlloc, VirtualFree, MEM_COMMIT, MEM_RELEASE, PAGE_EXECUTE_READWRITE},
    },
};


#[cfg(target_os = "linux")]
use std::ffi::CString;
#[cfg(target_os = "linux")]
use bof_common::{
    common_bof_data_parser, BSS_SECTION_NUMBER, DATA_SECTION_NUMBER, DYN_FUNCTION,
    END_SECTION_NUMBER, RDATA_SECTION_NUMBER, R_X86_64_64, R_X86_64_PC32, R_X86_64_PLT32,
    TEXT_SECTION_NUMBER,OS_TYPE_LINUX,ARCH_X86_64,ARCH_X86_32
};
#[cfg(target_os = "linux")]
use std::ptr;

#[cfg(target_os = "linux")]
use libc::{mmap, munmap, MAP_ANONYMOUS, MAP_PRIVATE, PROT_EXEC, PROT_READ, PROT_WRITE,RTLD_LAZY,RTLD_GLOBAL,dlopen, dlsym};

pub mod beacon_api;

#[allow(unused_variables)]
#[allow(unused_assignments)]
pub fn bof_lodaer(bof_data: &[u8]) -> Result<(), String> {
    let bof_parsed_data = common_bof_data_parser(bof_data)?;
    let mut function_map_addr: HashMap<String, usize> = HashMap::new();

    #[cfg(target_os = "windows")]
    {
        if bof_parsed_data.os_type != OS_TYPE_WINDOWS {
            return Err(format!("bof data os type error"));
        }

        let arch_bits = mem::size_of::<usize>();
        if arch_bits == 32 && bof_parsed_data.arch_type != ARCH_X86_32 {
            return Err(format!("bof data arch type error"));
        }

        if arch_bits == 64 && bof_parsed_data.arch_type != ARCH_X86_64 {
            return Err(format!("bof data arch type error"));
        }
    }
    #[cfg(target_os = "linux")]
    {
        if bof_parsed_data.os_type != OS_TYPE_LINUX {
            return Err(format!("bof data os type error"));
        }

        let arch_bits = mem::size_of::<usize>();
        if arch_bits == 32 && bof_parsed_data.arch_type != ARCH_X86_32 {
            return Err(format!("bof data arch type error"));
        }

        if arch_bits == 64 && bof_parsed_data.arch_type != ARCH_X86_64 {
            return Err(format!("bof data arch type error"));
        }
    }

    //get relocation symbol addr
    for rel in &bof_parsed_data.relocations {
        if rel.target_section_number < TEXT_SECTION_NUMBER {
            let func_name = beacon_func_idx_to_func_name(rel.target_section_number as usize);
            if function_map_addr.contains_key(&func_name) == false {
                let func_addr = beacon_func_idx_to_func_addr(rel.target_section_number as usize);
                function_map_addr.insert(func_name, func_addr as usize);
            }
        } else if rel.target_section_number == DYN_FUNCTION {
            #[cfg(target_os = "windows")]
            let func_name = format!("{}${}", rel.module_name, rel.function_name);
            #[cfg(target_os = "linux")]
            let func_name = format!("{}",rel.function_name);
            
            if function_map_addr.contains_key(&func_name) == false {
                //dyn function addr get for windows
                #[cfg(target_os = "windows")]
                {
                    let module_name = &rel.module_name;
                    let module_name = match CString::new(module_name.as_bytes()) {
                        Ok(c_str) => c_str,
                        Err(_) => {
                            return Err(format!("CString module name({}) error", rel.module_name))
                        } //null
                    };
                    let module_name: PCSTR = PCSTR(module_name.as_ptr() as *const u8);
                    let h_module;
                    if let Ok(_h_module) = unsafe { GetModuleHandleA(module_name) } {
                        h_module = _h_module;
                    } else {
                        if let Ok(_h_module) = unsafe { LoadLibraryA(module_name) } {
                            h_module = _h_module;
                        } else {
                            return Err(format!("LoadLibraryA module ({}) error", rel.module_name));
                        }
                    }

                    let func_name = &rel.function_name;
                    let func_name = match CString::new(func_name.as_bytes()) {
                        Ok(c_str) => c_str,
                        Err(_) => {
                            return Err(format!(
                                "CString function name({}) error",
                                rel.function_name
                            ))
                        } //null
                    };
                    let func_name: PCSTR = PCSTR(func_name.as_ptr() as *const u8);
                    let func_addr = unsafe { GetProcAddress(h_module, func_name) };
                    let func_addr = match func_addr {
                        Some(_func_addr) => _func_addr,
                        None => {
                            return Err(format!("GetProcAddress error({})", rel.function_name));
                        }
                    };

                    let func_name = format!("{}${}", rel.module_name, rel.function_name);
                    function_map_addr.insert(func_name, func_addr as usize);
                } 
                //dyn function addr get for linux ,  only support linked glibc func , that is enough for hacking
                #[cfg(target_os = "linux")]{
                    let lib_handle = unsafe {
                        dlopen(std::ptr::null() , RTLD_LAZY | RTLD_GLOBAL)
                    };
                    if lib_handle.is_null() {
                        return Err(String::from("dlopen error"));
                    }
                    let func_name = &rel.function_name;
                    let func_name = match CString::new(func_name.as_bytes()) {
                        Ok(c_str) => c_str,
                        Err(_) => {
                            return Err(format!(
                                "CString function name({}) error",
                                rel.function_name
                            ))
                        } //null
                    };
                    let func_ptr = unsafe {
                        dlsym(lib_handle, func_name.as_ptr())
                    };
                    if func_ptr.is_null() {
                        return Err(format!("dlsym func: {} error",rel.function_name));
                    }
                    let func_name = format!("{}", rel.function_name);
                    function_map_addr.insert(func_name, func_ptr as usize);
                    
                }
            }
        } else if rel.target_section_number >= END_SECTION_NUMBER {
            return Err(String::from("Unknow Relocation section number"));
        }
    }

    //align
    let mut text_mem_size = bof_parsed_data.text_section_data.len();
    if text_mem_size & (std::mem::size_of::<usize>() - 1) != 0 {
        text_mem_size =
            (text_mem_size + std::mem::size_of::<usize>()) & (!(std::mem::size_of::<usize>() - 1));
    }
    let mut data_mem_size = bof_parsed_data.data_section_data.len();
    if data_mem_size & (std::mem::size_of::<usize>() - 1) != 0 {
        data_mem_size =
            (data_mem_size + std::mem::size_of::<usize>()) & (!(std::mem::size_of::<usize>() - 1));
    }
    let mut rdata_mem_size = bof_parsed_data.rdata_section_data.len();
    if rdata_mem_size & (std::mem::size_of::<usize>() - 1) != 0 {
        rdata_mem_size =
            (rdata_mem_size + std::mem::size_of::<usize>()) & (!(std::mem::size_of::<usize>() - 1));
    }
    let mut bss_mem_size = bof_parsed_data.bss_section_data_size as usize;
    if bss_mem_size & (std::mem::size_of::<usize>() - 1) != 0 {
        bss_mem_size =
            (bss_mem_size + std::mem::size_of::<usize>()) & (!(std::mem::size_of::<usize>() - 1));
    }

    #[cfg(target_os = "windows")]
    let stub_mem_size = function_map_addr.len() * std::mem::size_of::<usize>();
    #[cfg(target_os = "linux")]
    let stub_mem_size = function_map_addr.len() * 12; //12 for "\x48\xb8\xEE\xEE\xEE\xEE\xEE\xEE\xEE\xEE\xff\xe0"

    let total_mem_size =
        stub_mem_size + text_mem_size + data_mem_size + rdata_mem_size + bss_mem_size;

    //mem offset calc
    let mut stub_start_offset = 0;
    let mut stub_end_offset = 0;
    let mut text_start_offset = 0;
    let mut text_end_offset = 0;
    let mut data_start_offset = 0;
    let mut data_end_offset = 0;
    let mut rdata_start_offset = 0;
    let mut rdata_end_offset = 0;
    let mut bss_start_offset = 0;
    let mut bss_end_offset = 0;

    if stub_mem_size == 0 {
        stub_start_offset = 0;
        stub_end_offset = 0;
    } else {
        stub_start_offset = 0;
        stub_end_offset = stub_mem_size - 1;
    }

    if text_mem_size == 0 {
        text_start_offset = stub_end_offset;
        text_end_offset = stub_end_offset;
    } else {
        text_start_offset = stub_mem_size;
        text_end_offset = text_start_offset + text_mem_size - 1;
    }

    if data_mem_size == 0 {
        data_start_offset = text_end_offset;
        data_end_offset = text_end_offset;
    } else {
        data_start_offset = stub_mem_size + text_mem_size;
        data_end_offset = data_start_offset + data_mem_size - 1;
    }

    if rdata_mem_size == 0 {
        rdata_start_offset = data_end_offset;
        rdata_end_offset = data_end_offset;
    } else {
        rdata_start_offset = stub_mem_size + text_mem_size + data_mem_size;
        rdata_end_offset = rdata_start_offset + rdata_mem_size - 1;
    }

    if bss_mem_size == 0 {
        bss_start_offset = rdata_end_offset;
        bss_end_offset = rdata_end_offset;
    } else {
        bss_start_offset = stub_mem_size + text_mem_size + data_mem_size + rdata_mem_size;
        bss_end_offset = bss_start_offset + bss_mem_size - 1;
    }

    #[cfg(test)]
    {
        println!("text_mem_size:{}", text_mem_size);
        println!("data_mem_size:{}", data_mem_size);
        println!("rdata_mem_size:{}", rdata_mem_size);
        println!("bss_mem_size:{}", bss_mem_size);

        println!("stub_start_offset:{}", stub_start_offset);
        println!("stub_end_offset:{}", stub_end_offset);

        println!("text_start_offset:{}", text_start_offset);
        println!("text_end_offset:{}", text_end_offset);

        println!("data_start_offset:{}", data_start_offset);
        println!("data_end_offset:{}", data_end_offset);

        println!("rdata_start_offset:{}", rdata_start_offset);
        println!("rdata_end_offset:{}", rdata_end_offset);

        println!("bss_start_offset:{}", bss_start_offset);
        println!("bss_end_offset:{}", bss_end_offset);
    }

    #[cfg(target_os = "windows")]
    let alloc_addr = unsafe {
        VirtualAlloc(
            Some(std::ptr::null()),
            total_mem_size,
            MEM_COMMIT,
            PAGE_EXECUTE_READWRITE,
        )
    };
    #[cfg(target_os = "linux")]
    let alloc_addr = unsafe {
        mmap(
            ptr::null_mut(),
            total_mem_size,
            PROT_READ | PROT_WRITE | PROT_EXEC,
            MAP_PRIVATE | MAP_ANONYMOUS,
            -1,
            0,
        )
    };

    if alloc_addr.is_null() {
        return Err(String::from("Failed to allocate memory"));
    }
    let alloc_addr = alloc_addr as *mut u8;
    #[cfg(test)]
    {
        println!("alloc_addr: {:p}", alloc_addr);
    }

    //copy text section data
    for (index, ch) in bof_parsed_data.text_section_data.iter().enumerate() {
        unsafe {
            std::ptr::write(
                alloc_addr.offset(text_start_offset as isize + index as isize),
                *ch,
            );
        }
    }
    //copy data section data
    for (index, ch) in bof_parsed_data.data_section_data.iter().enumerate() {
        unsafe {
            std::ptr::write(
                alloc_addr.offset(data_start_offset as isize + index as isize),
                *ch,
            );
        }
    }
    //copy rdata section data
    for (index, ch) in bof_parsed_data.rdata_section_data.iter().enumerate() {
        unsafe {
            std::ptr::write(
                alloc_addr.offset(rdata_start_offset as isize + index as isize),
                *ch,
            );
        }
    }
    //bss already memset to 0

    // function addr stub
    let mut function_map_stub_index: HashMap<String, usize> = HashMap::new();
    #[cfg(target_os = "windows")]
    {
        let mut index = 0;
        let stub_ptr = unsafe { alloc_addr.offset(stub_start_offset) };
        let stub_ptr = stub_ptr as *mut usize;
        for (k, v) in function_map_addr {
            unsafe {
                std::ptr::write(stub_ptr.offset(index), v);
            }
            function_map_stub_index.insert(k.to_string(), index as usize);
            index = index + 1;
        }
    }
    #[cfg(target_os = "linux")]
    {
        let mut index = 0;
        let stub_ptr = unsafe { alloc_addr.offset(stub_start_offset) };
        let code: [u8; 12] = [
            //\x48\xb8\xEE\xEE\xEE\xEE\xEE\xEE\xEE\xEE\xff\xe0
            0x48, 0xB8, 0xEE, 0xEE, 0xEE, 0xEE, 0xEE, 0xEE, 0xEE, 0xEE, 0xFF, 0xE0,
        ];
        for (k, v) in function_map_addr {
            for (i, b) in code.iter().enumerate() {
                unsafe {
                    std::ptr::write(stub_ptr.offset(index * 12 + i as isize), *b);
                }
            }
            let addr_to_write_func_addr = unsafe {
                stub_ptr.offset(index * 12 + 2) // stub entity size equ 12
            } as *mut u64;
            unsafe {
                std::ptr::write(addr_to_write_func_addr, v as u64);
            }

            function_map_stub_index.insert(k.to_string(), index as usize);
            index = index + 1;
        }
    }

    //fix relocation
    for rel in &bof_parsed_data.relocations {
        let section_number = rel.section_number;
        let target_section_number = rel.target_section_number;
        let offset = rel.offset;
        let offset_in_target_section = rel.offset_in_target_section;
        let rel_type = rel.rel_type;

        let rel_addr = match section_number {
            TEXT_SECTION_NUMBER => unsafe {
                alloc_addr.offset(text_start_offset as isize + offset as isize)
            },
            DATA_SECTION_NUMBER => unsafe {
                alloc_addr.offset(data_start_offset as isize + offset as isize)
            },
            RDATA_SECTION_NUMBER => unsafe {
                alloc_addr.offset(rdata_start_offset as isize + offset as isize)
            },
            BSS_SECTION_NUMBER => unsafe {
                alloc_addr.offset(bss_start_offset as isize + offset as isize)
            },
            _ => {
                return Err(format!("Unknow section number {section_number}"));
            }
        };

        #[cfg(target_os = "windows")]
        {
            let target_rel_addr = if target_section_number == TEXT_SECTION_NUMBER {
                unsafe {
                    alloc_addr
                        .offset(text_start_offset as isize + offset_in_target_section as isize)
                }
            } else if target_section_number == DATA_SECTION_NUMBER {
                unsafe {
                    alloc_addr
                        .offset(data_start_offset as isize + offset_in_target_section as isize)
                }
            } else if target_section_number == RDATA_SECTION_NUMBER {
                unsafe {
                    alloc_addr
                        .offset(rdata_start_offset as isize + offset_in_target_section as isize)
                }
            } else if target_section_number == BSS_SECTION_NUMBER {
                unsafe {
                    alloc_addr.offset(bss_start_offset as isize + offset_in_target_section as isize)
                }
            } else if target_section_number < TEXT_SECTION_NUMBER {
                let func_name = beacon_func_idx_to_func_name(target_section_number as usize);
                let func_stub_index = function_map_stub_index.get(&func_name).unwrap();
                let stub_ptr = unsafe { alloc_addr.offset(stub_start_offset) };
                let stub_ptr = stub_ptr as *mut usize;
                unsafe { stub_ptr.offset(*func_stub_index as isize) as *mut u8 }
            } else if target_section_number == DYN_FUNCTION {
                let func_name = format!("{}${}", rel.module_name, rel.function_name);
                let func_stub_index = function_map_stub_index.get(&func_name).unwrap();
                let stub_ptr = unsafe { alloc_addr.offset(stub_start_offset) };
                let stub_ptr = stub_ptr as *mut usize;
                unsafe { stub_ptr.offset(*func_stub_index as isize) as *mut u8 }
            } else {
                return Err(format!(
                    "Unknow target section number {target_section_number}"
                ));
            };

            #[cfg(test)]
            {
                println!("rel_type:{rel_type}");
            }
            match rel_type {
                IMAGE_REL_AMD64_ADDR64 => {
                    // 1
                    let addr = target_rel_addr as usize;
                    let rel_addr = rel_addr as *mut usize;
                    unsafe {
                        std::ptr::write(rel_addr, addr);
                    }
                }
                IMAGE_REL_AMD64_REL32 => {
                    // 4
                    let addr = ((target_rel_addr as isize) - (rel_addr as isize + 4)) as i32;
                    let rel_addr = rel_addr as *mut i32;
                    unsafe {
                        std::ptr::write(rel_addr, addr);
                    }
                }
                IMAGE_REL_I386_DIR32 => {
                    // 6
                    let addr = target_rel_addr as usize;
                    let rel_addr = rel_addr as *mut usize;
                    unsafe {
                        std::ptr::write(rel_addr, addr);
                    }
                }
                IMAGE_REL_I386_REL32 => {
                    // 20
                    let addr = ((target_rel_addr as isize) - (rel_addr as isize + 4)) as isize;
                    let rel_addr = rel_addr as *mut isize;
                    unsafe {
                        std::ptr::write(rel_addr, addr);
                    }
                }
                _ => {
                    return Err(format!("Unknow rel_type: {rel_type}"));
                }
            }
        }

        #[cfg(target_os = "linux")]
        {
            let target_rel_start_addr = if target_section_number == TEXT_SECTION_NUMBER {
                unsafe { alloc_addr.offset(text_start_offset as isize) }
            } else if target_section_number == DATA_SECTION_NUMBER {
                unsafe { alloc_addr.offset(data_start_offset as isize) }
            } else if target_section_number == RDATA_SECTION_NUMBER {
                unsafe { alloc_addr.offset(rdata_start_offset as isize) }
            } else if target_section_number == BSS_SECTION_NUMBER {
                unsafe { alloc_addr.offset(bss_start_offset as isize) }
            } else if target_section_number < TEXT_SECTION_NUMBER {
                let func_name = beacon_func_idx_to_func_name(target_section_number as usize);
                let func_stub_index = function_map_stub_index.get(&func_name).unwrap();
                let stub_ptr = unsafe { alloc_addr.offset(stub_start_offset) };
                unsafe { stub_ptr.offset((*func_stub_index * 12) as isize) as *mut u8 }
            } else if target_section_number == DYN_FUNCTION {
                let func_name = format!("{}", rel.function_name);
                let func_stub_index = function_map_stub_index.get(&func_name).unwrap();
                let stub_ptr = unsafe { alloc_addr.offset(stub_start_offset) };
                unsafe { stub_ptr.offset((*func_stub_index * 12) as isize) as *mut u8 }
            } else {
                return Err(format!(
                    "Unknow target section number {target_section_number}"
                ));
            };

            match rel_type {
                R_X86_64_64 => {
                    //S + A
                    // 1
                    let fix_value = target_rel_start_addr as i64 + offset_in_target_section as i64;
                    let rel_addr = rel_addr as *mut i64;
                    unsafe {
                        std::ptr::write(rel_addr, fix_value);
                    }
                }
                R_X86_64_PC32 => {
                    //S + A - P
                    let fix_value = (target_rel_start_addr as i64
                        + offset_in_target_section as i64)
                        - rel_addr as i64;
                    let rel_addr = rel_addr as *mut i32;
                    unsafe {
                        std::ptr::write(rel_addr, fix_value as i32);
                    }
                }
                R_X86_64_PLT32 => {
                    //L + A - P
                    let fix_value = (target_rel_start_addr as i64
                        + offset_in_target_section as i64)
                        - rel_addr as i64;
                    let rel_addr = rel_addr as *mut i32;
                    unsafe {
                        std::ptr::write(rel_addr, fix_value as i32);
                    }
                }
                _ => {
                    return Err(format!("Unknow rel_type: {rel_type}"));
                }
            }
        }
    }

    let entry =
        unsafe { alloc_addr.offset((bof_parsed_data.oep as usize + text_start_offset) as isize) };
    let entry: extern "C" fn() -> usize = unsafe { mem::transmute(entry) };

    entry();

    //memset bof data to 0 and free
    unsafe {
        std::ptr::write_bytes(alloc_addr, 0, total_mem_size);
    }

    //memory free
    #[cfg(target_os = "windows")]
    {
        let virtual_free_result = unsafe { VirtualFree(alloc_addr as *mut c_void, 0, MEM_RELEASE) };
        match virtual_free_result {
            Ok(_) => {}
            Err(e) => return Err(format!("VirtualFree error {e}")),
        }
    }
    #[cfg(target_os = "linux")]
    {
        let virtual_free_result = unsafe { munmap(alloc_addr as *mut c_void, total_mem_size) };
        if virtual_free_result != 0 {
            return Err(format!("munmap error"));
        }
    }

    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_windows_bof_loader() {
        //64 bit , MessageBox
        let bof_data: Vec<u8> = vec![
            0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x1e, 0x0, 0x0, 0x0, 0x48, 0x83, 0xec, 0x28,
            0x45, 0x33, 0xc9, 0x45, 0x33, 0xc0, 0x48, 0x8d, 0x15, 0x0, 0x0, 0x0, 0x0, 0x33, 0xc9,
            0xff, 0x15, 0x0, 0x0, 0x0, 0x0, 0x48, 0x83, 0xc4, 0x28, 0xc3, 0x6, 0x0, 0x0, 0x0, 0x68,
            0x65, 0x6c, 0x6c, 0x6f, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x1, 0x10, 0x0,
            0x0, 0x0, 0x0, 0x0, 0x0, 0x4, 0x0, 0x0, 0x0, 0x0, 0x10, 0x0, 0x0, 0xd, 0x0, 0x0, 0x0,
            0x4, 0x10, 0x0, 0x0, 0x6, 0x0, 0x0, 0x0, 0x55, 0x73, 0x65, 0x72, 0x33, 0x32, 0xb, 0x0,
            0x0, 0x0, 0x4d, 0x65, 0x73, 0x73, 0x61, 0x67, 0x65, 0x42, 0x6f, 0x78, 0x41, 0x4, 0x0,
            0x0, 0x0, 0x0, 0x10, 0x0, 0x0, 0x15, 0x0, 0x0, 0x0, 0x5, 0x10, 0x0, 0x0,
        ];

        let _ = bof_lodaer(&bof_data).unwrap();
    }

    #[test]
    fn test_linux_bof_loader() {
        //64 bit 
        let bof_data: Vec<u8> = vec![
            0x2b, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xa9, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xf3,
            0xf, 0x1e, 0xfa, 0x55, 0x48, 0x89, 0xe5, 0x48, 0x8b, 0x15, 0x0, 0x0, 0x0, 0x0, 0x48,
            0x8b, 0x5, 0x0, 0x0, 0x0, 0x0, 0x48, 0x89, 0xc6, 0xbf, 0x0, 0x0, 0x0, 0x0, 0xb8, 0x0,
            0x0, 0x0, 0x0, 0xe8, 0x0, 0x0, 0x0, 0x0, 0x90, 0x5d, 0xc3, 0xf3, 0xf, 0x1e, 0xfa, 0x55,
            0x48, 0x89, 0xe5, 0x48, 0x8d, 0x5, 0x0, 0x0, 0x0, 0x0, 0x48, 0x89, 0xc2, 0x48, 0x8d,
            0x5, 0x0, 0x0, 0x0, 0x0, 0x48, 0x89, 0xc6, 0xbf, 0x0, 0x0, 0x0, 0x0, 0xb8, 0x0, 0x0,
            0x0, 0x0, 0xe8, 0x0, 0x0, 0x0, 0x0, 0xb8, 0x0, 0x0, 0x0, 0x0, 0xe8, 0x0, 0x0, 0x0, 0x0,
            0xc6, 0x5, 0x0, 0x0, 0x0, 0x0, 0x61, 0xc6, 0x5, 0x0, 0x0, 0x0, 0x0, 0x61, 0xc6, 0x5,
            0x0, 0x0, 0x0, 0x0, 0x61, 0xc6, 0x5, 0x0, 0x0, 0x0, 0x0, 0x61, 0xc6, 0x5, 0x0, 0x0,
            0x0, 0x0, 0x0, 0x48, 0x8d, 0x5, 0x0, 0x0, 0x0, 0x0, 0x48, 0x89, 0xc2, 0x48, 0x8d, 0x5,
            0x0, 0x0, 0x0, 0x0, 0x48, 0x89, 0xc6, 0xbf, 0x0, 0x0, 0x0, 0x0, 0xb8, 0x0, 0x0, 0x0,
            0x0, 0xe8, 0x0, 0x0, 0x0, 0x0, 0x90, 0x5d, 0xc3, 0x10, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
            0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
            0x35, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x48, 0x65, 0x6c, 0x6c, 0x6f, 0x20, 0x25,
            0x73, 0xa, 0x0, 0x68, 0x61, 0x6e, 0x68, 0x61, 0x6e, 0x0, 0x74, 0x65, 0x73, 0x74, 0x5f,
            0x66, 0x75, 0x6e, 0x63, 0x0, 0x77, 0x65, 0x20, 0x77, 0x69, 0x6c, 0x6c, 0x20, 0x63,
            0x61, 0x6c, 0x6c, 0x20, 0x25, 0x73, 0x0, 0x74, 0x6d, 0x70, 0x73, 0x74, 0x72, 0x20,
            0x25, 0x73, 0x0, 0x0, 0x4, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x1, 0x10, 0x0, 0x0, 0x0, 0x0,
            0x0, 0x0, 0x4, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x2, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
            0x0, 0x0, 0x10, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xb, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
            0x1, 0x10, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xfc, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
            0xff, 0x2, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x10, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
            0x12, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x5, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xfc,
            0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x4, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
            0x10, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x24, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x2, 0x10,
            0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xd, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x2, 0x0, 0x0,
            0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x10, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x36, 0x0, 0x0, 0x0,
            0x0, 0x0, 0x0, 0x0, 0x2, 0x10, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x17, 0x0, 0x0, 0x0, 0x0,
            0x0, 0x0, 0x0, 0x2, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x10, 0x0, 0x0, 0x0, 0x0,
            0x0, 0x0, 0x40, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x5, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
            0x0, 0xfc, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x4, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
            0x0, 0x0, 0x10, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x52, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
            0x0, 0x10, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xfc, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
            0xff, 0x4, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x10, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
            0x5c, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x3, 0x10, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xfb,
            0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x2, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
            0x10, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x62, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x3, 0x10,
            0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xfc, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x2, 0x0,
            0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x10, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x69, 0x0, 0x0,
            0x0, 0x0, 0x0, 0x0, 0x0, 0x3, 0x10, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xfd, 0xff, 0xff,
            0xff, 0xff, 0xff, 0xff, 0xff, 0x2, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x10, 0x0,
            0x0, 0x0, 0x0, 0x0, 0x0, 0x70, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x3, 0x10, 0x0, 0x0,
            0x0, 0x0, 0x0, 0x0, 0xfe, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x2, 0x0, 0x0, 0x0,
            0x0, 0x0, 0x0, 0x0, 0x0, 0x10, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x77, 0x0, 0x0, 0x0, 0x0,
            0x0, 0x0, 0x0, 0x3, 0x10, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xff, 0xff, 0xff, 0xff, 0xff,
            0xff, 0xff, 0xff, 0x2, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x10, 0x0, 0x0, 0x0,
            0x0, 0x0, 0x0, 0x7e, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x3, 0x10, 0x0, 0x0, 0x0, 0x0,
            0x0, 0x0, 0xfc, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x2, 0x0, 0x0, 0x0, 0x0, 0x0,
            0x0, 0x0, 0x0, 0x10, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x86, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
            0x0, 0x2, 0x10, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x27, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
            0x2, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x10, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x90,
            0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x5, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xfc, 0xff,
            0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x4, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x10,
            0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xa2, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x2, 0x10, 0x0,
            0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x1, 0x0, 0x0, 0x0,
            0x0, 0x0, 0x0, 0x0, 0x1, 0x10, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
            0x0, 0x0, 0x0, 0x2, 0x10, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0xa, 0x0, 0x0, 0x0, 0x0, 0x0,
            0x0, 0x0, 0x1, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x1, 0x10, 0x0, 0x0, 0x0, 0x0, 0x0,
            0x0, 0x8, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x5, 0x10, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0,
        ];

        let _ = bof_lodaer(&bof_data).unwrap();
    }
}
