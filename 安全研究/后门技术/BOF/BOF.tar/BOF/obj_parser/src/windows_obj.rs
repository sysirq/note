use bof_common::*;
use std::{cell::RefCell, mem, ops::Deref, ptr};

#[derive(Clone, Copy)]
#[repr(C, packed(2))]
#[allow(non_snake_case)]
pub struct ImageFileHeader {
    pub Machine: u16,
    pub NumberOfSections: u16,
    pub TimeDateStamp: u32,
    pub PointerToSymbolTable: u32,
    pub NumberOfSymbols: u32,
    pub SizeOfOptionalHeader: u16,
    pub Characteristics: u16,
}

const IMAGE_SIZEOF_SHORT_NAME: usize = 8;

#[derive(Clone, Copy)]
#[repr(C, packed(2))]
#[allow(non_snake_case)]
pub struct ImageSectionHeader {
    Name: [u8; IMAGE_SIZEOF_SHORT_NAME],
    Misc: ImageSectionHeaderMisc,
    VirtualAddress: u32,
    SizeOfRawData: u32,
    PointerToRawData: u32,
    PointerToRelocations: u32,
    PointerToLinenumbers: u32,
    NumberOfRelocations: u16,
    NumberOfLinenumbers: u16,
    Characteristics: u32,
}

#[derive(Clone, Copy)]
#[repr(C)]
#[allow(non_snake_case)]
pub union ImageSectionHeaderMisc {
    PhysicalAddress: u32,
    VirtualSize: u32,
}

#[derive(Clone, Copy)]
#[repr(C, packed(2))]
#[allow(non_snake_case)]
pub struct ImageRelocation {
    pub Dummy_union_name: ImageRelocationDummyunionname,
    pub SymbolTableIndex: u32,
    pub Type: u16,
}

#[derive(Clone, Copy)]
#[repr(C)]
#[allow(non_snake_case)]
pub union ImageRelocationDummyunionname {
    pub VirtualAddress: u32,
    pub RelocCount: u32, // Set to the real count when IMAGE_SCN_LNK_NRELOC_OVFL is set
}

#[derive(Clone, Copy)]
#[repr(C, packed(2))]
#[allow(non_snake_case)]
pub struct ImageSymbol {
    pub N: ImageSymbolN,
    pub Value: u32,
    pub SectionNumber: u16,
    pub Type: u16,
    pub StorageClass: u8,
    pub NumberOfAuxSymbols: u8,
}

#[derive(Clone, Copy)]
#[repr(C)]
#[allow(non_snake_case)]
pub union ImageSymbolN {
    pub ShortName: [u8; 8],
    pub Name: ImageSymbolName,
    pub long_name: [u32; 2], // PBYTE [2]
}

#[derive(Clone, Copy)]
#[repr(C)]
#[allow(non_snake_case)]
pub struct ImageSymbolName {
    pub Short: u32, // if 0, use LongName
    pub Long: u32,  // offset into string table
}

#[allow(dead_code)]
pub struct WindowsObj {
    arch_type: u8,
    oep: u64,
    file_header: Option<Box<ImageFileHeader>>,

    text_section_header: Option<Box<ImageSectionHeader>>,
    data_section_header: Option<Box<ImageSectionHeader>>,
    rdata_section_header: Option<Box<ImageSectionHeader>>,
    bss_section_header: Option<Box<ImageSectionHeader>>,

    text_section_number: u64,
    data_section_number: u64,
    rdata_section_number: u64,
    bss_section_number: u64,

    text_section_data: RefCell<Vec<u8>>,
    data_section_data: RefCell<Vec<u8>>,
    rdata_section_data: RefCell<Vec<u8>>,
    bss_section_data_size: u64,

    symbol_table: Vec<ImageSymbol>,

    text_section_relocation_table: RefCell<Vec<ImageRelocation>>,
    data_section_relocation_table: RefCell<Vec<ImageRelocation>>,
    rdata_section_relocation_table: RefCell<Vec<ImageRelocation>>,
    bss_section_relocation_table: RefCell<Vec<ImageRelocation>>,

    common_relocation_info: RefCell<Vec<Relocation>>,
}

impl WindowsObj {
    fn read_file_header(&mut self, obj_data: &[u8]) -> Result<(), String> {
        //file header
        let obj_data_ptr = obj_data as *const _ as *const u8;
        let file_header_ptr = obj_data_ptr as *const ImageFileHeader;
        is_data_len_enough(
            obj_data_ptr as usize,
            file_header_ptr as usize,
            obj_data.len(),
            mem::size_of::<ImageFileHeader>(),
            "not hava enough space to read ImageFileHeader",
        )?;
        let file_header = unsafe { ptr::read_unaligned(file_header_ptr) };
        self.file_header = Some(Box::new(file_header));
        Ok(())
    }

    fn read_section_header(&mut self, obj_data: &[u8]) -> Result<(), String> {
        let obj_data_ptr = obj_data as *const _ as *const u8;
        let section_header_ptr = unsafe {
            obj_data_ptr.offset(
                (mem::size_of::<ImageFileHeader>()
                    + self.file_header.as_ref().unwrap().SizeOfOptionalHeader as usize)
                    as isize,
            )
        };
        //coff section number start from 1
        let mut section_header_ptr = section_header_ptr as *const ImageSectionHeader;
        for i in 1..=self.file_header.as_ref().unwrap().NumberOfSections {
            is_data_len_enough(
                obj_data_ptr as usize,
                section_header_ptr as usize,
                obj_data.len(),
                mem::size_of::<ImageSectionHeader>(),
                "not hava enough space to read ImageSectionHeader",
            )?;
            let section_header = unsafe { ptr::read_unaligned(section_header_ptr) };
            let name = section_header.Name.to_vec();

            let section_name = match String::from_utf8(name) {
                Ok(s) => s,
                Err(_) => "".to_string(),
            };
            if section_name.contains(".text") {
                self.text_section_header = Some(Box::new(section_header));
                self.text_section_number = i.into();
            } else if section_name.contains(".rdata") {
                self.rdata_section_header = Some(Box::new(section_header));
                self.rdata_section_number = i.into();
            } else if section_name.contains(".data") {
                self.data_section_header = Some(Box::new(section_header));
                self.data_section_number = i.into();
            } else if section_name.contains(".bss") {
                self.bss_section_header = Some(Box::new(section_header));
                self.bss_section_number = i.into();
            }
            section_header_ptr = unsafe { section_header_ptr.offset(1) };
        }

        Ok(())
    }

    fn read_symbol_table(&mut self, obj_data: &[u8]) -> Result<(), String> {
        let obj_data_ptr = obj_data as *const _ as *const u8;

        let pointer_to_sym_table = self.file_header.as_ref().unwrap().PointerToSymbolTable;
        let number_of_syms = self.file_header.as_ref().unwrap().NumberOfSymbols;
        let symbol_table_ptr = unsafe { obj_data_ptr.offset(pointer_to_sym_table as isize) };
        let mut symbol_table_ptr = symbol_table_ptr as *const ImageSymbol;

        is_data_len_enough(
            obj_data_ptr as usize,
            symbol_table_ptr as usize,
            obj_data.len(),
            mem::size_of::<ImageSymbol>() * number_of_syms as usize,
            "not hava enough space to read ImageSymbols",
        )?;

        for _ in 0..number_of_syms {
            let symbol = unsafe { ptr::read_unaligned(symbol_table_ptr) };
            self.symbol_table.push(symbol);
            symbol_table_ptr = unsafe { symbol_table_ptr.offset(1) };
        }

        Ok(())
    }

    fn read_relocation_table(
        &self,
        obj_data: &[u8],
        section_header: &Option<Box<ImageSectionHeader>>,
        relocation_table: &RefCell<Vec<ImageRelocation>>,
    ) -> Result<(), String> {
        let obj_data_ptr = obj_data as *const _ as *const u8;
        if let Some(section_header) = section_header {
            let relocation_ptr =
                unsafe { obj_data_ptr.offset((section_header).PointerToRelocations as isize) };

            let mut relocation_ptr = relocation_ptr as *const ImageRelocation;
            let num_of_rec = section_header.NumberOfRelocations;

            is_data_len_enough(
                obj_data_ptr as usize,
                relocation_ptr as usize,
                obj_data.len(),
                mem::size_of::<ImageRelocation>() * num_of_rec as usize,
                "not hava enough space to read ImageRelocations",
            )?;

            for _ in 0..num_of_rec {
                let relocation = unsafe { ptr::read_unaligned(relocation_ptr) };
                relocation_table.borrow_mut().push(relocation);
                relocation_ptr = unsafe { relocation_ptr.offset(1) };
            }
        }

        Ok(())
    }

    fn get_symbol_name(&self, obj_data: &[u8], symbol: &ImageSymbol) -> String {
        let name;
        let mut ch_vec: Vec<u8> = Vec::new();
        let obj_data_ptr = obj_data as *const _ as *const u8;
        if unsafe { symbol.N.Name.Short } == 0 {
            let pstr = unsafe {
                obj_data_ptr.offset(
                    (self.file_header.as_ref().unwrap().PointerToSymbolTable as isize)
                        + (self.file_header.as_ref().unwrap().NumberOfSymbols as isize)
                            * (mem::size_of::<ImageSymbol>() as isize),
                )
            };

            let mut pstr = unsafe { pstr.offset(symbol.N.Name.Long as isize) };

            if let Err(_) = is_data_len_enough(
                obj_data_ptr as usize,
                pstr as usize,
                obj_data.len(),
                1,
                "not have enough space to read symbol ch ",
            ) {
                return "".to_string();
            }

            let mut ch = unsafe { ptr::read(pstr) };
            while ch != 0 {
                ch_vec.push(ch);

                pstr = unsafe { pstr.offset(1) };

                if let Err(_) = is_data_len_enough(
                    obj_data_ptr as usize,
                    pstr as usize,
                    obj_data.len(),
                    1,
                    "not have enough space to read symbol ch ",
                ) {
                    return "".to_string();
                }
                ch = unsafe { ptr::read(pstr) };
            }
        } else {
            for ch in unsafe { symbol.N.ShortName } {
                if ch == 0 {
                    break;
                }
                ch_vec.push(ch);
            }
        }
        name = match std::str::from_utf8(&ch_vec) {
            Ok(str) => str,
            Err(_) => "",
        };
        name.to_string()
    }

    fn get_and_set_oep(&mut self, obj_data: &[u8], entry_func_name: &str) -> Result<u32, String> {
        for symbol in &self.symbol_table {
            let name = self.get_symbol_name(obj_data, symbol);

            if (name == entry_func_name)
                && (symbol.SectionNumber == self.text_section_number as u16)
                && (symbol.StorageClass == 2)
            {
                self.oep = symbol.Value as u64;
                return Ok(symbol.Value);
            }
        }
        return Err(String::from("Found oep error"));
    }

    #[allow(unused_variables)]
    #[allow(dead_code)]
    fn generate_common_relocation_info(
        &self,
        obj_data: &[u8],
        relocation_table: &RefCell<Vec<ImageRelocation>>,
        section_header: &Option<Box<ImageSectionHeader>>,
        section_number: u64,
    ) -> Result<(), String> {
        let obj_data_ptr = obj_data as *const _ as *const u8;

        for rel in relocation_table.borrow().deref() {
            let symbol_table_idx = rel.SymbolTableIndex;
            let symbol = &self.symbol_table[symbol_table_idx as usize];
            let mut symbol_name = self.get_symbol_name(obj_data, symbol);
            let is_external_symbol = symbol.SectionNumber == 0;

            let mut module_name = "".to_string();
            let mut function_name = "".to_string();

            symbol_name = match symbol_name.strip_prefix("__imp__") {
                //x86_64-w64-mingw32-gcc
                Some(remaining) => remaining.to_string(),
                None => symbol_name,
            };

            symbol_name = match symbol_name.strip_prefix("__imp_") {
                //cl.exe
                Some(remaining) => remaining.to_string(),
                None => symbol_name,
            };

            let rel_type = match rel.Type as u64 {
                IMAGE_REL_AMD64_ADDR64 => IMAGE_REL_AMD64_ADDR64,
                IMAGE_REL_AMD64_REL32 => IMAGE_REL_AMD64_REL32,
                IMAGE_REL_I386_DIR32 => IMAGE_REL_I386_DIR32,
                IMAGE_REL_I386_REL32 => IMAGE_REL_I386_REL32,
                _ => {
                    return Err(format!("Unknow relocation type:{}", rel.Type));
                }
            };

            let target_section_number = if symbol.SectionNumber == self.text_section_number as u16 {
                TEXT_SECTION_NUMBER
            } else if symbol.SectionNumber == self.rdata_section_number as u16 {
                RDATA_SECTION_NUMBER
            } else if symbol.SectionNumber == self.data_section_number as u16 {
                DATA_SECTION_NUMBER
            } else if symbol.SectionNumber == self.bss_section_number as u16 {
                BSS_SECTION_NUMBER
            } else {
                //external symbol
                let beacon_internal_func_index =
                    bof_loader::beacon_api::get_beacon_internal_function_index(&symbol_name);
                if beacon_internal_func_index == u64::MAX {
                    //DYN
                    let parts: Vec<&str> = symbol_name.split("$").collect();
                    if parts.len() != 2 {
                        return Err(format!("Unknow dyn symbol {}", symbol_name));
                    }
                    module_name = parts[0].to_string();
                    function_name = parts[1].to_string();

                    let parts: Vec<&str> = function_name.split("@").collect(); //MessageBoxA@16
                    if parts.len() == 2 {
                        function_name = parts[0].to_string();
                    }

                    DYN_FUNCTION
                } else {
                    if beacon_internal_func_index > TEXT_SECTION_NUMBER {
                        return Err(format!("Unknow beacon internal function {}", symbol_name));
                    }
                    beacon_internal_func_index
                }
            };

            let offset = unsafe { rel.Dummy_union_name.VirtualAddress };
            let mut offset_in_target_section = symbol.Value;

            if (symbol.StorageClass == 0x0003) && (offset_in_target_section == 0) {
                let value_ptr = unsafe {
                    obj_data_ptr.offset(
                        section_header.as_ref().unwrap().PointerToRawData as isize
                            + offset as isize,
                    )
                };

                is_data_len_enough(
                    obj_data_ptr as usize,
                    value_ptr as usize,
                    obj_data.len(),
                    mem::size_of::<u32>(),
                    "not hava enough space to read offset_in_target_section",
                )?;

                offset_in_target_section = unsafe { ptr::read_unaligned(value_ptr as *const u32) }
            }

            #[cfg(test)]
            {
                println!("symbol name:{}", symbol_name);
                println!("\tis external symbol:{}", is_external_symbol);
                println!("\trel_type:{:x}", rel_type);
                println!("\tsection_number:{:x}", section_number);
                println!("\ttarget_section_number:{:x}", target_section_number);
                println!("\toffset:{:x}", offset);
                println!("\toffset_in_target_section:{:x}", offset_in_target_section);
                println!("\tmodule name:{}", &module_name);
                println!("\tfunction name:{}", &function_name);
            }

            let relocation = Relocation {
                rel_type: rel_type as u64,
                section_number: section_number,
                target_section_number: target_section_number as u64,
                offset: offset as u64,
                offset_in_target_section: offset_in_target_section as u64,
                module_name: module_name,
                function_name: function_name,
            };

            self.common_relocation_info.borrow_mut().push(relocation);
        }
        Ok(())
    }

    fn get_section_data(
        &self,
        obj_data: &[u8],
        section_header: &Option<Box<ImageSectionHeader>>,
        section_data: &RefCell<Vec<u8>>,
    ) -> Result<(), String> {
        let obj_data_ptr = obj_data as *const _ as *const u8;
        if let Some(section_header) = section_header {
            let mut section_data_ptr =
                unsafe { obj_data_ptr.offset(section_header.PointerToRawData as isize) };
            let secion_data_size = section_header.SizeOfRawData;
            is_data_len_enough(
                obj_data_ptr as usize,
                section_data_ptr as usize,
                obj_data.len(),
                secion_data_size as usize,
                "not hava enough space to read section data",
            )?;

            unsafe {
                for _ in 0..secion_data_size {
                    let ch = *section_data_ptr;
                    section_data.borrow_mut().push(ch);
                    section_data_ptr = section_data_ptr.offset(1);
                }
            }
        }

        Ok(())
    }

    #[allow(unused_variables)]
    pub fn new(obj_data: &[u8]) -> Result<WindowsObj, String> {
        let arch_type;

        if obj_data[1] == 0x01 && obj_data[0] == 0x4c {
            //Intel 386.
            arch_type = ARCH_X86_32;
        } else if obj_data[1] == 0x86 && obj_data[0] == 0x64 {
            //AMD64 (K8)
            arch_type = ARCH_X86_64;
        } else {
            return Err("Not a valid coff format".to_string());
        }
        let mut obj = WindowsObj {
            arch_type,
            oep: 0,
            file_header: None,
            text_section_header: None,
            data_section_header: None,
            rdata_section_header: None,
            bss_section_header: None,
            text_section_data: RefCell::new(Vec::new()),
            data_section_data: RefCell::new(Vec::new()),
            rdata_section_data: RefCell::new(Vec::new()),
            bss_section_data_size: 0,
            text_section_number: u64::MAX,
            data_section_number: u64::MAX,
            rdata_section_number: u64::MAX,
            bss_section_number: u64::MAX,
            symbol_table: Vec::new(),
            text_section_relocation_table: RefCell::new(Vec::new()),
            rdata_section_relocation_table: RefCell::new(Vec::new()),
            data_section_relocation_table: RefCell::new(Vec::new()),
            bss_section_relocation_table: RefCell::new(Vec::new()),
            common_relocation_info: RefCell::new(Vec::new()),
        };

        obj.read_file_header(obj_data)?;
        obj.read_section_header(obj_data)?;
        obj.read_symbol_table(obj_data)?;

        obj.read_relocation_table(
            obj_data,
            &obj.text_section_header,
            &obj.text_section_relocation_table,
        )?;
        obj.read_relocation_table(
            obj_data,
            &obj.rdata_section_header,
            &obj.rdata_section_relocation_table,
        )?;
        obj.read_relocation_table(
            obj_data,
            &obj.data_section_header,
            &obj.data_section_relocation_table,
        )?;
        obj.read_relocation_table(
            obj_data,
            &obj.bss_section_header,
            &obj.bss_section_relocation_table,
        )?;

        #[cfg(test)]
        {
            println!(
                "sizeof ImageFileHeader: {}",
                mem::size_of::<ImageFileHeader>()
            );
            println!(
                "sizeof ImageSectionHeader: {}",
                mem::size_of::<ImageSectionHeader>()
            );
            println!(
                "sizeof ImageRelocation: {}",
                mem::size_of::<ImageRelocation>()
            );
            println!("sizeof ImageSymbol: {}", mem::size_of::<ImageSymbol>());

            println!("text section number:{}", obj.text_section_number);
            println!("rdata section number:{}", obj.rdata_section_number);
            println!("data section number:{}", obj.data_section_number);
            println!("bss section number:{}", obj.bss_section_number);
        }

        //windows cl.exe: _go , Linux mingw: go
        let oep = match obj.get_and_set_oep(obj_data, "_go") {
            Ok(_oep) => _oep,
            Err(_) => {
                if let Ok(_oep) = obj.get_and_set_oep(obj_data, "go") {
                    _oep
                } else {
                    return Err("Get OEP error".to_string());
                }
            }
        };

        #[cfg(test)]
        {
            println!("OEP: {oep}");
        }

        obj.generate_common_relocation_info(
            obj_data,
            &obj.text_section_relocation_table,
            &obj.text_section_header,
            TEXT_SECTION_NUMBER,
        )?;
        obj.generate_common_relocation_info(
            obj_data,
            &obj.data_section_relocation_table,
            &obj.data_section_header,
            DATA_SECTION_NUMBER,
        )?;
        obj.generate_common_relocation_info(
            obj_data,
            &obj.rdata_section_relocation_table,
            &obj.rdata_section_header,
            RDATA_SECTION_NUMBER,
        )?;
        obj.generate_common_relocation_info(
            obj_data,
            &obj.bss_section_relocation_table,
            &obj.bss_section_header,
            BSS_SECTION_NUMBER,
        )?;

        obj.get_section_data(obj_data, &obj.text_section_header, &obj.text_section_data)?;
        obj.get_section_data(obj_data, &obj.data_section_header, &obj.data_section_data)?;
        obj.get_section_data(obj_data, &obj.rdata_section_header, &obj.rdata_section_data)?;
        obj.bss_section_data_size = match obj.bss_section_header {
            Some(ref section_header) => section_header.SizeOfRawData as u64,
            None => 0,
        };

        #[cfg(test)]
        {
            println!("text data size:{}", obj.text_section_data.borrow().len());
            println!("data data size:{}", obj.data_section_data.borrow().len());
            println!("rdata data size:{}", obj.rdata_section_data.borrow().len());
            println!("bss data size:{}", obj.bss_section_data_size);
        }

        Ok(obj)
    }

    pub fn get_bof_data(&self) -> Vec<u8> {
        generate_common_bof_data(
            OS_TYPE_WINDOWS,
            self.arch_type,
            self.oep,
            &*self.text_section_data.borrow(),
            &*self.data_section_data.borrow(),
            &*self.rdata_section_data.borrow(),
            self.bss_section_data_size,
            &*self.common_relocation_info.borrow(),
        )
    }
}
