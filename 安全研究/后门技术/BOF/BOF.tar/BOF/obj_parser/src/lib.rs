use bof_common::is_data_len_enough;
use linux_obj::LinuxObj;

use crate::windows_obj::WindowsObj;

mod linux_obj;
mod windows_obj;

pub fn obj_parser(obj_data:&[u8]) -> Result<Vec<u8>,String>{
   
   is_data_len_enough(obj_data.as_ptr() as usize , 
                 obj_data.as_ptr()as usize, 
                 obj_data.len(), 
                 8, 
                 "not have enough space to read obj magic number")?;

    if obj_data[0] == b'\x7f' && obj_data[1] == b'E' && obj_data[2] == b'L' && obj_data[3] == b'F' {
        let linux_obj = LinuxObj::new(obj_data)?;
        let bof_data = linux_obj.get_bof_data();
        return Ok(bof_data);
    }else if (obj_data[1] == 0x01 && obj_data[0] == 0x4c) || (obj_data[1] == 0x86 && obj_data[0] == 0x64) {
        let windows_obj = WindowsObj::new(obj_data)?;
        let bof_data = windows_obj.get_bof_data();
        return Ok(bof_data);
    }else{
        Err(String::from("Unknow obj format"))
    }
}

#[cfg(test)]
mod tests {
    use std::{fs::File, io::Read};

    use crate::obj_parser;

    #[test]
    fn test_windows_64_obj(){
        //let mut file = File::open("../windows_64_bof.o").unwrap();
        let mut file = File::open("../ipconfig.x64.o").unwrap();
        let mut buf :Vec<u8> = Vec::new();
        
        file.read_to_end(&mut buf).unwrap();

        let data = obj_parser(&buf).unwrap();

        print!("[");
        for ch in data {
            print!("0x{:x},",ch);
        }
        print!("]\n");
    }

    #[test]
    fn test_linux_64_obj(){
        //let mut file = File::open("../windows_64_bof.o").unwrap();
        let mut file = File::open("../linux_obj.o").unwrap();
        let mut buf :Vec<u8> = Vec::new();
        
        file.read_to_end(&mut buf).unwrap();

        let data = obj_parser(&buf).unwrap();

        print!("[");
        for ch in data {
            print!("0x{:x},",ch);
        }
        print!("]\n");
    }

}
