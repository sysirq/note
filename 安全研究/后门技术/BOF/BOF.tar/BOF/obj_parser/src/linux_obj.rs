use std::{
    cell::RefCell, mem, ops::Deref, ptr
};

use bof_common::{
    generate_common_bof_data, is_data_len_enough, Relocation, ARCH_X86_64, BSS_SECTION_NUMBER, DATA_SECTION_NUMBER, DYN_FUNCTION, OS_TYPE_LINUX, RDATA_SECTION_NUMBER, R_X86_64_64, R_X86_64_PC32, R_X86_64_PLT32, TEXT_SECTION_NUMBER
};

type Elf64Half = u16;


type Elf64Word = u32;

type Elf64Xword = u64;
type Elf64Sxword = i64;

type Elf64Addr = u64;

type Elf64Off = u64;

type Elf64Section = u16;

const EI_NIDENT: usize = 16;

#[repr(C)]
pub struct Elf64Ehdr {
    pub e_ident: [u8; EI_NIDENT],
    pub e_type: Elf64Half,
    pub e_machine: Elf64Half,
    pub e_version: Elf64Word,
    pub e_entry: Elf64Addr,
    pub e_phoff: Elf64Off,
    pub e_shoff: Elf64Off,
    pub e_flags: Elf64Word,
    pub e_ehsize: Elf64Half,
    pub e_phentsize: Elf64Half,
    pub e_phnum: Elf64Half,
    pub e_shentsize: Elf64Half,
    pub e_shnum: Elf64Half,
    pub e_shstrndx: Elf64Half,
}

#[derive(Clone)]
#[repr(C)]
pub struct Elf64Sym {
    pub st_name: Elf64Word,
    pub st_info: u8,
    pub st_other: u8,
    pub st_shndx: Elf64Section,
    pub st_value: Elf64Addr,
    pub st_size: Elf64Xword,
}

#[repr(C)]
pub struct Elf64Rela {
    pub r_offset: Elf64Addr,
    pub r_info: Elf64Xword,
    pub r_addend: Elf64Sxword,
}

#[repr(C)]
pub struct Elf64Shdr {
    pub sh_name: Elf64Word,
    pub sh_type: Elf64Word,
    pub sh_flags: Elf64Xword,
    pub sh_addr: Elf64Addr,
    pub sh_offset: Elf64Off,
    pub sh_size: Elf64Xword,
    pub sh_link: Elf64Word,
    pub sh_info: Elf64Word,
    pub sh_addralign: Elf64Xword,
    pub sh_entsize: Elf64Xword,
}

#[allow(non_snake_case)]
fn ELF64_R_SYM(i: u64) -> u64 {
    i >> 32
}

#[allow(non_snake_case)]
fn ELF64_R_TYPE(i: u64) -> u64 {
    i & 0xffffffff
}


pub struct LinuxObj {
    elf_header: Option<Box<Elf64Ehdr>>,
    oep:u64,
    arch_type: u8,

    text_section_header: Option<Box<Elf64Shdr>>,
    data_section_header: Option<Box<Elf64Shdr>>,
    rdata_section_header: Option<Box<Elf64Shdr>>,
    bss_section_header: Option<Box<Elf64Shdr>>,

    text_section_number: u64,
    data_section_number: u64,
    rdata_section_number: u64,
    bss_section_number: u64,

    text_section_data: RefCell<Vec<u8>>,
    data_section_data: RefCell<Vec<u8>>,
    rdata_section_data: RefCell<Vec<u8>>,
    bss_section_data_size: u64,

    text_section_relocation_table: RefCell<Vec<Elf64Rela>>,
    data_section_relocation_table: RefCell<Vec<Elf64Rela>>,
    rdata_section_relocation_table: RefCell<Vec<Elf64Rela>>,
    bss_section_relocation_table: RefCell<Vec<Elf64Rela>>,

    text_section_relocation_symbol_section_number: u64, // relocation table associated symbol section number
    data_section_relocation_symbol_section_number: u64,
    rdata_section_relocation_symbol_section_number: u64,
    bss_section_relocation_symbol_section_number: u64,

    text_section_relocation_symbol_table: RefCell<Vec<Elf64Sym>>, // relocation table associated symbol table
    data_section_relocation_symbol_table: RefCell<Vec<Elf64Sym>>,
    rdata_section_relocation_symbol_table: RefCell<Vec<Elf64Sym>>,
    bss_section_relocation_symbol_table: RefCell<Vec<Elf64Sym>>,

    text_section_symbol_table_strtbl_section_number: u64, // symbol table associated string table
    data_section_symbol_table_strtbl_section_number: u64,
    rdata_section_symbol_table_strtbl_section_number: u64,
    bss_section_symbol_table_strtbl_section_number: u64,

    common_relocation_info: RefCell<Vec<Relocation>>,
}

impl LinuxObj {
    fn read_elf_header(&mut self, obj_data: &[u8]) -> Result<(),String> {

        let obj_data_ptr = obj_data as *const _ as *const u8;
        let elf_header_ptr = obj_data_ptr as *const Elf64Ehdr;

        is_data_len_enough(obj_data_ptr as usize, 
            elf_header_ptr as usize, 
            obj_data.len(), 
            mem::size_of::<Elf64Ehdr>(), 
            "not hava enough space to read elf header")?;
        let elf_header = unsafe { ptr::read_unaligned(elf_header_ptr) };
        self.elf_header = Some(Box::new(elf_header));

        Ok(())
    }

    fn get_string_from_strtab(
        &self,
        obj_data: &[u8],
        strtab_index: isize,
        name_offset: usize,
    ) -> String {
        let obj_data_ptr = obj_data as *const _ as *const u8;
        let section_header_ptr =
            unsafe { obj_data_ptr.offset(self.elf_header.as_ref().unwrap().e_shoff as isize) };
        let section_header_ptr = section_header_ptr as *const Elf64Shdr;
        let section_header_str_tab_ptr =
            unsafe { section_header_ptr.offset(strtab_index as isize) };

        if let Err(_) = is_data_len_enough(obj_data_ptr as usize,
            section_header_str_tab_ptr as usize, 
            obj_data.len(), 
            mem::size_of::<Elf64Shdr>(),
             "not have enough space to read elf section header"){
            
            return "".to_string();
        }
        let section_header_str_tab = unsafe { ptr::read_unaligned(section_header_str_tab_ptr) };

        let sh_name_offset = name_offset as u64 + section_header_str_tab.sh_offset;
        let mut name_ptr = unsafe { obj_data_ptr.offset(sh_name_offset as isize) };

        let mut name_vec: Vec<u8> = Vec::new();
        if let Err(_) = is_data_len_enough(obj_data_ptr as usize,
            name_ptr as usize, 
            obj_data.len(), 
            1,
             "not have enough space to read name ch"){
            
            return "".to_string();
        }
        let mut ch = unsafe { name_ptr.read_unaligned() };
        while ch != 0 {
            name_vec.push(ch);
            name_ptr = unsafe { name_ptr.offset(1) };
            if let Err(_) = is_data_len_enough(obj_data_ptr as usize,
                name_ptr as usize, 
                obj_data.len(), 
                1,
                 "not have enough space to read name ch"){
                
                return "".to_string();
            }
            ch = unsafe { name_ptr.read_unaligned() };
        }

        let name = match String::from_utf8(name_vec) {
            Ok(s) => s,
            Err(_) => "".to_string(),
        };

        return name;
    }

    fn read_section_header(&mut self, obj_data: &[u8])->Result<(),String> {
        let obj_data_ptr = obj_data as *const _ as *const u8;
        let section_header_ptr =
            unsafe { obj_data_ptr.offset(self.elf_header.as_ref().unwrap().e_shoff as isize) };
        let mut section_header_ptr = section_header_ptr as *const Elf64Shdr;

        for i in 0..self.elf_header.as_ref().unwrap().e_shnum {
            is_data_len_enough(obj_data_ptr as usize,
                                section_header_ptr as usize, 
                                obj_data.len(), 
                                mem::size_of::<Elf64Shdr>(),
                                 "not have enough space to read elf section header")?;
            let section_header = unsafe { ptr::read_unaligned(section_header_ptr) };

            let sh_name = self.get_string_from_strtab(
                obj_data,
                self.elf_header.as_ref().unwrap().e_shstrndx as isize,
                section_header.sh_name as usize,
            );

            if sh_name.starts_with(".text") {
                self.text_section_header = Some(Box::new(section_header));
                self.text_section_number = i.into();
            } else if sh_name.starts_with(".rodata") {
                self.rdata_section_header = Some(Box::new(section_header));
                self.rdata_section_number = i.into();
            } else if sh_name.starts_with(".data.rel") {
                self.data_section_header = Some(Box::new(section_header));
                self.data_section_number = i.into();
            } else if sh_name.starts_with(".bss") {
                self.bss_section_header = Some(Box::new(section_header));
                self.bss_section_number = i.into();
            }

            section_header_ptr = unsafe { section_header_ptr.offset(1) };
        }
        Ok(())
    }

    fn read_relocation_table(&mut self, obj_data: &[u8]) -> Result<(),String>{
        let obj_data_ptr = obj_data as *const _ as *const u8;
        let section_header_ptr =
            unsafe { obj_data_ptr.offset(self.elf_header.as_ref().unwrap().e_shoff as isize) };
        let mut section_header_ptr = section_header_ptr as *const Elf64Shdr;

        for _ in 0..self.elf_header.as_ref().unwrap().e_shnum {
            is_data_len_enough(obj_data_ptr as usize,
                                section_header_ptr as usize, 
                                obj_data.len(), 
                                mem::size_of::<Elf64Shdr>(), 
                                "not have enough space to read elf section header")?;
            let section_header = unsafe { ptr::read_unaligned(section_header_ptr) };

            if section_header.sh_type == 4 {
                //SHT_RELA
                //sh_info :The section header index of the section to where the relocation applies.
                //sh_link :The section header index of the associated symbol table.
                let rela_ptr = unsafe { obj_data_ptr.offset(section_header.sh_offset as isize) };
                let mut rela_ptr = rela_ptr as *const Elf64Rela;

                let rela_entity_count = section_header.sh_size / section_header.sh_entsize;
                let mut rela_vec: Vec<Elf64Rela> = Vec::new();

                for _ in 0..rela_entity_count {
                    is_data_len_enough(obj_data_ptr as usize,
                        rela_ptr as usize, 
                        obj_data.len(), 
                        mem::size_of::<Elf64Rela>(), 
                        "not have enough space to read elf rela element")?;
                    let rela = unsafe { rela_ptr.read_unaligned() };
                    rela_vec.push(rela);
                    rela_ptr = unsafe { rela_ptr.offset(1) };
                }

                if section_header.sh_info == self.text_section_number as u32 {
                    self.text_section_relocation_table
                        .borrow_mut()
                        .extend(rela_vec);
                    self.text_section_relocation_symbol_section_number =
                        section_header.sh_link as u64;
                } else if section_header.sh_info == self.data_section_number as u32 {
                    self.data_section_relocation_table
                        .borrow_mut()
                        .extend(rela_vec);
                    self.data_section_relocation_symbol_section_number =
                        section_header.sh_link as u64;
                } else if section_header.sh_info == self.rdata_section_number as u32 {
                    self.rdata_section_relocation_table
                        .borrow_mut()
                        .extend(rela_vec);
                    self.rdata_section_relocation_symbol_section_number =
                        section_header.sh_link as u64;
                } else if section_header.sh_info == self.bss_section_number as u32 {
                    self.bss_section_relocation_table
                        .borrow_mut()
                        .extend(rela_vec);
                    self.bss_section_relocation_symbol_section_number =
                        section_header.sh_link as u64;
                }
            }

            section_header_ptr = unsafe { section_header_ptr.offset(1) };
        }
        Ok(())
    }

    fn read_symbol_table(&mut self, obj_data: &[u8])->Result<(),String> {
        let obj_data_ptr = obj_data as *const _ as *const u8;
        let section_header_ptr =
            unsafe { obj_data_ptr.offset(self.elf_header.as_ref().unwrap().e_shoff as isize) };
        let mut section_header_ptr = section_header_ptr as *const Elf64Shdr;

        for i in 0..self.elf_header.as_ref().unwrap().e_shnum {
            is_data_len_enough(obj_data_ptr as usize,
                section_header_ptr as usize, 
                obj_data.len(), 
                mem::size_of::<Elf64Shdr>(), 
                "not have enough space to read elf section header")?;
            let section_header = unsafe { ptr::read_unaligned(section_header_ptr) };

            if section_header.sh_type == 2 {//SHT_SYMTAB
                let symbol_ptr = unsafe { obj_data_ptr.offset(section_header.sh_offset as isize) };
                let mut symbol_ptr = symbol_ptr as *const Elf64Sym;
                let symbol_entity_count = section_header.sh_size / section_header.sh_entsize;
                let mut symbol_vec: Vec<Elf64Sym> = Vec::new();

                for _ in 0..symbol_entity_count {
                    is_data_len_enough(obj_data_ptr as usize,
                        symbol_ptr as usize, 
                        obj_data.len(), 
                        mem::size_of::<Elf64Sym>(), 
                        "not have enough space to read elf symbol table")?;
                    let symbol = unsafe { symbol_ptr.read_unaligned() };

                    symbol_vec.push(symbol);
                    symbol_ptr = unsafe { symbol_ptr.offset(1) };
                }

                if i == self.text_section_relocation_symbol_section_number as u16 {
                    self.text_section_relocation_symbol_table
                        .borrow_mut()
                        .extend(symbol_vec.to_vec());
                    self.text_section_symbol_table_strtbl_section_number =
                        section_header.sh_link as u64;
                } 
                if i == self.data_section_relocation_symbol_section_number as u16 {
                    self.data_section_relocation_symbol_table
                        .borrow_mut()
                        .extend(symbol_vec.to_vec());
                    self.data_section_symbol_table_strtbl_section_number =
                        section_header.sh_link as u64;
                } 
                if i == self.rdata_section_relocation_symbol_section_number as u16 {
                    self.rdata_section_relocation_symbol_table
                        .borrow_mut()
                        .extend(symbol_vec.to_vec());
                    self.rdata_section_symbol_table_strtbl_section_number =
                        section_header.sh_link as u64;
                }
                if i == self.bss_section_relocation_symbol_section_number as u16 {
                    self.bss_section_relocation_symbol_table
                        .borrow_mut()
                        .extend(symbol_vec.to_vec());
                    self.bss_section_symbol_table_strtbl_section_number =
                        section_header.sh_link as u64;
                }
            }

            section_header_ptr = unsafe { section_header_ptr.offset(1) };
        }
        Ok(())
    }

    #[allow(dead_code)]
    #[allow(unused_variables)]
    fn generate_common_relocation_info(
        &self,
        obj_data: &[u8],
        section_number: u64,
        section_header: &Option<Box<Elf64Shdr>>,
        relocation_table: &RefCell<Vec<Elf64Rela>>,
        symbol_table: &RefCell<Vec<Elf64Sym>>,
        strtbl_section_number: u64,
    ) -> Result<(), String> {
        let obj_data_ptr = obj_data as *const _ as *const u8;
        let symbol_table = symbol_table.borrow();

        for rela in relocation_table.borrow().deref() {
            let symbol_index = ELF64_R_SYM(rela.r_info);
            let rela_type = ELF64_R_TYPE(rela.r_info);

            let symbol = symbol_table.deref().get(symbol_index as usize).unwrap();

            let symbol_name = self.get_string_from_strtab(
                obj_data,
                strtbl_section_number as isize,
                symbol.st_name as usize,
            );

            let mut module_name = "".to_string();
            let mut function_name = "".to_string();
            let offset = rela.r_offset;
            let is_external_symbol = symbol.st_shndx == 0;

            let target_section_number = if symbol.st_shndx == self.text_section_number as u16 {
                TEXT_SECTION_NUMBER
            } else if symbol.st_shndx == self.rdata_section_number as u16 {
                RDATA_SECTION_NUMBER
            } else if symbol.st_shndx == self.data_section_number as u16 {
                DATA_SECTION_NUMBER
            } else if symbol.st_shndx == self.bss_section_number as u16 {
                BSS_SECTION_NUMBER
            } else {
                //external symbol
                if symbol.st_shndx == 0 {//Undefined section
                    let beacon_internal_func_index = bof_loader::beacon_api::get_beacon_internal_function_index(&symbol_name);
                    if beacon_internal_func_index == u64::MAX {//DYN

                        module_name   = "".to_string();
                        function_name = symbol_name.to_string();
    
                        DYN_FUNCTION
                    }else{
                        if beacon_internal_func_index > TEXT_SECTION_NUMBER {
                            return Err(format!("Unknow beacon internal function {}",symbol_name));
                        }
                        beacon_internal_func_index
                    }
                } else {
                    return Err(format!("Unknow target section number{}", symbol.st_shndx));
                }
            };

            let mut offset_in_target_section = symbol.st_value;

            let rel_type = match rela_type {
                1 /*R_X86_64_64 */    => {//S + A
                    offset_in_target_section = (offset_in_target_section as i64 + rela.r_addend )as u64;
                    R_X86_64_64
                },
                2 /*R_X86_64_PC32 */  => {//S + A - P
                    offset_in_target_section = (offset_in_target_section as i64 + rela.r_addend )as u64;

                    R_X86_64_PC32
                },
                4 /*R_X86_64_PLT32*/  => {//L + A - P
                    offset_in_target_section = rela.r_addend as u64;
                    R_X86_64_PLT32 
                },
                _ => {
                    return Err(format!("Unknow relocation type:{}",rela_type));
                }
            };

            #[cfg(test)]{
                println!("symbol name:{}",symbol_name);
                println!("\tis external symbol:{}",is_external_symbol);
                println!("\trel_type:{:x}",rel_type);
                println!("\tsection_number:{:x}",section_number);
                println!("\ttarget_section_number:{:x}",target_section_number);
                println!("\toffset:{:x}",offset);
                println!("\toffset_in_target_section:{:x}",offset_in_target_section);
                println!("\tmodule name:{}",&module_name);
                println!("\tfunction name:{}",&function_name);
                println!("\t=======================================================");
                println!("\tElf64_Rela.r_offset: {:x}", rela.r_offset);
                println!("\tElf64_Rela.r_info: {:x}", rela.r_info);
                println!("\tElf64_Rela.r_info.sym: {:x}", symbol_index);
                println!("\tElf64_Rela.r_info.type: {:x}", rela_type);
                println!("\tElf64_Rela.r_addend: {:x}", rela.r_addend);
                println!("\tElf64_Sym.st_name: {}", symbol_name);
                println!("\tElf64_Sym.st_info: {:x}", symbol.st_info);
                println!("\tElf64_Sym.st_other: {:x}", symbol.st_other);
                println!("\tElf64_Sym.st_shndx: {:x}", symbol.st_shndx);
                println!("\tElf64_Sym.st_value: {:x}", symbol.st_value);
                println!("\tElf64_Sym.st_size: {:x}", symbol.st_size);
            }

            let relocation = Relocation{ rel_type: rel_type, 
                section_number:section_number, 
                target_section_number: target_section_number, 
                offset:offset,
                offset_in_target_section:offset_in_target_section, 
                module_name: module_name,
                function_name: function_name 
            };

            self.common_relocation_info.borrow_mut().push(relocation);
        }
        Ok(())
    }
    
    fn get_section_data(&self,obj_data: &[u8],section_header:&Option<Box<Elf64Shdr>>,section_data:&RefCell<Vec<u8>>)->Result<(),String>{
        let obj_data_ptr = obj_data as *const _ as *const u8;
        if let Some(section_header) = section_header { 
            let mut section_data_ptr = unsafe {
                obj_data_ptr.offset(section_header.sh_offset as isize)
            };
            let secion_data_size = section_header.sh_size;

            is_data_len_enough(obj_data_ptr as usize, 
                                    section_data_ptr as usize, 
                                    obj_data.len(), 
                                    secion_data_size as usize, 
                                    "not have enoght space to read section data")?;

            unsafe{
                for _ in 0..secion_data_size{
                    let ch = *section_data_ptr;
                    section_data.borrow_mut().push(ch);
                    section_data_ptr = section_data_ptr.offset(1);
                }
            }
        }

        Ok(())
    }
    #[allow(dead_code)]
    #[allow(unused_variables)]
    fn get_and_set_oep(&mut self, obj_data: &[u8], entry_func_name: &str) -> Result<u32, String> {
        let obj_data_ptr = obj_data as *const _ as *const u8;
        let section_header_ptr =
            unsafe { obj_data_ptr.offset(self.elf_header.as_ref().unwrap().e_shoff as isize) };
        let mut section_header_ptr = section_header_ptr as *const Elf64Shdr;

        for i in 0..self.elf_header.as_ref().unwrap().e_shnum {
            is_data_len_enough(obj_data_ptr as usize,
                section_header_ptr as usize, 
                obj_data.len(), 
                mem::size_of::<Elf64Shdr>(), 
                "not have enough space to read elf section header")?;
            let section_header = unsafe { ptr::read_unaligned(section_header_ptr) };

            if section_header.sh_type == 2 {//SHT_SYMTAB
                let symbol_ptr = unsafe { obj_data_ptr.offset(section_header.sh_offset as isize) };
                let mut symbol_ptr = symbol_ptr as *const Elf64Sym;
                let symbol_entity_count = section_header.sh_size / section_header.sh_entsize;
                let  symbol_vec: Vec<Elf64Sym> = Vec::new();

                for _ in 0..symbol_entity_count {
                    is_data_len_enough(obj_data_ptr as usize,
                        symbol_ptr as usize, 
                        obj_data.len(), 
                        mem::size_of::<Elf64Sym>(), 
                        "not have enough space to read elf symbol")?;
                    let symbol = unsafe { symbol_ptr.read_unaligned() };

                    let symbol_name =  self.get_string_from_strtab(obj_data, section_header.sh_link as isize, symbol.st_name as usize);
                    
                    if symbol_name == entry_func_name {
                        if symbol.st_shndx == self.text_section_number as u16 {
                            self.oep = symbol.st_value;
                            return Ok(self.oep as u32);
                        }
                    }

                    symbol_ptr = unsafe { symbol_ptr.offset(1) };
                }
            }
            section_header_ptr = unsafe { section_header_ptr.offset(1) };
        }
        return Err(String::from("Found oep error"));
    }

    pub fn new(obj_data: &[u8]) -> Result<LinuxObj, String> {
        if obj_data[4] != 2 {
            return Err("only support on x64 obj".to_string());
        }
        let mut obj = LinuxObj {
            elf_header: None,
            text_section_header: None,
            data_section_header: None,
            rdata_section_header: None,
            bss_section_header: None,
            text_section_number: u64::MAX,
            data_section_number: u64::MAX,
            rdata_section_number: u64::MAX,
            bss_section_number: u64::MAX,
            text_section_relocation_table: RefCell::new(Vec::new()),
            data_section_relocation_table: RefCell::new(Vec::new()),
            rdata_section_relocation_table: RefCell::new(Vec::new()),
            bss_section_relocation_table: RefCell::new(Vec::new()),
            text_section_relocation_symbol_section_number: u64::MAX,
            data_section_relocation_symbol_section_number: u64::MAX,
            rdata_section_relocation_symbol_section_number: u64::MAX,
            bss_section_relocation_symbol_section_number: u64::MAX,
            text_section_relocation_symbol_table: RefCell::new(Vec::new()),
            data_section_relocation_symbol_table: RefCell::new(Vec::new()),
            rdata_section_relocation_symbol_table: RefCell::new(Vec::new()),
            bss_section_relocation_symbol_table: RefCell::new(Vec::new()),
            text_section_symbol_table_strtbl_section_number: u64::MAX,
            data_section_symbol_table_strtbl_section_number: u64::MAX,
            rdata_section_symbol_table_strtbl_section_number: u64::MAX,
            bss_section_symbol_table_strtbl_section_number: u64::MAX,
            common_relocation_info: RefCell::new(Vec::new()),
            bss_section_data_size: 0,
            text_section_data: RefCell::new(Vec::new()),
            data_section_data: RefCell::new(Vec::new()),
            rdata_section_data: RefCell::new(Vec::new()),
            oep:0,
            arch_type:ARCH_X86_64,
        };

        obj.read_elf_header(obj_data)?;

        if obj.elf_header.as_ref().unwrap().e_type != 1 {
            return Err("not a relocatable file".to_string());
        }

        if obj.elf_header.as_ref().unwrap().e_entry != 0 {
            return Err("Entry point address not equ 0".to_string());
        }

        if obj.elf_header.as_ref().unwrap().e_phnum != 0 {
            return Err("Number of program headers not equ 0".to_string());
        }

        if obj.elf_header.as_ref().unwrap().e_shnum == 0 {
            return Err("Number of section headers equ 0".to_string());
        }

        if obj.elf_header.as_ref().unwrap().e_machine != 62 {
            return Err("only support on x64 obj".to_string());
        }

        obj.read_section_header(obj_data)?;

        #[cfg(test)]
        {
            println!("text section number : {}", obj.text_section_number);
            println!("data section number : {}", obj.data_section_number);
            println!("rdata section number : {}", obj.rdata_section_number);
            println!("bss section number : {}", obj.bss_section_number);

            println!(
                "text section size : {}",
                obj.text_section_header.as_ref().unwrap().sh_size
            );
            println!(
                "data section size : {}",
                obj.data_section_header.as_ref().unwrap().sh_size
            );
            println!(
                "rdata section size : {}",
                obj.rdata_section_header.as_ref().unwrap().sh_size
            );
            println!(
                "bss section size : {}",
                obj.bss_section_header.as_ref().unwrap().sh_size
            );
        }

        obj.read_relocation_table(obj_data)?;
        obj.read_symbol_table(obj_data)?;

        obj.generate_common_relocation_info(
            obj_data,
            TEXT_SECTION_NUMBER,
            &obj.text_section_header,
            &obj.text_section_relocation_table,
            &obj.text_section_relocation_symbol_table,
            obj.text_section_symbol_table_strtbl_section_number,
        )?;

        obj.generate_common_relocation_info(
            obj_data,
            DATA_SECTION_NUMBER,
            &obj.data_section_header,
            &obj.data_section_relocation_table,
            &obj.data_section_relocation_symbol_table,
            obj.data_section_symbol_table_strtbl_section_number,
        )?;

        obj.generate_common_relocation_info(
            obj_data,
            RDATA_SECTION_NUMBER,
            &obj.rdata_section_header,
            &obj.rdata_section_relocation_table,
            &obj.rdata_section_relocation_symbol_table,
            obj.rdata_section_symbol_table_strtbl_section_number,
        )?;

        obj.generate_common_relocation_info(
            obj_data,
            BSS_SECTION_NUMBER,
            &obj.bss_section_header,
            &obj.bss_section_relocation_table,
            &obj.bss_section_relocation_symbol_table,
            obj.bss_section_symbol_table_strtbl_section_number,
        )?;

        obj.get_section_data(obj_data, &obj.text_section_header, &obj.text_section_data)?;
        obj.get_section_data(obj_data, &obj.data_section_header, &obj.data_section_data)?;
        obj.get_section_data(obj_data, &obj.rdata_section_header, &obj.rdata_section_data)?;
        obj.bss_section_data_size = match obj.bss_section_header {
            Some(ref section_header) => {
                section_header.sh_size
            },
            None => 0,
        };

        #[cfg(test)]
        {
            println!("text data size:{}",obj.text_section_data.borrow().len());
            println!("data data size:{}",obj.data_section_data.borrow().len());
            println!("rdata data size:{}",obj.rdata_section_data.borrow().len());
            println!("bss data size:{}",obj.bss_section_data_size);
        }

        obj.get_and_set_oep(obj_data, "go")?;

        #[cfg(test)]
        {
            println!("OEP: {:x}",obj.oep);
        }


        Ok(obj)
    }

    pub fn get_bof_data(&self)->Vec<u8>{
        generate_common_bof_data(OS_TYPE_LINUX,
                                self.arch_type,
                                self.oep,
                            &*self.text_section_data.borrow(),
                          &*self.data_section_data.borrow(), 
                          &*self.rdata_section_data.borrow(), 
                          self.bss_section_data_size,
                          &*self.common_relocation_info.borrow())
    }
}
