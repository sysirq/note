use std::{fs::File, io::Read};
use obj_parser::*;
use bof_loader::*;
fn main() {
    let mut file = File::open("linux_obj.o").unwrap(); 

    let mut buf :Vec<u8> = Vec::new();

    file.read_to_end(&mut buf).unwrap();

    let data = obj_parser(&buf).unwrap();

    bof_lodaer(&data).unwrap();
}
 