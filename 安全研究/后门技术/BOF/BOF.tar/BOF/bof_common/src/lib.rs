use std:: ptr;

//os type
pub const OS_TYPE_LINUX:u8      =0x00;
pub const OS_TYPE_WINDOWS:u8    =0x01;

//system architecture
pub const ARCH_X86_32:u8           =0x00;
pub const ARCH_X86_64:u8           =0x01;

//for windows relocation type
pub const IMAGE_REL_AMD64_ADDR64: u64 = 0x0001;
pub const IMAGE_REL_AMD64_REL32: u64 = 0x0004;
pub const IMAGE_REL_I386_DIR32: u64 = 0x0006;
pub const IMAGE_REL_I386_REL32: u64 = 0x0014;
//for linux relocation type
pub const R_X86_64_64: u64 = 1;
pub const R_X86_64_PC32: u64 = 2;
pub const R_X86_64_PLT32: u64 = 4;

pub const TEXT_SECTION_NUMBER: u64 = 0x1000;
pub const DATA_SECTION_NUMBER: u64 = 0x1001;
pub const RDATA_SECTION_NUMBER: u64 = 0x1002;
pub const BSS_SECTION_NUMBER: u64 = 0x1003;

pub const DYN_FUNCTION: u64 = 0x1004;
pub const END_SECTION_NUMBER: u64 = 0x1005;

//targetSection Number < 0x1000  === BOF Internal Function Index

pub struct Relocation {
    pub target_section_number: u64,
    pub section_number: u64,
    pub rel_type: u64,
    pub offset: u64,
    pub offset_in_target_section: u64,
    pub module_name: String,
    pub function_name: String,
}

pub fn generate_common_bof_data(
    os_type:u8,
    arch_type:u8,
    entry_offset: u64,
    text_section_data: &Vec<u8>,
    data_section_data: &Vec<u8>,
    rdata_section_data: &Vec<u8>,
    bss_section_size: u64,
    rels: &Vec<Relocation>,
) -> Vec<u8> {
    let mut data_vec: Vec<u8> = Vec::new();

    //os type
    data_vec.push(os_type);
    //arch type
    data_vec.push(arch_type);

    //oep append
    data_vec.extend_from_slice(&entry_offset.to_le_bytes());

    //text data append
    let text_data_len = text_section_data.len() as u64;
    data_vec.extend_from_slice(&text_data_len.to_le_bytes());
    if text_data_len != 0 {
        data_vec.extend_from_slice(text_section_data);
    }

    //data data append
    let data_data_len = data_section_data.len() as u64;
    data_vec.extend_from_slice(&data_data_len.to_le_bytes());
    if data_data_len != 0 {
        data_vec.extend_from_slice(data_section_data);
    }

    //rdata data append
    let rdata_data_len = rdata_section_data.len() as u64;
    data_vec.extend_from_slice(&rdata_data_len.to_le_bytes());
    if rdata_data_len != 0 {
        data_vec.extend_from_slice(rdata_section_data);
    }

    //bss size
    let bss_data_len = bss_section_size;
    data_vec.extend_from_slice(&bss_data_len.to_le_bytes());

    //relocation info append
    for rel in rels {
        //append target section number
        let target_section_number = rel.target_section_number;
        data_vec.extend_from_slice(&target_section_number.to_le_bytes());

        let offset_in_target_section = rel.offset_in_target_section;
        data_vec.extend_from_slice(&offset_in_target_section.to_le_bytes());
        
        if target_section_number == DYN_FUNCTION {
            let module_name = &rel.module_name;
            let function_name = &rel.function_name;
            let module_name_len = module_name.len() as u64;
            let function_name_len = function_name.len() as u64;

            data_vec.extend_from_slice(&module_name_len.to_le_bytes());
            data_vec.extend_from_slice(module_name.as_bytes());

            data_vec.extend_from_slice(&function_name_len.to_le_bytes());
            data_vec.extend_from_slice(function_name.as_bytes());
        }
        //append rel_type
        let rel_type = rel.rel_type;
        data_vec.extend_from_slice(&rel_type.to_le_bytes());

        //append section number
        let section_number = rel.section_number;
        data_vec.extend_from_slice(&section_number.to_le_bytes());

        //append offset
        let offset = rel.offset;
        data_vec.extend_from_slice(&offset.to_le_bytes());
    }

    //end
    let end_section_number = END_SECTION_NUMBER;
    data_vec.extend_from_slice(&end_section_number.to_le_bytes());
    data_vec
}

pub struct BofParsedData {
    pub os_type:u8,
    pub arch_type:u8,
    pub oep: u64,
    pub text_section_data: Vec<u8>,
    pub data_section_data: Vec<u8>,
    pub rdata_section_data: Vec<u8>,
    pub bss_section_data_size: u64,
    pub relocations: Vec<Relocation>,
}

pub fn is_data_len_enough(data_start_addr:usize,data_addr:usize,data_total_size:usize,read_size:usize,err_str:&str)->Result<(),String>{
    if read_size + data_addr - data_start_addr > data_total_size {
        return Err(err_str.to_string());
    }

    return Ok(());
}

pub fn common_bof_data_parser(bof_data: &[u8]) -> Result<BofParsedData,String> {
    let mut bof_data_ptr = bof_data.as_ptr();

    // get os type
    is_data_len_enough(bof_data.as_ptr() as usize,bof_data_ptr as usize,bof_data.len(),1,"Not have enough space to read os type")?;
    let os_type = unsafe { ptr::read_unaligned(bof_data_ptr as *const u8) };
    bof_data_ptr = unsafe { bof_data_ptr.offset(1) };

    // get arch type
    is_data_len_enough(bof_data.as_ptr() as usize,bof_data_ptr as usize,bof_data.len(),1,"Not have enough space to read arch type")?;
    let arch_type = unsafe { ptr::read_unaligned(bof_data_ptr as *const u8) };
    bof_data_ptr = unsafe { bof_data_ptr.offset(1) };

    // get oep
    is_data_len_enough(bof_data.as_ptr() as usize,bof_data_ptr as usize,bof_data.len(),8,"Not have enough space to read oep")?;
    let oep = unsafe { ptr::read_unaligned(bof_data_ptr as *const u64) };
    bof_data_ptr = unsafe { bof_data_ptr.offset(8) };

    //read text data
    let mut text_section_data: Vec<u8> = Vec::new();
    is_data_len_enough(bof_data.as_ptr() as usize,bof_data_ptr as usize,bof_data.len(),8,"Not have enough space to read text data size")?;
    let text_data_size = unsafe { ptr::read_unaligned(bof_data_ptr as *const u64) };
    bof_data_ptr = unsafe { bof_data_ptr.offset(8) };
    is_data_len_enough(bof_data.as_ptr() as usize,bof_data_ptr as usize,bof_data.len(),text_data_size as usize,"Not have enough space to read text data")?;
    for _ in 0..text_data_size {
        let ch = unsafe { *bof_data_ptr };
        text_section_data.push(ch);
        bof_data_ptr = unsafe { bof_data_ptr.offset(1) };
    }

    //read data data
    let mut data_section_data: Vec<u8> = Vec::new();
    is_data_len_enough(bof_data.as_ptr() as usize,bof_data_ptr as usize,bof_data.len(),8,"Not have enough space to read data data size")?;
    let data_data_size = unsafe { ptr::read_unaligned(bof_data_ptr as *const u64) };
    bof_data_ptr = unsafe { bof_data_ptr.offset(8) };
    is_data_len_enough(bof_data.as_ptr() as usize,bof_data_ptr as usize,bof_data.len(),data_data_size as usize,"Not have enough space to read data data")?;
    for _ in 0..data_data_size {
        let ch = unsafe { *bof_data_ptr };
        data_section_data.push(ch);
        bof_data_ptr = unsafe { bof_data_ptr.offset(1) };
    }

    //read rdata data
    let mut rdata_section_data: Vec<u8> = Vec::new();
    is_data_len_enough(bof_data.as_ptr() as usize,bof_data_ptr as usize,bof_data.len(),8,"Not have enough space to read rdata data size")?;
    let rdata_data_size = unsafe { ptr::read_unaligned(bof_data_ptr as *const u64) };
    bof_data_ptr = unsafe { bof_data_ptr.offset(8) };
    is_data_len_enough(bof_data.as_ptr() as usize,bof_data_ptr as usize,bof_data.len(),rdata_data_size as usize,"Not have enough space to read rdata data size")?;
    for _ in 0..rdata_data_size {
        let ch = unsafe { *bof_data_ptr };
        rdata_section_data.push(ch);
        bof_data_ptr = unsafe { bof_data_ptr.offset(1) };
    }

    //read bss size
    is_data_len_enough(bof_data.as_ptr() as usize,bof_data_ptr as usize,bof_data.len(),8,"Not have enough space to read bss data size")?;
    let bss_data_size = unsafe { ptr::read_unaligned(bof_data_ptr as *const u64) };
    bof_data_ptr = unsafe { bof_data_ptr.offset(8) };

    //read relocation info
    let mut relocations: Vec<Relocation> = Vec::new();
    is_data_len_enough(bof_data.as_ptr() as usize,bof_data_ptr as usize,bof_data.len(),8,"Not have enough space to read target section number")?;
    let mut target_section_number = unsafe { ptr::read_unaligned(bof_data_ptr as *const u64) };
    bof_data_ptr = unsafe { bof_data_ptr.offset(8) };

    while target_section_number != END_SECTION_NUMBER {
        let mut module_name: String = "".to_string();
        let mut function_name: String = "".to_string();

        is_data_len_enough(bof_data.as_ptr() as usize,bof_data_ptr as usize,bof_data.len(),8,"Not have enough space to read offset_in_target_section")?;
        let offset_in_target_section = unsafe { ptr::read_unaligned(bof_data_ptr as *const u64) };
        bof_data_ptr = unsafe { bof_data_ptr.offset(8) };
        
        if target_section_number == DYN_FUNCTION {
            is_data_len_enough(bof_data.as_ptr() as usize,bof_data_ptr as usize,bof_data.len(),8,"Not have enough space to read module name len")?;
            let module_name_len = unsafe { ptr::read_unaligned(bof_data_ptr as *const u64) };
            bof_data_ptr = unsafe { bof_data_ptr.offset(8) };

            is_data_len_enough(bof_data.as_ptr() as usize,bof_data_ptr as usize,bof_data.len(),module_name_len as usize,"Not have enough space to read module name")?;
            let mut str_vec: Vec<u8> = Vec::new();
            for _ in 0..module_name_len {
                let ch = unsafe { *bof_data_ptr };
                str_vec.push(ch);

                bof_data_ptr = unsafe { bof_data_ptr.offset(1) }
            }

            module_name = match std::str::from_utf8(&str_vec) {
                Ok(str) => str.to_string(),
                Err(_) => "".to_string(),
            };

            is_data_len_enough(bof_data.as_ptr() as usize,bof_data_ptr as usize,bof_data.len(),8,"Not have enough space to read function name len")?;
            let function_name_len = unsafe { ptr::read_unaligned(bof_data_ptr as *const u64) };
            bof_data_ptr = unsafe { bof_data_ptr.offset(8) };

            is_data_len_enough(bof_data.as_ptr() as usize,bof_data_ptr as usize,bof_data.len(),function_name_len as usize,"Not have enough space to read function name")?;
            let mut str_vec: Vec<u8> = Vec::new();
            for _ in 0..function_name_len {
                let ch = unsafe { *bof_data_ptr };
                str_vec.push(ch);

                bof_data_ptr = unsafe { bof_data_ptr.offset(1) }
            }

            function_name = match std::str::from_utf8(&str_vec) {
                Ok(str) => str.to_string(),
                Err(_) => "".to_string(),
            };
        }

        is_data_len_enough(bof_data.as_ptr() as usize,bof_data_ptr as usize,bof_data.len(),8 as usize,"Not have enough space to read rel_type")?;
        let rel_type = unsafe { ptr::read_unaligned(bof_data_ptr as *const u64) };
        bof_data_ptr = unsafe { bof_data_ptr.offset(8) };

        is_data_len_enough(bof_data.as_ptr() as usize,bof_data_ptr as usize,bof_data.len(),8 as usize,"Not have enough space to read section_number")?;
        let section_number = unsafe { ptr::read_unaligned(bof_data_ptr as *const u64) };
        bof_data_ptr = unsafe { bof_data_ptr.offset(8) };

        is_data_len_enough(bof_data.as_ptr() as usize,bof_data_ptr as usize,bof_data.len(),8 as usize,"Not have enough space to read offset")?;
        let offset = unsafe { ptr::read_unaligned(bof_data_ptr as *const u64) };
        bof_data_ptr = unsafe { bof_data_ptr.offset(8) };

        #[cfg(test)]
        {
            println!("rel_type:{:x}", rel_type);
            println!("section_number:{:x}", section_number);
            println!("target_section_number:{:x}", target_section_number);
            println!("offset:{:x}", offset);
            println!("offset_in_target_section:{:x}", offset_in_target_section);
            println!("module name:{}", &module_name);
            println!("function name:{}", &function_name);
            println!("\n");
        }

        relocations.push(Relocation {
            target_section_number,
            section_number,
            rel_type,
            offset,
            offset_in_target_section,
            module_name,
            function_name,
        });

        is_data_len_enough(bof_data.as_ptr() as usize,bof_data_ptr as usize,bof_data.len(),8 as usize,"Not have enough space to read target_section_number")?;
        target_section_number = unsafe { ptr::read_unaligned(bof_data_ptr as *const u64) };
        bof_data_ptr = unsafe { bof_data_ptr.offset(8) };
    }

    #[cfg(test)]
    {
        println!("text_data_size: {}", text_data_size);
        println!("data_data_size: {}", data_data_size);
        println!("rdata_data_size: {}", rdata_data_size);
        println!("bss_data_size: {}", bss_data_size);
    }

    Ok(BofParsedData {
        os_type:os_type,
        arch_type:arch_type,
        oep,
        text_section_data: text_section_data,
        data_section_data: data_section_data,
        rdata_section_data: rdata_section_data,
        bss_section_data_size: bss_data_size,
        relocations,
    })
}
