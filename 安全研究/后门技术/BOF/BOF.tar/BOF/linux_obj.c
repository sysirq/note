#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

void BeaconPrintf(int type, char * fmt, ...);

#define BUFFER_SIZE 1024

int go() {
    int file_descriptor;
    ssize_t bytes_written;
    char buffer[BUFFER_SIZE] = "hacked\n";

    // 打开一个文件以写入数据
    file_descriptor = open("output.txt", O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR);
    if (file_descriptor == -1) {
        BeaconPrintf(0,"open file error");
    }

    // 写入数据
    bytes_written = write(file_descriptor, buffer, strlen(buffer));
    if (bytes_written == -1) {
        BeaconPrintf(0,"write file error");
        close(file_descriptor);
    }

    // 关闭文件
    close(file_descriptor);

    return 0;
}