# useage

```
 run_me.sh options
	-o, --output		output file
	-i, --input		input file
	--enable-debug		enable debug
	--enable-sandbox-check		enable sandbox check
	--sandbox-check-uptime		The minimum amount of time the target system has been running(minute,default:0 minutes)
	--sandbox-check-time-to-sleep		time to sleep (default:60 seconds)
```

# examples

```shell
./run_me.sh -i ../tsh-master/tshd -o hello --enable-sandbox-check --sandbox-check-uptime 30 --sandbox-check-time-to-sleep 10
```