#!/bin/sh

get_workspace_name(){
    local length=32
    local random_string=$(tr -dc 'a-zA-Z0-9' < /dev/urandom | head -c "$length")
    echo $random_string
}

environment_check(){

    which musl-gcc >/dev/null 2>&1 
    if [ $? -ne 0 ]; then
        echo "not found musl-gcc command"
        exit 1
    fi

    which make >/dev/null 2>&1 
    if [ $? -ne 0 ]; then
        echo "not found make command"
        exit 1
    fi

    which cmake >/dev/null 2>&1 
    if [ $? -ne 0 ]; then
        echo "not found cmake command"
        exit 1
    fi

    which file >/dev/null 2>&1 
    if [ $? -ne 0 ]; then
        echo "not found file command"
        exit 1
    fi

    which nasm >/dev/null 2>&1 
    if [ $? -ne 0 ]; then
        echo "not found nasm command"
        exit 1
    fi
}

useage(){
    script_name=$(basename "$0")
    echo "Usage:\\n $script_name options"
    echo "\\t-o, --output\\t\\toutput file"
    echo "\\t-i, --input\\t\\tinput file"
    echo "\\t--enable-debug\\t\\tenable debug"
    echo "\\t--enable-sandbox-check\\t\\tenable sandbox check"
    echo "\\t--sandbox-check-uptime\\t\\tThe minimum amount of time the target system has been running(minute,default:0 minutes)"
    echo "\\t--sandbox-check-time-to-sleep\\t\\ttime to sleep (default:60 seconds)"
}

environment_check

# Parse command line options
ARGS=$(getopt -o i:o:h --long help,input:,output:,enable-debug,enable-sandbox-check,sandbox-check-uptime:,sandbox-check-time-to-sleep: -n "$0" -- "$@")
if [ $? -ne 0 ]; then
    exit 1
fi

enable_debug=0
enable_sandbox_check=0
input_file=""
output_file=""
sandbox_check_uptime=0
sandbox_check_time_to_sleep=60

eval set -- "$ARGS"
while true; do
    case "$1" in
        -h | --help )
            useage
            exit 0
            ;;
        -o | --output )
            output_file="$2"
            shift 2
            ;;
        -i | --input )
            input_file="$2"
            shift 2
            ;;
        --enable-debug )
            enable_debug=1
            shift 1
            ;;
        --enable-sandbox-check )
            enable_sandbox_check=1
            shift 1
            ;;
        --sandbox-check-uptime )
            sandbox_check_uptime="$2"
            shift 2
            ;;
        --sandbox-check-time-to-sleep )
            sandbox_check_time_to_sleep="$2"
            shift 2
            ;;
        -- )
            shift
            break
            ;;
        * )
            useage
            exit 1
            ;;
    esac
done

if [ -z "$input_file" ]; then
    echo "need input file."
    exit 1
fi

if [ -z "$output_file" ]; then
    echo "need output file."
    exit 1
fi


if [ ! -f "$input_file" ]; then
     echo "input file not exist."
     exit 1
fi

file "$input_file" | grep -q "static-pie"
if [ $? -ne 0 ]; then
    echo "input file not a statically linked PIE executable."
    exit 1
fi

# code, tool copy

workspace=$(get_workspace_name)
workspace_path="/tmp/loader_$workspace"

mkdir -p "$workspace_path/src"
if [ $? -ne 0 ]; then
    echo "create workspace error($workspace_path)."
    exit 1
fi

cp -r -p lib include tools Makefile "$workspace_path" # common objs tools copy,Speed up compile
if [ $? -ne 0 ]; then
    echo "cp objs,tools error."
    rm -rf $workspace_path
    exit 1
fi

cp -r -p src/*.c "$workspace_path/src/"
if [ $? -ne 0 ]; then
    echo "cp source code error."
    rm -rf $workspace_path
    exit 1
fi

chmod +x $workspace_path/tools/print_lzma_payload
if [ $? -ne 0 ]; then
    echo "chmod +x print_lzma_payload error."
    rm -rf $workspace_path
    exit 1
fi

# payload genenrate

$workspace_path/tools/print_lzma_payload $input_file > $workspace_path/src/payload.asm

# compile
cwd=$(pwd)
cd $workspace_path
make ENABLE_DEBUG=$enable_debug ENABLE_SANDBOX_CHECK=$enable_sandbox_check SANDBOX_CHECK_UPTIME=$sandbox_check_uptime SANDBOX_CHECK_TIME_TO_SLEEP=$sandbox_check_time_to_sleep -j 16 > /dev/null 2>&1
if [ $? -ne 0 ]; then
    echo "compile code error."
    rm -rf $workspace_path
    exit 1
fi
cd $cwd

# get loader
cp $workspace_path/loader $output_file

rm -rf $workspace_path