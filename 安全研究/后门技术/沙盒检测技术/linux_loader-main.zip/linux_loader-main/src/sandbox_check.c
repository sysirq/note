#include <sys/sysinfo.h>
#include <string.h>
#include <stdio.h>
#include <stdint.h>
#include <x86intrin.h>
#include <unistd.h>
#include "debug.h"


uint64_t rdtsc() 
{
    __asm__ __volatile__("":::"memory");
    uint64_t r = __rdtsc();
    __asm__ __volatile__("":::"memory");
    return r;
}


//
uint64_t get_system_uptime_seconds(void)
{
    FILE *fp;
    double uptime_seconds;

    // Open /proc/uptime for reading
    fp = fopen("/proc/uptime", "r");
    if (fp == NULL) {
        return -1;
    }

    // Read system uptime from /proc/uptime
    if (fscanf(fp, "%lf", &uptime_seconds) != 1) {
        fclose(fp);
        return -1;
    }

    // Close the file
    fclose(fp);

    return uptime_seconds;
}

//MHz , 
uint64_t get_cpu_frequency()
{
    FILE *fp;
    char line[4096];
    float cpu_freq = 0.0;

    fp = fopen("/proc/cpuinfo", "r");
    if (fp == NULL) {
        perror("Error opening /proc/cpuinfo");
        return 1;
    }

    while (fgets(line, 4096, fp) != NULL) {
        if (strstr(line, "cpu MHz") != NULL) {
            sscanf(line, "cpu MHz : %f", &cpu_freq);
        }
    }

    fclose(fp);

    // 输出 CPU 频率
    if (cpu_freq > 0.0) {
        return cpu_freq;
    } else {
        return 0;
    }
}
