#include "compression.h"
#include "debug.h"

int print_lzma_compressd_payload(char *compressed_data)
{
    uint64_t data_decompressed_len = *(uint64_t*)(compressed_data);
    uint64_t compressed_len = *(uint64_t*)(compressed_data + sizeof(uint64_t));
    uint64_t total_len = compressed_len + sizeof(uint64_t) + sizeof(uint64_t) + LZMA_PROPS_SIZE;

    printf("section .text\nglobal payload\n\npayload:\n");

    for(int i = 0;i<total_len;i++){
        printf("\tmov al,byte 0x%.2x\n",(uint8_t)compressed_data[i]);
    }

    printf("\tret\n");
}

int memset_compressd_data(char *compressed_data,char ch)
{
    uint64_t data_decompressed_len = *(uint64_t*)(compressed_data);
    uint64_t compressed_len = *(uint64_t*)(compressed_data + sizeof(uint64_t));
    uint64_t total_len = compressed_len + sizeof(uint64_t) + sizeof(uint64_t) + LZMA_PROPS_SIZE;

    memset(compressed_data,ch,total_len);
}

int compress_use_lzma(char *data_2_compress,unsigned long data_2_compress_len,char **compressed_data)
{
    unsigned long compressed_len;
    unsigned char props[LZMA_PROPS_SIZE];
    size_t props_size=LZMA_PROPS_SIZE;//属性大小

    if (compressed_data == NULL) {
        return -1;
    }

    *compressed_data = malloc(sizeof(uint64_t) + sizeof(uint64_t) + LZMA_PROPS_SIZE + data_2_compress_len);

    if(!*compressed_data)
    {
        return 2;
    }

    switch(LzmaCompress(//开始压缩
        *compressed_data + sizeof(uint64_t) + sizeof(uint64_t) + LZMA_PROPS_SIZE,&compressed_len,
        data_2_compress,data_2_compress_len,//输入缓冲区，大小
        props,&props_size,//属性，属性大小
        9,(1<<24),3,0,2,32,2))//压缩比最大。其余全部取默认
    {
    case SZ_OK://成功完成
        *(uint64_t*)(*compressed_data) = data_2_compress_len;//原数据大小
        *(uint64_t*)(*compressed_data+sizeof(uint64_t)) = compressed_len;//compressed data len

        memset((*compressed_data+sizeof(uint64_t)+sizeof(uint64_t)),0,LZMA_PROPS_SIZE);//属性
        memcpy((*compressed_data+sizeof(uint64_t)+sizeof(uint64_t)),props,props_size);
        return 0;
    default:
        free(*compressed_data);
        *compressed_data = NULL;
        return 1;
    }
}

int decompress_use_lzma(char *compressed_data,char **data_decompressed)
{
    unsigned char props[LZMA_PROPS_SIZE];
    uint64_t data_decompressed_len = *(uint64_t*)(compressed_data);
    uint64_t compressed_len = *(uint64_t*)(compressed_data + sizeof(uint64_t));
    memcpy(props,(compressed_data+sizeof(uint64_t)+sizeof(uint64_t)),sizeof(props));

    if (data_decompressed == NULL) {
        return -1;
    }

    *data_decompressed = malloc(data_decompressed_len);

    switch(LzmaUncompress(*data_decompressed,&data_decompressed_len,
                    compressed_data +sizeof(uint64_t)+sizeof(uint64_t) + sizeof(props),
                    &compressed_len,props,sizeof(props))
    )
    {
    case SZ_OK:
        return 0;
    default:
        free(*data_decompressed);
        *data_decompressed = NULL;
        return 2;
    }
}