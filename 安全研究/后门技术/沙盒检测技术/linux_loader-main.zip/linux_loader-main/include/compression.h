#ifndef __INCLUDE_COMPRESSION_H__
#define __INCLUDE_COMPRESSION_H__

#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include "LzmaLib.h"

int decompress_use_lzma(char *compressed_data,char **data_decompressed);
int compress_use_lzma(char *data_2_compress,unsigned long data_2_compress_len,char **compressed_data);
int print_lzma_compressd_payload(char *compressed_data);
int memset_compressd_data(char *compressed_data,char ch);
#endif