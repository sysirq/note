#ifndef __INCLUDE_SANDBOX_CHECK_H__
#define __INCLUDE_SANDBOX_CHECK_H__

uint64_t get_system_uptime_seconds(void);
uint64_t rdtsc();
uint64_t get_cpu_frequency();

#endif