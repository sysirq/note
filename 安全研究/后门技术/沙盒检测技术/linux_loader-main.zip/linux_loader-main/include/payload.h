#ifndef __PAYLOAD_INCLUDE__
#define __PAYLOAD_INCLUDE__
extern int payload(int a, int b);  // 引入汇编函数
#endif
