#ifndef __INCLUDE_HIDDEN_H__
#define __INCLUDE_HIDDEN_H__

int hidden_process(int argc,char **argv,char **env);

#endif