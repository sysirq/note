/* Precomp.h -- StdAfx
2023-04-02 : Igor Pavlov : Public domain */

#ifndef ZIP7_INC_PRECOMP_H
#define ZIP7_INC_PRECOMP_H

#include "Compiler.h"
/* #include "7zTypes.h" */

#endif
