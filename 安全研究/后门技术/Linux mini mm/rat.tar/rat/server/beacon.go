package main

import (
	"fmt"
	"sync"
	"time"
)

type Beacon struct {
	beaconID uint32
	ip       string

	interval         uint32
	jitter           uint32
	last_access_time int64

	packet *Packet
	mutex  sync.Mutex

	dmesg_buf string
}

type BeaconManager struct {
	beacons []Beacon
}

func (beaconManager *BeaconManager) findBeacon(beaconID uint32) *Beacon {
	if len(beaconManager.beacons) == 0 {
		return nil
	}
	for index := range beaconManager.beacons {
		if beaconManager.beacons[index].beaconID == beaconID {
			return &beaconManager.beacons[index]
		}
	}

	return nil
}

func (beaconManager *BeaconManager) addBeacon(beacon Beacon) bool {
	found := 0
	if len(beaconManager.beacons) == 0 {
		beaconManager.beacons = append(beaconManager.beacons, beacon)
		return true
	}
	for index := range beaconManager.beacons {
		if (beaconManager.beacons[index].beaconID == beacon.beaconID) && (beaconManager.beacons[index].ip == beacon.ip) {
			found = 1
			beaconManager.beacons[index].last_access_time = beacon.last_access_time
		}
	}

	if found == 0 {
		beaconManager.beacons = append(beaconManager.beacons, beacon)

		return true
	}

	return false
}

func (beaconManager *BeaconManager) listBeacons() []string {
	var ret_str []string
	ret_str = nil

	for index := range beaconManager.beacons {
		ret_str = append(ret_str, fmt.Sprintf("beaconID:%d , IP:%s , interval:%d , jitter:%d ,last access time: %s (unix time %d)", beaconManager.beacons[index].beaconID,
			beaconManager.beacons[index].ip,
			beaconManager.beacons[index].interval,
			beaconManager.beacons[index].jitter,
			time.Unix(beaconManager.beacons[index].last_access_time, 0).Local().Format(time.UnixDate),
			beaconManager.beacons[index].last_access_time))
	}

	return ret_str
}
