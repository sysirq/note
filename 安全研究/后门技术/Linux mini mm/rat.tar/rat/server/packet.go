package main

import (
	"encoding/binary"
	"fmt"
	"net"
)

type Packet struct {
	buffer []byte
	size   int
	length int
}

func (packet *Packet) recvPacket(conn net.Conn) bool {
	buffer := make([]byte, 4)
	n, err := conn.Read(buffer[:4])
	if err != nil || n != 4 {
		fmt.Println("Error reading:", err)
		return false
	}

	packet.size = int(binary.BigEndian.Uint32(buffer[:4]))
	packet.buffer = make([]byte, packet.size)
	packet.length = 0

	n, err = conn.Read(packet.buffer[:packet.size])
	if err != nil || n != packet.size {
		fmt.Println("Error reading:", err)
		return false
	}

	return true
}

func (packet *Packet) sendPacket(conn net.Conn) {
	buffer := make([]byte, 4)
	binary.BigEndian.PutUint32(buffer, uint32(packet.size))
	buffer = append(buffer, packet.buffer...)

	conn.Write(buffer)
}

func (packet *Packet) packet_get_uint32() uint32 {
	var ret uint32

	if (packet.size - packet.length) < 4 {
		fmt.Printf("packet_get_uint32 %d %d\n", packet.size, packet.length)
		return 0
	}

	ret = uint32(binary.BigEndian.Uint32(packet.buffer[packet.length : packet.length+4]))
	packet.length += 4
	return ret
}

func (packet *Packet) packet_get_uint16() uint16 {
	var ret uint16

	if (packet.size - packet.length) < 2 {
		fmt.Printf("packet_get_uint16 %d %d\n", packet.size, packet.length)
		return 0
	}

	ret = uint16(binary.BigEndian.Uint16(packet.buffer[packet.length : packet.length+2]))
	packet.length += 2
	return ret
}

func (packet *Packet) packet_get_bytes(size int) []byte {

	if (packet.size - packet.length) < size {
		fmt.Printf("packet_get_uint16 %d %d\n", packet.size, packet.length)
		return nil
	}

	ret := make([]byte, size)

	copy(ret, packet.buffer[packet.length:packet.length+size])

	packet.length += size

	return ret
}

func (packet *Packet) packet_put_uint32(data uint32) {
	buffer := make([]byte, 4)

	binary.BigEndian.PutUint32(buffer, data)

	packet.buffer = append(packet.buffer, buffer...)

	packet.size += 4
}

func (packet *Packet) packet_put_bytes(bytes []byte) {
	packet.buffer = append(packet.buffer, bytes...)
	packet.size += len(bytes)
}
