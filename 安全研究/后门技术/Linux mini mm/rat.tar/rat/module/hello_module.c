#include "../client/include/beaconAPI.h"

char *description = "This module only for test!";

static size_t my_strlen(const char *str) {
    const char *s = str;
    while (*s) {
        s++;
    }
    return s - str;
}


int module_init(void)
{
    char *str = "module_init running\n";
    beaconOutput(str,my_strlen(str));
    return 0;
}

int module_run(void)
{
}

void module_exit(void)
{
    char *str = "module_exit running\n";
    beaconOutput(str,my_strlen(str));
}
