#include "../client/include/beaconAPI.h"

int module_init(void)
{
    beaconRegisterDescription("The module only for test!");
    beaconRegisterParameterInfo("-p","port","port");
    beaconRegisterParameterInfo("-a","addr","ipv4 addr");
    return 0;
}

int module_run(void)
{
}

void module_exit(void)
{
    
}
