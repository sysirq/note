#include "common.h"
#include "transport.h"

int my_getaddrinfo(char *host,struct sockaddr_in *addr)
{
    struct addrinfo *result, *p;

    if(addr == NULL) return -1;

    memset(addr,0,sizeof(addr));

    int status = getaddrinfo(host, NULL, NULL, &result);
    if(status != 0){
        DLX(4,printf("\tgetaddrinfo error(addr:%s)\n",host));
        return -1;
    }
    for (p = result; p != NULL; p = p->ai_next) {
        if (p->ai_family == AF_INET) {
            memcpy(addr,p->ai_addr,sizeof(struct sockaddr_in));
        };
    }
    freeaddrinfo(result);

    if(addr->sin_addr.s_addr == 0){
        DLX(4,printf("\tgetaddrinfo error(addr:%s)\n",host));
        return -1;
    }

    return 0;
}

int transport_send(char *host,int port,void *data, uint32_t size, void **recv_data, uint32_t *recv_size)
{
    tcp_send_and_recv(host,port,data,size,recv_data,recv_size);
}