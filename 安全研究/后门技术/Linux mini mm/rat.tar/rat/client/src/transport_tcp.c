#include "transport_tcp.h"

static int create_tcp_connect(struct sockaddr_in addr)
{
    int serverfd = socket(AF_INET, SOCK_STREAM, 0);
    struct linger so_linger;

    so_linger.l_onoff  = 1;
    so_linger.l_linger = 0;

    if (serverfd == -1)
    {
        DLX(4, printf("\tcreate socket error\n"));
        return -1;
    }

    if(setsockopt(serverfd,SOL_SOCKET,SO_LINGER,&so_linger,sizeof(so_linger)) == -1){
        DLX(4, printf("\tsetsockopt SO_LINGER error\n"));
        close(serverfd);
    }

    if (connect(serverfd, (struct sockaddr *)&addr, sizeof(addr)) == -1)
    {
        DLX(4, printf("\tconnect server error\n"));
        close(serverfd);
        return -1;
    }

    return serverfd;
}

static int tcp_send(int serverfd, void *data, uint32_t size)
{
    int already_send_size = 0;
    int send_size = 0;

    while (already_send_size != size)
    {
        send_size = send(serverfd, data + already_send_size, size - already_send_size,0);
        if (send_size <= 0)
        {
            DLX(4, printf("\tsend data to server error\n"));
            close(serverfd);
            return -1;
        }
        already_send_size += send_size;
    }

    return 0;
}

static int tcp_recv(int serverfd, void **data, uint32_t *size)
{
    uint32_t data_size;
    void *recv_data;

    int already_recv_size = 0;
    int recv_size = 0;
    // read size
    if (recv(serverfd, &data_size, sizeof(data_size), 0) != sizeof(data_size))
    {
        close(serverfd);
        return -1;
    }

    data_size = ntohl(data_size);
    recv_data = malloc(data_size);
    if (recv_data == NULL)
    {
        close(serverfd);
        return -1;
    }

    while (already_recv_size != data_size)
    {
        recv_size = recv(serverfd, recv_data + already_recv_size, data_size - already_recv_size, 0);
        if (recv_size <= 0)
        {
            DLX(4, printf("\trecv data to server error\n"));
            close(serverfd);
            free(recv_data);
            return -1;
        }

        already_recv_size += recv_size;
    }

    *data = recv_data;
    *size = data_size;

    return 0;
}

int tcp_send_and_recv(char *host, int port, void *data, uint32_t size, void **recv_data, uint32_t *recv_size)
{
    struct sockaddr_in addr;
    int serverfd;

    if (my_getaddrinfo(host, &addr) != 0)
    {
        return -1;
    }
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);

    serverfd = create_tcp_connect(addr);
    if (serverfd == -1)
    {
        return -1;
    }

    if (tcp_send(serverfd, data, size) == -1)
    {
        return -1;
    }

    if (tcp_recv(serverfd, recv_data, recv_size) == -1)
    {
        return -1;
    }

    DLX(4, printf("\trecv response size %d \n", *recv_size));

    return 0;
}