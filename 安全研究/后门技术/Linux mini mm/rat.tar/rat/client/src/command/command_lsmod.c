#include "command_lsmod.h"
#include "beacon.h"
#include "command.h"
#include "module.h"

int command_lsmod(BEACONINFO *beaconInfo)
{
    struct packet_struct *packet = packet_create(COMMAND_LSMOD);
    char *str;
    str = get_all_module_name_strings();

    if(str == NULL){
        packet_add_uint32(packet, 0);
    }else{
        packet_add_uint32(packet, strlen(str));
        packet_add_bytes(packet,str,strlen(str));
    }

    packet_transmit(beaconInfo, packet);
}