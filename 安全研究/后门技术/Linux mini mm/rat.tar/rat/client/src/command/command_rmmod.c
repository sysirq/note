#include "command_rmmod.h"
#include "beacon.h"
#include "command.h"
#include "module.h"
#include "error.h"

int command_rmmod(BEACONINFO *beaconInfo,char *mod_name)
{
    struct packet_struct *packet = packet_create(COMMAND_RMMOD);
    struct module *mod;
    char *err_str = "";
    packet_add_uint32(packet, strlen(mod_name));
    packet_add_bytes(packet, mod_name, strlen(mod_name));

    mod = find_module(mod_name);
    if(mod == NULL){
        packet_add_uint32(packet, -E_MOD_NOEXIST);
        err_str = "module not found";
    }else{
        if( mod->module_is_running == 1 ){
            packet_add_uint32(packet, -E_MOD_IS_RUNNING);
            err_str = "module is running";
        }
        else{
            packet_add_uint32(packet, 0);
            free_module(mod);
        }
    }

    packet_add_uint32(packet, strlen(err_str));
    if(strlen(err_str) != 0){
        packet_add_bytes(packet, err_str, strlen(err_str));
    }
    

    packet_transmit(beaconInfo, packet);
    return 0;
}