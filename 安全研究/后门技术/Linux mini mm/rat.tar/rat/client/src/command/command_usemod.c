#include "command_usemod.h"
#include "beacon.h"
#include "command.h"
#include "module.h"
#include <pthread.h>

struct usemod_pthread_arg{
    struct module *mod;
    char *argumentdata;
    uint32_t argumentSize;
};

static void* usemod_pthread_entry(void* thread_arg) {
    struct usemod_pthread_arg *arg = (struct usemod_pthread_arg *)thread_arg;
    
    exec_mod_run_function(arg->mod,arg->argumentdata,arg->argumentSize);

    arg->mod->module_is_running = 0;
    free(thread_arg);
}

int command_usemod(BEACONINFO *beaconInfo,char *mod_name,char *argumentdata,uint32_t argumentSize)
{
    struct packet_struct *packet = packet_create(COMMAND_USEMOD);
    struct module *mod;
    pthread_t pid;

    packet_add_uint32(packet, strlen(mod_name));
    packet_add_bytes(packet, mod_name, strlen(mod_name));

    mod = find_module(mod_name);
    if(mod == NULL){
        packet_add_uint32(packet, -E_MOD_NOEXIST);
    }else{

        if(mod->module_is_running == 0){
            packet_add_uint32(packet, 0);

            mod->module_is_running = 1;
            struct usemod_pthread_arg *arg = malloc(sizeof(struct usemod_pthread_arg));
            arg->mod = mod;
            arg->argumentdata = malloc(argumentSize);
            memcpy(arg->argumentdata,argumentdata,argumentSize);
            arg->argumentSize = argumentSize;

            pthread_create(&pid, NULL, usemod_pthread_entry, (void*)(&arg));
        }
        else{
            packet_add_uint32(packet, -E_MOD_IS_RUNNING);
        }

    }

    packet_transmit(beaconInfo, packet);
    return 0;
}