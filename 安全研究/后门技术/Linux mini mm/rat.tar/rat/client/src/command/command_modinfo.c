#include "command_modinfo.h"
#include "beacon.h"
#include "command.h"
#include "module.h"

int command_modinfo(BEACONINFO *beaconInfo,char *mod_name)
{
    struct packet_struct *packet = packet_create(COMMAND_MODINFO);
    struct module *mod;
    char *err_str;
    char buf[4096] = {0};
    int i = 0;
    int parms_data_len = 0;

    packet_add_uint32(packet, strlen(mod_name));
    packet_add_bytes(packet, mod_name, strlen(mod_name));

    mod = find_module(mod_name);
    if(mod == NULL){
        packet_add_uint32(packet, -E_MOD_NOEXIST);//error code
        err_str = "module not found";
        packet_add_uint32(packet, strlen(err_str));
        packet_add_bytes(packet, err_str, strlen(err_str));
    }else{
        packet_add_uint32(packet, 0);//errcode

        packet_add_uint32(packet, strlen(mod->mod_description));
        packet_add_bytes(packet, mod->mod_description, strlen(mod->mod_description));

        for(i = 0;i<mod->module_parm_count;i++){
            parms_data_len += 4;
            parms_data_len += strlen(mod->module_parms[i].option);
            parms_data_len += 4;
            parms_data_len += strlen(mod->module_parms[i].name);
            parms_data_len += 4;
            parms_data_len += strlen(mod->module_parms[i].description);
        }

        packet_add_uint32(packet, parms_data_len);

        for(i = 0;i<mod->module_parm_count;i++){
            packet_add_uint32(packet, strlen(mod->module_parms[i].option));
            packet_add_bytes(packet,mod->module_parms[i].option, strlen(mod->module_parms[i].option));

            packet_add_uint32(packet, strlen(mod->module_parms[i].name));
            packet_add_bytes(packet,mod->module_parms[i].name, strlen(mod->module_parms[i].name));
            
            packet_add_uint32(packet, strlen(mod->module_parms[i].description));
            packet_add_bytes(packet,mod->module_parms[i].description, strlen(mod->module_parms[i].description));
        }
    }

    packet_transmit(beaconInfo, packet);
    return 0;
}