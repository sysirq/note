#include "tunnel.h"
#include <pthread.h>

static int tunnel_id = 0;
static LIST_HEAD(tunnels);
pthread_mutex_t tunnels_mutex;

int tunnel_init(void)
{
    pthread_mutexattr_t mutex_attr;

    // 初始化互斥锁属性
    pthread_mutexattr_init(&mutex_attr);
    pthread_mutexattr_settype(&mutex_attr, PTHREAD_MUTEX_RECURSIVE);
    pthread_mutex_init(&tunnels_mutex, &mutex_attr);
}

static struct tunnel_data* tunnel_data_create(void)
{
    struct tunnel_data *tunnel_data = malloc(sizeof(struct tunnel_data));
    if(tunnel_data == NULL ) return NULL;

    tunnel_data->addr_rd = 0;
    tunnel_data->addr_wr = 0;
    tunnel_data->length = TUNNEL_DATA_MAX_SIZE;

    return tunnel_data;
}

static int tunnel_data_isEmpty(struct tunnel_data *tunnel_data)
{
    return (tunnel_data->addr_wr == tunnel_data->addr_rd);
}

int tunnel_data_isFull(struct tunnel_data *tunnel_data)
{
    return ((tunnel_data->addr_wr + 1) % tunnel_data->length == tunnel_data->addr_rd);
}

int tunnel_data_count(struct tunnel_data *tunnel_data)
{
    if(tunnel_data->addr_rd <= tunnel_data->addr_wr)
        return (tunnel_data->addr_wr - tunnel_data->addr_rd);
    //addr_rd > addr_wr;
    return (tunnel_data->length + tunnel_data->addr_wr - tunnel_data->addr_rd);
}

int tunnel_data_write(struct tunnel_data *tunnel_data, char data)
{
    if(tunnel_data_isFull(tunnel_data)){
        return -1;
    }
    
    tunnel_data->fifo[tunnel_data->addr_wr] = data;
    tunnel_data->addr_wr = (tunnel_data->addr_wr + 1) % tunnel_data->length;

    return 0;
}

int tunnel_data_read(struct tunnel_data *tunnel_data,char *data)
{

    if(tunnel_data_isEmpty(tunnel_data)){
        return -1;
    }
    
    *data = tunnel_data->fifo[tunnel_data->addr_rd];
    tunnel_data->addr_rd = (tunnel_data->addr_rd + 1) % tunnel_data->length;

    return 0;
}

static void tunnel_data_destroy(struct tunnel_data *tunnel_data)
{
    if(tunnel_data == NULL) return ;

    free(tunnel_data);
}


struct tunnel * tunnel_create(void)
{
    struct tunnel *tunnel = malloc(sizeof(struct tunnel));
    if(tunnel == NULL) goto cleanup;
    
    tunnel->tunnel_data  = tunnel_data_create();
    if(tunnel->tunnel_data == NULL) goto cleanup;

    tunnel->id = tunnel_id++;
    tunnel->is_closed = 0;

    return tunnel;
cleanup:
    if(tunnel != NULL){
        if(tunnel->tunnel_data != NULL){
            tunnel_data_destroy(tunnel->tunnel_data);
        }

        free(tunnel);
    }
    return NULL;
}

void tunnel_destroy(struct tunnel *tunnel)
{
    if(tunnel == NULL) return;

    tunnel_data_destroy(tunnel->tunnel_data);

    free(tunnel);
}

struct tunnel *find_tunnel(int id)
{
	struct tunnel *tunnel;

    pthread_mutex_lock(&tunnels_mutex);
	list_for_each_entry(tunnel, &tunnels, list) {
		if (tunnel->id == id)
			return tunnel;
	}
    pthread_mutex_unlock(&tunnels_mutex);
	return NULL;
}

int add_tunnel(struct tunnel *tunnel)
{
    pthread_mutex_lock(&tunnels_mutex);
    if(find_tunnel(tunnel->id) != NULL){
        return -EEXIST;
    }
    list_add(&tunnel->list,&tunnels);
    pthread_mutex_unlock(&tunnels_mutex);
    return 0;
}

void remove_tunnel(struct tunnel *tunnel)
{
    pthread_mutex_lock(&tunnels_mutex);
    list_del(&tunnel->list);
    pthread_mutex_unlock(&tunnels_mutex);
}

size_t tunnel_write(int id,char *data,size_t size)
{
    pthread_mutex_lock(&tunnels_mutex);
    struct tunnel *tunnel = find_tunnel(id);

    if(tunnel == NULL){
        pthread_mutex_unlock(&tunnels_mutex);
        return -1;    
    }

    

    pthread_mutex_unlock(&tunnels_mutex);
}