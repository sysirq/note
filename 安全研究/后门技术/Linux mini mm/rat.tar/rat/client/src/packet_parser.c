#include "packet_parser.h"

void packet_parser_new(struct packet_parser_struct *parser,char *buffer,uint32_t size)
{
    if(parser == NULL)
        return;
    parser->original = malloc(size);

    memcpy(parser->original,buffer,size);

    parser->buffer = parser->original;
    parser->length = size;
    parser->size = size;
}

void packet_parser_destroy(struct packet_parser_struct *parser)
{
    if(parser->original)
    {
        free(parser->original);
    }

    parser->original = NULL;
    parser->buffer   = NULL;
}

uint16_t packet_parser_get_uint16(struct packet_parser_struct *parser)
{
    uint16_t ret;
    if(parser->length  < 2)
        return 0;
    
    ret = *(uint16_t*)parser->buffer;
    parser->buffer += 2;
    parser->length -= 2;

    return ntohs(ret);
}

uint32_t packet_parser_get_uint32(struct packet_parser_struct *parser)
{
    uint32_t ret;
    if(parser->length  < 4)
        return 0;
    
    ret = *(uint32_t*)parser->buffer;
    parser->buffer += 4;
    parser->length -= 4;

    return ntohl(ret);
}

uint32_t packet_parser_get_bytes(struct packet_parser_struct *parser,uint8_t *data,uint32_t size)
{
    if(parser->length < size){
        return 0;
    }

    memcpy(data,parser->buffer,size);
    parser->buffer += size;
    parser->length -= size;

    return size;
}