#include "module.h"

static LIST_HEAD(modules);
__thread struct module *current_mod = NULL;

struct module *find_module(const char *name)
{
	struct module *mod;

	list_for_each_entry(mod, &modules, list) {
		if (strcmp(mod->name, name) == 0)
			return mod;
	}
	return NULL;
}

char *get_all_module_name_strings(void)
{
    struct module *mod;
    int str_len = 0;
    int index = 0;
    char *str = NULL;

    if(list_empty(&modules)){
        return NULL;
    }

    list_for_each_entry(mod,&modules,list){
        str_len = str_len + strlen(mod->name) + 1;// 1 for \n
    }
    str_len = str_len + 1;//for \0

    str = malloc(str_len);
    if(str == NULL) return NULL;
    memset(str,0,str_len);

    list_for_each_entry(mod,&modules,list){
       index += snprintf(str+index,str_len - index,"%s\n",mod->name);
    }

    return str;
}

int add_module(struct module *mod)
{
    if(find_module(mod->name) != NULL){
        return -EEXIST;
    }
    list_add(&mod->list,&modules);
    return 0;
}

void free_module(struct module *mod)
{
    ELFInfo_t elfinfo;
    int counter = 0;

    exec_mod_exit_function(mod);
    elfinfo = mod->elfinfo;

    for (counter = 0; counter < elfinfo.sectHeaderNum; counter++){
        if (elfinfo.sectionMappings != NULL){
            if (elfinfo.sectionMappings[counter] != NULL){
                munmap(elfinfo.sectionMappings[counter], elfinfo.sectHeader[counter].sh_size);
            }
        }
    }
    if (elfinfo.tempOffsetTable){
        munmap(elfinfo.tempOffsetTable, 255*ThunkTrampolineSize);
    }

    if (elfinfo.sectionMappings){
        free(elfinfo.sectionMappings);
    }
    if (elfinfo.sectionMappingProts){
        free(elfinfo.sectionMappingProts);
    }
    if (elfinfo.Header){
        free(elfinfo.Header);
    }

    list_del(&mod->list);
    free(mod);
}

int exec_mod_init_function(struct module *mod)
{
    int retcode = 0; 

    if(mod == NULL) return -1;

    current_mod = mod;

    retcode = mod->module_init_func();

    current_mod = NULL;

    return retcode;
}

void exec_mod_exit_function(struct module *mod)
{
    if(mod == NULL) return;

    current_mod = mod;

    mod->module_exit_func();

    current_mod = NULL;
}

void exec_mod_run_function(struct module *mod,char *argumentdata,uint32_t argumentSize)
{
    if(mod == NULL) return;

    current_mod = mod;

    mod->module_run_func(argumentdata,argumentSize);

    current_mod = NULL;
}