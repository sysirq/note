#if defined(__amd64__) || defined(__x86_64__)
unsigned char* ThunkTrampoline = (unsigned char*)"\x48\xb8\xEE\xEE\xEE\xEE\xEE\xEE\xEE\xEE\xff\xe0";
int ThunkTrampolineSize = 12;
#endif

/* x86 */
#if defined(__i386__)
unsigned char* ThunkTrampoline = (unsigned char*)"\x68\x00\x00\x00\x00\x58\xff\xe0";
int ThunkTrampolineSize = 8;
#endif