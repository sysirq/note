#ifndef __INCLUDE_COMMON_H__
#define __INCLUDE_COMMON_H__

/* C Library Includes */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <time.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <errno.h>
#include "debug.h"
#include "list.h"
#include "error.h"

#ifndef SUCCESS
#define SUCCESS 0
#endif

#ifndef FAILURE
#define FAILURE -1
#endif

#define ARRAY_SIZE(a) (sizeof((a))/sizeof((a[0])))

#endif