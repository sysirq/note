#ifndef __INCLUDE_PACKET_H__
#define __INCLUDE_PACKET_H__
#include "common.h"
#include "beacon.h"
#include "transport.h"
#include "beacon.h"
#include "command.h"

struct packet_struct
{
    uint32_t command_id;
    uint32_t length;
    uint32_t destroy; /* 1 :destroy this package after Transmit */
    void *buffer;

    struct packet_struct *next;
};

// packet create and destroy
struct packet_struct *packet_create(uint32_t command_id);
struct packet_struct *packet_create_with_metadata(uint32_t command_id);
void packet_destroy(struct packet_struct *packet);

// transform packet
int packet_transmit_now(char *host,int port,struct packet_struct *packet, void **response, uint32_t *response_size);
void packet_transmit(BEACONINFO *beaconInfo,struct packet_struct *packet);//cache packet
int packet_transmit_all(BEACONINFO *beaconInfo,void **response, uint32_t *response_size);

// packet add data
void packet_add_uint16(struct packet_struct *packet, uint16_t data);
void packet_add_uint32(struct packet_struct *packet, uint32_t data);
void packet_add_bytes(struct packet_struct *packet, void *data, uint32_t size);
#endif