#ifndef __INCLUDE_COMMAND_EXEC_H__
#define __INCLUDE_COMMAND_EXEC_H__

#include "common.h"
#include "command.h"
#include "packet.h"
#include "beaconAPI.h"
#include <sys/types.h>
#include <sys/wait.h>

int command_exec(BEACONINFO *beaconInfo, char *exec_name,char *exec_data);

#endif