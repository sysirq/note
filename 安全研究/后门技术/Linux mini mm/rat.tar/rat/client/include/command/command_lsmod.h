#ifndef __INCLUDE_COMMAND_LSMOD_H__
#define __INCLUDE_COMMAND_LSMOD_H__
#include "common.h"
#include "beacon.h"

int command_lsmod(BEACONINFO *beaconInfo);

#endif