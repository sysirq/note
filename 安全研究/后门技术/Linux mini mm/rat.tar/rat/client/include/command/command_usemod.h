#ifndef __INCLUDE_COMMAND_USEMOD_H__
#define __INCLUDE_COMMAND_USEMOD_H__

#include "common.h"
#include "beacon.h"

int command_usemod(BEACONINFO *beaconInfo,char *mod_name,char *argumentdata,uint32_t argumentSize);

#endif