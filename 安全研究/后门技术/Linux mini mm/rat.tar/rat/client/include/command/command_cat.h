#ifndef __INCLUDE_COMMAND_CAT_H__
#define __INCLUDE_COMMAND_CAT_H__

#include "common.h"
#include "command.h"
#include "packet.h"

int command_cat(BEACONINFO *beaconInfo, char *path);

#endif