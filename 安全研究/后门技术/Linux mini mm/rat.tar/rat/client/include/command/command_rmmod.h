#ifndef __INCLUDE_COMMAND_RMMOD_H__
#define __INCLUDE_COMMAND_RMMOD_H__

#include "beacon.h"

int command_rmmod(BEACONINFO *beaconInfo,char *mod_name);

#endif