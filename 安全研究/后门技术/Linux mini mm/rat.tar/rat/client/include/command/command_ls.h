#ifndef __INCLUDE_COMMAND_DIR_H__
#define __INCLUDE_COMMAND_DIR_H__

#include "command.h"
#include "beacon.h"
#include "packet.h"
#include <dirent.h>

int command_ls(BEACONINFO *beaconInfo,char *path);

#endif