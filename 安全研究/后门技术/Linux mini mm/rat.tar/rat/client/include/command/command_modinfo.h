#ifndef __INCLUDE_COMMAND_MODINFO_H__
#define __INCLUDE_COMMAND_MODINFO_H__

#include "beacon.h"

int command_modinfo(BEACONINFO *beaconInfo,char *mod_name);

#endif