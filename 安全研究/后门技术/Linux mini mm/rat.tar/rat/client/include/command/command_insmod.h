#ifndef __INCLUDE_COMMAND_INSMOD_H__
#define __INCLUDE_COMMAND_INSMOD_H__

#include <dlfcn.h>
#include "common.h"
#include "command.h"
#include "packet.h"
#include "beaconAPI.h"


int command_insmod(BEACONINFO *beaconInfo, char *mod_name,char *mod_data,int mod_size);

#endif