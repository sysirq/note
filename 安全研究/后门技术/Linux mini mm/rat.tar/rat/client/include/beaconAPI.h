#ifndef __INCLUDE_BEACON_API_H__
#define __INCLUDE_BEACON_API_H__
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <dirent.h>

struct beaconModuleExecResult{
    uint32_t status;
    void *buffer;
    uint32_t length;
};

void beaconRegisterParameterInfo(char *option,char *name,char *description); //register parameter
void beaconRegisterDescription(char *description); //register parameter

void* internalFunctionLookup(char* symbolName);

void beaconOutput(char* data, int len);
void beaconPrintf(const char *format, ...);
int beaconSnprintf(char *str,size_t size,const char *format,...);
void *beaconMalloc(size_t size);
void beaconFree(void *buf);
int beaconOpen(const char *pathname,int flags);
ssize_t beaconRead(int fd,void *buf,size_t count);
ssize_t beaconWrite(int fd,const void *buf,size_t count);
int beaconClose(int fd);
DIR *beaconOpendir(const char *name);
struct dirent *beaconReaddir(DIR *dirp);
int beaconClosedir(DIR *dirp);
FILE *beaconFopen(const char *pathname,const char *mode);
char* beaconFgets(char *s,int size,FILE *stream);
int beaconFclose(FILE *stream);
int beaconAtoi(const char *nptr);
#endif