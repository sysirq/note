#ifndef __INCLUDE_PACKET_PARSER_H__
#define __INCLUDE_PACKET_PARSER_H__

#include "common.h"

struct packet_parser_struct {
    char *original;
    char *buffer;
    uint32_t size;
    uint32_t length;
};

void packet_parser_new(struct packet_parser_struct *parser,char *buffer,uint32_t size);
void packet_parser_destroy(struct packet_parser_struct *parser);
uint16_t packet_parser_get_uint16(struct packet_parser_struct *parser);
uint32_t packet_parser_get_uint32(struct packet_parser_struct *parser);
uint32_t packet_parser_get_bytes(struct packet_parser_struct *parser,uint8_t *data,uint32_t size);
#endif