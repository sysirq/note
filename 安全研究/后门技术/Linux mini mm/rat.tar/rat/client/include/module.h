#ifndef __INCLUDE_MODULE_H__
#define __INCLUDE_MODULE_H__

#include "common.h"
#include "beacon.h"
#include "beaconAPI.h"
#include "elf_parser.h"

#define MODULE_NAME_LENGTH 255
#define MODULE_MAX_PARMS 100

#define MODULE_INIT_FUNC_NAME  "module_init"
#define MODULE_EXIT_FUNC_NAME  "module_exit"
#define MODULE_RUN_FUNC_NAME   "module_run"

typedef int  (*module_init)(void);
typedef void (*module_exit)(void);
typedef int  (*module_run)(char *, int);

struct module_parm{
    char *option;
    char *name;
    char *description;
};

struct module{
    /* Member of list of modules */
	struct list_head list;
    char name[MODULE_NAME_LENGTH];
    ELFInfo_t elfinfo;

    module_init module_init_func;
    module_exit module_exit_func;
    module_run  module_run_func;

    int module_is_running;//0 for false , 1 for true

    char *mod_description;
    struct module_parm module_parms[MODULE_MAX_PARMS];
    int module_parm_count;

    BEACONINFO *beaconInfo;
};

extern __thread struct module *current_mod;

struct module *find_module(const char *name);
int add_module(struct module *mod);
char *get_all_module_name_strings(void);
void free_module(struct module *mod);
int exec_mod_init_function(struct module *mod);
void exec_mod_exit_function(struct module *mod);
void exec_mod_run_function(struct module *mod,char *argumentdata,uint32_t argumentSize);

#endif