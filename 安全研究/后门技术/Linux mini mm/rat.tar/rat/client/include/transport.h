#ifndef __INCLUDE_TRANSPORT_H__
#define __INCLUDE_TRANSPORT_H__

#include "common.h"
#include "transport_tcp.h"
#include <netdb.h>

int transport_send(char *host,int port,void *data, uint32_t size, void **recv_data, uint32_t *recv_size);
int my_getaddrinfo(char *host,struct sockaddr_in *addr);

#endif