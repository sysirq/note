#ifndef __INCLUDE_TUNNEL_H__
#define __INCLUDE_TUNNEL_H__

#include "common.h"
#include <semaphore.h>

#define TUNNEL_DATA_MAX_SIZE 4096

//fifo
struct tunnel_data{
    uint32_t addr_rd;
    uint32_t addr_wr;
    uint32_t length;
    char fifo[TUNNEL_DATA_MAX_SIZE];
};

struct tunnel{
    uint32_t id;//TODO: We must ensure that we do not use another

    /* Member of list of modules */
	struct list_head list;

    char *description;

    int is_closed;

    struct tunnel_data *tunnel_data;  
};


//tunnel handlers
int tunnel_init(void);

struct tunnel * tunnel_create(void);
void tunnel_destroy(struct tunnel *tunnel);

struct tunnel *find_tunnel(int id);
int add_tunnel(struct tunnel *tunnel);
void remove_tunnel(struct tunnel *tunnel);

#endif