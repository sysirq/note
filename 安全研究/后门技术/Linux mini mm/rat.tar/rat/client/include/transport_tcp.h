#ifndef __INCLUDE_TRANSPORT_TCP_H__
#define __INCLUDE_TRANSPORT_TCP_H__

#include "common.h"
#include "transport.h"
#include <netdb.h>

int tcp_send_and_recv(char *host,int port,void *data, uint32_t size, void **recv_data, uint32_t *recv_size);

#endif